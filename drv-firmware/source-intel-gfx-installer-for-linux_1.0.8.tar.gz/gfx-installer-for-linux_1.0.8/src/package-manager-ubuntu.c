/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *          Vivek Dasmohapatra <vivek.dasmohapatra@collabora.co.uk>
 *          Marco Barisione <marco.barisione@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "config.h"
#include <sys/wait.h>
#include <glib/gi18n.h>
#include <glib/gstdio.h>
#include <gio/gio.h>
#include "package-manager-ubuntu.h"
#include "utils.h"

#define DEBUG_COMMIT_CALL 1
#define ODAPT  "org.debian.apt"
#define CUSP   "com.ubuntu.SoftwareProperties"
#define cusp   "com.ubuntu.softwareproperties"
#define REPO_NAME "intellinuxgraphics.list"

G_DEFINE_TYPE (PackageManagerUbuntu, package_manager_ubuntu, TYPE_PACKAGE_MANAGER)

struct _PackageManagerUbuntuPrivate {
  GDBusConnection *bus;
  GDBusProxy *apt_proxy;
  GSList *transactions;
  gboolean clean_mode;
  gboolean install_key;
  gchar *tmp_key_file;
  Configuration *config;
  struct {
    gchar action[128];
    gint percent;
  } progress;
};

typedef void (* TransactionFinishedFunc) (PackageManagerUbuntu *pmu, gboolean success);

typedef struct {
  PackageManagerUbuntu *pmu;
  TransactionFinishedFunc callback;
  GDBusProxy *proxy;
} TransactionData;

static gboolean update_apt_cache (PackageManagerUbuntu *pmu, gchar **xt_id);
static gboolean remove_upgrade_repo (PackageManagerUbuntu *pmu);

static void on_transaction_signal (GDBusProxy  *proxy,
                                   const gchar *sender_name,
                                   const gchar *signal_name,
                                   GVariant    *parameters,
                                   gpointer     user_data);

static gchar * dkms_header_package (void);

static void
clean_transactions (PackageManagerUbuntu *pmu)
{
  while (pmu->priv->transactions != NULL)
    {
      TransactionData *tdata = (TransactionData *) pmu->priv->transactions->data;

      pmu->priv->transactions = g_slist_remove (pmu->priv->transactions, tdata);

      g_signal_handlers_disconnect_by_func (tdata->proxy,
                                            on_transaction_signal,
                                            tdata);
      g_object_unref (tdata->proxy);

      g_free (tdata);
    }
}

static void
package_manager_ubuntu_finalize (GObject *object)
{
  PackageManagerUbuntu *pmu = PACKAGE_MANAGER_UBUNTU (object);

  if (pmu->priv != NULL)
    {
      clean_transactions (pmu);

      g_free (pmu->priv->tmp_key_file);

      if (pmu->priv->apt_proxy != NULL)
	{
	  g_object_unref (pmu->priv->apt_proxy);
	  pmu->priv->apt_proxy = NULL;
	}

      if (pmu->priv->bus != NULL)
	{
	  g_object_unref (pmu->priv->bus);
	  pmu->priv->bus = NULL;
	}

      g_free (pmu->priv);
    }

  G_OBJECT_CLASS (package_manager_ubuntu_parent_class)->finalize (object);
}

static gboolean
get_repo_config (PackageManagerUbuntu *pmu, gchar **repo_data, GError **error)
{
  gint i = -1;
  gchar *contents = NULL;
  gchar **lines = NULL;
  gboolean result = FALSE;
  const gchar *sources_file = "/etc/apt/sources.list.d/" REPO_NAME;
  const gchar *repo_url = g_ptr_array_index (pmu->priv->config->sources, 0);

  if (repo_data)
    *repo_data = NULL;

  if (g_file_test (sources_file, G_FILE_TEST_IS_REGULAR))
    if (g_file_get_contents (sources_file, &contents, NULL, error))
      if ((lines = g_strsplit (contents, "\n", 0)) != NULL)
        while (lines[++i] != NULL)
          if (g_strstr_len (lines[i], -1, repo_url))
            {
              if (repo_data)
                *repo_data = g_strdup (lines[i]);

              result = TRUE;
              break;
            }

  g_strfreev (lines);
  g_free (contents);

  return result;
}

static gboolean
check_repository_setup (PackageManagerUbuntu *pmu)
{
  gboolean result = FALSE;
  Configuration *cfg = pmu->priv->config;
  const gchar *repo_url = g_ptr_array_index (cfg->sources, 0);
  GError *error = NULL;

  update_progress_details ("Configuration", "Checking Apt Sources", 0, 1);
  update_progress_details (NULL, repo_url, 1, 1);

  result = get_repo_config (pmu, NULL, &error);

  update_progress_details (NULL, NULL, 100, 0);

  return result;
}

/* If we had a full implementation of o.fd.PackageKit we could do all *
 * of this through that - but we don't, so we have to resort to this: */
#define INSTALLED_VERSION "dpkg-query -f '${Version} ${Status}' -W %s"
#define CANDIDATE_DATA    "apt-cache madison %s"
#define CANDIDATE_FILTER  "head -n1 | sed -e \"s/^[^|]\\+| \\+\\| \\+|.*//g\""
#define CANDIDATE_VERSION "sh -c '" CANDIDATE_DATA "|" CANDIDATE_FILTER "'"

static gboolean
is_upgraded (PackageManagerUbuntu *pmu, const gchar *package)
{
  gboolean upgraded = FALSE;
  gint status = 0;
  gchar *pkg = g_shell_quote (package);
  gchar *icmd = g_strdup_printf (INSTALLED_VERSION, pkg);
  gchar *ccmd = g_strdup_printf (CANDIDATE_VERSION, pkg);
  gchar *err = NULL;
  gchar *istatus = NULL;
  const gchar *installed = NULL;
  gchar *candidate = NULL;
  GStrv detail = NULL;

  if (g_spawn_command_line_sync (icmd, &istatus, &err, &status, NULL) &&
      WIFEXITED (status))
    {
      if (WEXITSTATUS (status) != 0)
        {
          g_debug ("checking %s for installed version: %s", package, err);
          g_free (istatus);
          istatus = NULL;
        }
      else
        {
          detail = g_strsplit (istatus, " ", -1);

          if (g_strv_length (detail) >= 4)
            {
              if (g_strcmp0(detail[3], "installed") == 0)
                installed = detail[0];
            }
        }

      g_free (err);
      err = NULL;
    }

  if (g_spawn_command_line_sync (ccmd, &candidate, &err, &status, NULL) &&
      WIFEXITED (status))
    {
      if (WEXITSTATUS (status) != 0)
        {
          g_debug ("checking %s for candidate version: %s", package, err);
          g_free (candidate);
          candidate = NULL;
        }
      else
        {
          gchar *end = strchr (candidate, '\n');
          if (end)
            *end = '\0';
        }

      g_free (err);
      err = NULL;
    }

  /* bearing in mind this should only get called when we DO NOT have  *
   * the 3rd party repo configured:                                   *
   * Installed < Candidate => distro upgrade    : not our concern     *
   * Installed = Candidate => distro up to date : not our concern     *
   * Installed > Candidate => ahead of distro   : we can downgrade    */
  if ((installed != NULL) && (candidate != NULL))
    {
      upgraded = compare_versions (installed, candidate) > 0;
    }

  g_free (candidate);
  g_strfreev (detail);
  g_free (pkg);
  g_free (icmd);
  g_free (ccmd);

  return upgraded;
}

static gboolean
is_installed (PackageManagerUbuntu *pmu, const gchar *package)
{
  gboolean installed = FALSE;
  gint status = 0;
  gchar *pkg = g_shell_quote (package);
  gchar *out = NULL;
  gchar *err = NULL;
  gchar *cmd = g_strdup_printf ("dpkg-query -f'${Status}' -W %s", pkg);

  /* This is how we would like to do this (via o.fd.PackageKit.Query):
   * args = g_variant_new ("(ss)", package, "")
   * g_dbus_proxy_call_sync (proxy, "IsInstalled", args, …);
   * Unfortunately it is unreliable: It says i915-dkms is installed if
   * i915-dkms has been installed before, isn't currently, and isn't
   * available from the repo: Vexatious. */
  if (g_spawn_command_line_sync (cmd, &out, &err, &status, NULL) &&
      WIFEXITED (status) &&
      WEXITSTATUS (status) == 0)
    {
      GStrv pkg_status = NULL;

      pkg_status = g_strsplit (out, " ", -1);

      if (g_strv_length (pkg_status) >= 3)
        installed = g_strcmp0 (*(pkg_status + 2), "installed") == 0;

      g_strfreev (pkg_status);
      g_free (out);
      g_free (err);
    }

  g_free (pkg);
  g_free (cmd);

  return installed;
}

static gboolean
package_manager_ubuntu_is_system_upgraded (PackageManager *manager,
                                           DiagnosticsView *view)
{
  PackageManagerUbuntu *pmu = PACKAGE_MANAGER_UBUNTU (manager);
  gboolean upgraded = FALSE;
  Configuration *cfg = pmu->priv->config;
  guint i;
  guint x;
  guint X = (cfg->install->len + cfg->upgrade->len) * 2;

  /* we don't check install_only packages as we can never touch
     them after they've been installed: (there currently aren't any
     for ubuntu targets anyway): */

  diagnostics_view_add_postscript (view, "Checking installed packages: \n");
  update_progress_details ("Status-check", "Installation candidates", 0, 1);

  /* checking for install/remove candidates: */
  for (x = i = 0; i < cfg->install->len; i++)
    {
      const gchar *package = g_ptr_array_index (cfg->install, i);

      diagnostics_view_add_postscript (view, package);
      diagnostics_view_add_postscript (view, "\n");

      update_progress_details (NULL, package, (++x * 100) / X, 1);

      if (upgraded = is_installed (pmu, package))
        break;

      update_progress_details (NULL, package, (++x * 100) / X, 1);
    }

  // update progress as if we'd checked all the istallation candidates,
  // even if we skipped some:
  x = cfg->install->len * 2;
  update_progress_details (NULL, "Upgrade candidates", (x * 100) / X, 1);

  diagnostics_view_end_postscript (view, "Done.\n");
  diagnostics_view_add_postscript (view, "Checking upgradeable packages: \n");

  /* checking for upgrade/downgrade candidates: */
  for (i = 0; i < cfg->upgrade->len; i++)
    {
      const gchar *package = g_ptr_array_index (cfg->upgrade, i);

      diagnostics_view_add_postscript (view, package);
      diagnostics_view_add_postscript (view, "\n");

      update_progress_details (NULL, package, (++x * 100) / X, 1);

      if (upgraded = is_upgraded (pmu, package))
        break;

      update_progress_details (NULL, package, (++x * 100) / X, 1);
    }

  update_progress_details (NULL, "Complete", 100, 0);
  diagnostics_view_end_postscript (view, "Done.\n");

  return upgraded;
}

static gboolean
package_manager_ubuntu_is_setup (PackageManager *manager)
{
  return check_repository_setup (PACKAGE_MANAGER_UBUNTU (manager));
}

static gboolean
package_manager_ubuntu_is_distro_supported (PackageManager *manager,
                                            Configuration *cfg)
{
  // At least one APT source
  if (cfg->sources->len == 0)
    return FALSE;

  // at least one package to try to upgrade/install
  if (cfg->install->len +
      cfg->install_only->len +
      cfg->upgrade->len < 1)
    return FALSE;

  PACKAGE_MANAGER_UBUNTU (manager)->priv->config = cfg;

  return TRUE;
}

static void
update_progress (PackageManagerUbuntu *pmu, gint percent)
{
  gint update = -2;
  PackageManagerUbuntuPrivate *priv = pmu->priv;

  if (percent != priv->progress.percent)
    priv->progress.percent = update = percent;

  update_progress_details (NULL, NULL, update, 1);
}

static void
update_action (PackageManagerUbuntu *pmu, const gchar *action)
{
  PackageManagerUbuntuPrivate *priv = pmu->priv;

  if (action == NULL)
    return;

  if (g_strcmp0 (action, priv->progress.action))
    {
      char *c = NULL;
      gchar *atext = NULL;
      memset (priv->progress.action, 0, 128);
      g_utf8_strncpy (priv->progress.action, action, 31);

      if (g_str_has_prefix (action, "status-"))
        atext = g_strdup (action + strlen ("status-"));
      else
        atext = g_strdup (action);

      *atext = g_ascii_toupper (*atext);

      for (c = atext + 1; *c; c++)
        {
          if (*c == '-')
            *c = ' ';
        }

      update_progress_details (atext, NULL, -1, 1);
      g_free (atext);
    }
}

static void
update_message (PackageManagerUbuntu *pmu, const gchar *message)
{
  update_progress_details (NULL, message, -1, 1);
}

static void
on_transaction_signal (GDBusProxy  *proxy,
		       const gchar *sender_name,
		       const gchar *signal_name,
		       GVariant    *parameters,
		       gpointer     user_data)
{
  gchar *vp;
  TransactionData *tdata = (TransactionData *) user_data;

  vp = g_variant_print (parameters, TRUE);
  g_debug ("%s/%s: Received transaction signal %s from %s with %s", __FILE__, __FUNCTION__, signal_name, sender_name, vp);
  g_free (vp);

  if (!g_strcmp0 (signal_name, "Finished"))
    {
      gchar *exit_status;

      g_variant_get (parameters, "(s)", &exit_status);
      if (!g_strcmp0 (exit_status, "exit-success"))
	{
	  tdata->callback (tdata->pmu, TRUE);
          update_progress_details (NULL, "Done", 100, 0);
	}
      else
	{
	  tdata->callback (tdata->pmu, FALSE);
          /* stop the spinner, don't hide the last action or message */
          update_progress_details (NULL, "Failed", -1, 0);
	}

      g_free (exit_status);

      g_signal_handlers_disconnect_by_func (proxy, on_transaction_signal, tdata);
    }
  else if (!g_strcmp0 (signal_name, "PropertyChanged"))
    {
      gchar *prop = NULL;
      GVariant *value = NULL;
      const GVariantType *vtype;

      g_variant_get (parameters, "(sv)", &prop, &value);
      vtype = g_variant_get_type (value);

      if (g_strcmp0 ("Progress", prop) == 0 &&
          g_variant_type_equal (G_VARIANT_TYPE_INT32, vtype))
	{
	  update_progress (tdata->pmu, g_variant_get_int32 (value));
	}
      else if (g_strcmp0 ("Status", prop) == 0 &&
	       g_variant_type_equal (G_VARIANT_TYPE_STRING, vtype))
	{
	  update_action (tdata->pmu, g_variant_get_string (value, NULL));
	}
      else if (g_strcmp0 ("StatusDetails", prop) == 0 &&
	       g_variant_type_equal (G_VARIANT_TYPE_STRING, vtype))
	{
	  update_message (tdata->pmu, g_variant_get_string (value, NULL));
	}
      else if (g_strcmp0 ("ExitState", prop) == 0 &&
	       g_variant_type_equal (G_VARIANT_TYPE_STRING, vtype))
	{
	  if (g_strcmp0 (g_variant_get_string (value, NULL), "exit-failed") == 0)
	    {
	      tdata->callback (tdata->pmu, FALSE);
	      /* stop the spinner, don't hide the last action or message */
              update_progress_details (NULL, NULL, -1, 0);
	    }
	  else if (g_strcmp0 (g_variant_get_string (value, NULL), "exit-success") == 0)
	    {
	      tdata->callback (tdata->pmu, TRUE);
              update_progress_details (NULL, "Done", 100, 0);
	    }

	  g_signal_handlers_disconnect_by_func (proxy, on_transaction_signal, tdata);
	}
      else if (g_strcmp0 ("Error", prop) == 0)
	{
	  gchar *code, *details;

	  g_variant_get (value, "(ss)", &code, &details);

	  g_signal_emit_by_name (tdata->pmu, "error", details);
	  tdata->callback (tdata->pmu, FALSE);

	  g_signal_handlers_disconnect_by_func (proxy, on_transaction_signal, tdata);

	  g_free (code);
	  g_free (details);
	}

      g_free (prop);
      g_variant_unref (value);
    }
}

static void
run_transaction_finished (GObject      *source_object,
			  GAsyncResult *res,
			  gpointer      user_data)
{
  GVariant *result;
  TransactionData *tdata = (TransactionData *) user_data;
  GError *error = NULL;

  g_debug ("%s/%s: APT transaction finished", __FILE__, __FUNCTION__);

  result = g_dbus_proxy_call_finish (G_DBUS_PROXY (source_object), res, &error);
  if (result)
    {
      g_variant_unref (result);
    }
  else
    {
      gchar *msg = g_strdup_printf (_("Error running transaction: %s"), error->message);
      g_signal_emit_by_name (tdata->pmu, "error", msg);
      g_free (msg);
      g_error_free (error);

      tdata->callback (tdata->pmu, FALSE);

      g_signal_handlers_disconnect_by_func (source_object, on_transaction_signal, tdata);
    }
}

static gboolean
run_apt_transaction (PackageManagerUbuntu *pmu,
                     const gchar *id,
                     TransactionFinishedFunc callback,
                     const gchar *url)
{
  GDBusProxy *transaction;
  GError *error = NULL;
  TransactionData *tdata;
  Configuration *cfg = pmu->priv->config;
  const gchar *target = url ? url : g_ptr_array_index (cfg->sources, 0);
  const gchar *hproxy = get_proxy_url("http", target);
  GVariant *ret = NULL;

  g_debug ("%s/%s: Running APT transaction %s", __FILE__, __FUNCTION__, id);

  transaction = g_dbus_proxy_new_sync (pmu->priv->bus,
				       0,
				       NULL,
				       ODAPT,
				       id,
				       ODAPT ".transaction",
				       NULL,
				       &error);
  if (!transaction)
    {
      gchar *msg = g_strdup_printf (_("Could not get APT transaction: %s"), error ? error->message : "");
      g_signal_emit_by_name (pmu, "error", msg);
      g_error_free (error);
      g_free (msg);
      return FALSE;
    }
  else if (hproxy && *hproxy)
    {
      ret =
        g_dbus_proxy_call_sync (transaction, OFDBUS ".Properties.Set",
                                g_variant_new ("(ssv)",
                                               ODAPT ".transaction",
                                               "HttpProxy",
                                               g_variant_new ("(s)", hproxy)),
                                G_DBUS_CALL_FLAGS_NONE, -1, NULL, &error);
      if (ret)
        {
          g_variant_unref (ret);
          g_debug ("Set HTTP Proxy to '%s'", hproxy);
        }
      else if (error)
        {
          g_signal_emit_by_name (pmu, "error", error->message);
          g_clear_error (&error);
        }
    }

  ret = g_dbus_proxy_call_sync (transaction, OFDBUS ".Properties.Set",
                                g_variant_new ("(ssv)",
                                               ODAPT ".transaction",
                                               "AllowUnauthenticated",
                                               g_variant_new ("(b)", (gint) TRUE)),
                                G_DBUS_CALL_FLAGS_NONE, -1, NULL, &error);
  if (ret)
    {
      g_variant_unref (ret);
      g_debug ("Set allow-unauthenticated to '%d'", TRUE);
    }
  else if (error)
    {
      g_signal_emit_by_name (pmu, "error", error->message);
      g_clear_error (&error);
    }

  /* Actually run the transaction */
  tdata = g_new0 (TransactionData, 1);
  tdata->proxy = transaction;
  tdata->pmu = pmu;
  tdata->callback = callback;

  pmu->priv->transactions = g_slist_append (pmu->priv->transactions, tdata);

  g_signal_connect (transaction, "g_signal",
                    G_CALLBACK (on_transaction_signal), tdata);
  g_dbus_proxy_call (transaction, "Run",
                     NULL,
                     G_DBUS_CALL_FLAGS_NONE, -1, NULL,
                     run_transaction_finished, tdata);

  return TRUE;
}

static void
on_add_key_transaction_finished (PackageManagerUbuntu *pmu, gboolean success)
{
  if (success)
    g_signal_emit_by_name (pmu, "setup-finished");

  g_unlink (pmu->priv->tmp_key_file);
}

static void
on_add_repo_transaction_finished (PackageManagerUbuntu *pmu, gboolean success)
{
  Configuration *cfg = pmu->priv->config;
  const gchar *key_url = NULL;
  GVariant *ret = NULL;
  gchar *xt_id = NULL;
  gchar *error_msg = NULL;
  GError *error = NULL;

  if (!success)
    return;

  if (cfg->keys->len > 1)
    {
      g_critical ("You cannot specify multiple GPG keys in the configuration file.");
      error_msg = g_strdup_printf ("Malformed configuration file.");
      goto out;
    }
  else if (cfg->keys->len == 0)
    {
#if ENABLE_KEY_INSTALLATION
      /* If key installation is disabled at compile time there's no point
       * in complaining that the configuration file doesn't contain any
       * GPG key */
      g_warning ("No GPG key specified");
#endif
      pmu->priv->install_key = FALSE;
    }

  if (!pmu->priv->install_key)
    {
      /* The user doesn't want us to install the key */
      g_signal_emit_by_name (pmu, "setup-finished");
      goto out;
    }

  if (!package_manager_check_pk_permission (PACKAGE_MANAGER (pmu), ODAPT ".change-repository"))
    {
      error_msg = g_strdup_printf ("You are not authorized to install a security key.");
      goto out;
    }

  g_signal_emit_by_name (pmu, "progress", _("Adding security key for repository..."));

  key_url = g_ptr_array_index (cfg->keys, 0);
  if (!http_download_file (key_url, pmu->priv->tmp_key_file, &error))
    {
      error_msg = g_strdup_printf ("Could not download GPG key file (%s): %s",
          key_url, error ? error->message : "");
      g_clear_error (&error);
      goto out;
    }

  ret = g_dbus_proxy_call_sync (pmu->priv->apt_proxy, "AddVendorKeyFromFile",
      g_variant_new ("(s)", pmu->priv->tmp_key_file),
      G_DBUS_CALL_FLAGS_NONE,
      -1,
      NULL,
      &error);
  if (!ret)
    {
      error_msg = g_strdup_printf ("Could not authenticate repository: %s",
          error ? error->message : "");
      g_clear_error (&error);
      goto out;
    }

  /* Run the transaction */
  g_variant_get (ret, "(s)", &xt_id);
  run_apt_transaction (pmu, xt_id, on_add_key_transaction_finished, NULL);
  g_free (xt_id);

out:
  if (error_msg != NULL)
    {
      g_signal_emit_by_name (pmu, "error", error_msg);
      g_free (error_msg);
    }

  g_clear_pointer (&ret, g_variant_unref);
}

static gboolean
package_manager_ubuntu_pre_install (PackageManager *manager)
{
  gint exit_status;
  GError *error = NULL;
  const gchar *command_line =
    "pkexec "
    SCRIPTSDIR "/remove-ubuntu-repo.sh "
    "/etc/apt/sources.list.d/" REPO_NAME;
  gchar *msg;

  /* Ugh... */
  if (g_spawn_command_line_sync (command_line, NULL, NULL,
        &exit_status, &error))
    {
      if (exit_status == 0)
        {
          g_signal_emit_by_name (manager, "pre-install-finished");
          return TRUE;
        }
    }

  msg = g_strdup_printf (_("Error removing old repository configuration: %s"), error ? error->message : "");
  g_signal_emit_by_name (manager, "error", msg);
  g_free (msg);

  if (error)
    g_error_free (error);

  return FALSE;
}

static gboolean
package_manager_ubuntu_setup (PackageManager *manager, gboolean install_key)
{
  gboolean result = TRUE;
  PackageManagerUbuntu *pmu = PACKAGE_MANAGER_UBUNTU (manager);

  if (!pmu->priv->apt_proxy)
    return FALSE;

  pmu->priv->install_key = install_key;

  if (!check_repository_setup (pmu))
    {
      GVariant *ret;
      GVariantBuilder *builder;
      gchar *xt_id;
      GError *error = NULL;
      Configuration *cfg = pmu->priv->config;
      const gchar *repo_url = g_ptr_array_index (cfg->sources, 0);
      const gchar *codename = g_ptr_array_index (cfg->sources, 1);
      const gchar *release  = g_ptr_array_index (cfg->sources, 2);

      clean_transactions (pmu);

      if (!package_manager_check_pk_permission (manager, ODAPT ".change-repository"))
	return FALSE;

      if (!codename || !*codename)
        {
          Distribution *distro = get_distro_information ();
          codename = distro->codename;
        }

      /* The repository is not setup, so add it */
      builder = g_variant_builder_new (G_VARIANT_TYPE ("as"));
      g_variant_builder_add (builder, "s", release);

      g_signal_emit_by_name (pmu, "progress", _("Adding repository..."));
      ret = g_dbus_proxy_call_sync (pmu->priv->apt_proxy, "AddRepository",
				    g_variant_new ("(sssasss)",
						   "deb",
						   repo_url,
						   codename,
						   builder,
						   "Intel Graphics drivers",
						   REPO_NAME),
				    G_DBUS_CALL_FLAGS_NONE,
				    -1,
				    NULL,
				    &error);

      g_variant_builder_unref (builder);

      if (!ret)
	{
	  gchar *msg = g_strdup_printf (_("Could not add repository: %s"), error->message);
	  g_signal_emit_by_name (pmu, "error", msg);
	  g_error_free (error);
	  g_free (msg);
	  return FALSE;
	}

      /* Run the transaction */
      g_variant_get (ret, "(s)", &xt_id);
      result = run_apt_transaction (pmu, xt_id, on_add_repo_transaction_finished, NULL);
      g_free (xt_id);
      g_variant_unref (ret);
    }
  else
    {
      /* Already setup, so just notify we're done */
      g_signal_emit_by_name (pmu, "setup-finished");
    }

  return result;
}

static void
on_install_transaction_finished (PackageManagerUbuntu *pmu, gboolean success)
{
  if (success)
    {
      update_progress_details (NULL, NULL, 100, 0);

      if (pmu->priv->clean_mode)
	g_signal_emit_by_name (pmu, "cleanup-finished");
      else
	g_signal_emit_by_name (pmu, "transaction-finished");
    }
}

static void
on_update_transaction_finished (PackageManagerUbuntu *pmu, gboolean success)
{
  if (success)
    {
      if (package_manager_check_pk_permission (PACKAGE_MANAGER (pmu), ODAPT ".upgrade-packages"))
	{
	  GVariant *ret;
	  GVariantBuilder *reinstall = NULL;
          GVariantBuilder *install = NULL;
          GVariantBuilder *remove = NULL;
	  GError *error = NULL;
	  guint i;
	  gint x, X;
	  Distribution *distro = get_distro_information ();
          GVariant *gv = NULL;
	  Configuration *cfg = pmu->priv->config;

	  g_signal_emit_by_name (pmu, "progress", pmu->priv->clean_mode ? _("Downgrading packages...") : _("Installing packages..."));

          update_progress_details ("Preparing package list", "…", 0, 1);

          if (pmu->priv->clean_mode)
            {
              reinstall = g_variant_builder_new (G_VARIANT_TYPE ("as"));
              remove = g_variant_builder_new (G_VARIANT_TYPE ("as"));
              X = ( cfg->install->len + cfg->upgrade->len ) * 2;
              x = 0;

	      for (i = 0; i < cfg->install->len; i++)
		{
		  const gchar *package = g_ptr_array_index (cfg->install, i);

                  update_progress_details (NULL, package, (++x * 100) / X, 1);

		  if (is_installed (pmu, package))
                    g_variant_builder_add (remove, "s", package);

                  update_progress_details (NULL, package, (++x * 100) / X, 1);
		}

	      for (i = 0; i < cfg->upgrade->len; i++)
		{
	          const gchar *package = g_ptr_array_index (cfg->upgrade, i);
                  gchar *package_name =
                    g_strdup_printf ("%s/%s", package, distro->codename);

                  update_progress_details (NULL, package, (++x * 100) / X, 1);

                  if (is_installed (pmu, package))
                    g_variant_builder_add (reinstall, "s", package_name);

                  update_progress_details (NULL, package, (++x * 100) / X, 1);

                  g_free (package_name);
                }
	    }
	  else
	    {
	      guint j;
              gboolean extra_headers = FALSE;
              GPtrArray *pkg[] = { cfg->install,
                                   cfg->upgrade,
                                   cfg->install_only,
                                   NULL };

	      install = g_variant_builder_new (G_VARIANT_TYPE ("as"));

              for (j = 0; pkg[j]; j++)
                {
                  for (i = 0; i < pkg[j]->len; i++)
                    {
                      const gchar *package = g_ptr_array_index (pkg[j], i);

                      g_variant_builder_add (install, "s", package);

                      if (g_str_has_prefix (package, "i915-") &&
                          g_str_has_suffix (package, "-dkms"))
                        extra_headers = TRUE;
                    }
                }

              if (extra_headers)
                {
                  gchar *package = dkms_header_package ();

                  g_variant_builder_add (install, "s", package);

                  g_free (package);
                }
	    }

          update_progress_details ("Installing", "", 0, 1);

          gv = g_variant_new ("(asasasasasas)",
                              install, reinstall, remove,
                              NULL, NULL, NULL);

          if (DEBUG_COMMIT_CALL)
            {
              gchar *debug = g_variant_print (gv, TRUE);
              g_debug ("commit-packages( %s )", debug);
              g_free (debug);
            }

	  ret = g_dbus_proxy_call_sync (pmu->priv->apt_proxy, "CommitPackages",
                                        gv,
					G_DBUS_CALL_FLAGS_NONE,
					-1,
					NULL,
					&error);

          if (install)
            g_variant_builder_unref (install);

          if (reinstall)
            g_variant_builder_unref (reinstall);

          if (remove)
            g_variant_builder_unref (remove);

	  if (!ret)
	    {
	      gchar *msg = g_strdup_printf ("Could not install packages: %s", error ? error->message : "");
	      g_signal_emit_by_name (pmu, "error", msg);
	      g_error_free (error);
	      g_free (msg);
	    }
	  else
	    {
	      gchar *xt_id;

	      /* Run the transaction */
	      g_variant_get (ret, "(s)", &xt_id);
	      run_apt_transaction (pmu, xt_id, on_install_transaction_finished, NULL);
              g_free (xt_id);
	      g_variant_unref (ret);
	    }
	}
    }
}

static gboolean
package_manager_ubuntu_run_transaction (PackageManager *manager)
{
  gboolean result = FALSE;
  GVariant *ret;
  GError *error = NULL;
  PackageManagerUbuntu *pmu = PACKAGE_MANAGER_UBUNTU (manager);

  if (!pmu->priv->apt_proxy)
    return FALSE;

  clean_transactions (pmu);
  pmu->priv->clean_mode = FALSE;

  /* Update package cache */
  if (!package_manager_check_pk_permission (PACKAGE_MANAGER (pmu), ODAPT ".update-cache"))
    return FALSE;

  g_signal_emit_by_name (pmu, "progress", _("Updating package cache..."));
  ret = g_dbus_proxy_call_sync (pmu->priv->apt_proxy, "UpdateCache",
				NULL, //g_variant_new ("(s)", "intellinuxgraphics.list"),
				G_DBUS_CALL_FLAGS_NONE,
				-1,
				NULL,
				&error);
  if (!ret)
    {
      gchar *msg = g_strdup_printf (_("Could not update APT cache: %s"), error->message);
      g_signal_emit_by_name (pmu, "error", msg);
      g_error_free (error);
      g_free (msg);
    }
  else
    {
      gchar *xt_id;

      /* Run the transaction */
      g_variant_get (ret, "(s)", &xt_id);
      result = run_apt_transaction (pmu, xt_id, on_update_transaction_finished, NULL);
      g_free (xt_id);
      g_variant_unref (ret);
    }

  return result;
}

static gboolean
package_manager_ubuntu_clean (PackageManager *manager)
{
  gboolean result = FALSE;
  PackageManagerUbuntu *pmu = PACKAGE_MANAGER_UBUNTU (manager);
  gboolean have_sources = check_repository_setup (pmu);
  gboolean have_upgrade = have_sources || package_manager_ubuntu_is_system_upgraded (manager, NULL);
  gchar *xt_id = NULL;

  clean_transactions (pmu);

  if (!have_upgrade)
    {
      g_signal_emit_by_name (pmu, "cleanup-finished");
      return TRUE;
    }

  pmu->priv->clean_mode = TRUE;

  /* Remove the repository IFF we do not have the intel repo in sources */
  if (have_sources && remove_upgrade_repo (pmu))
    update_apt_cache (pmu, &xt_id);
  else
    update_apt_cache (pmu, &xt_id);

  /* No xt_id means the cache update failed (error already signalled) */
  if (xt_id != NULL)
    {
      g_debug ("Cache updated: running downgrade");
      result = run_apt_transaction (pmu, xt_id, on_update_transaction_finished, NULL);
      g_free (xt_id);
    }

  return result;
}

static gboolean
update_apt_cache (PackageManagerUbuntu *pmu, gchar **xt_id)
{
  GError *error = NULL;
  gboolean done = FALSE;
  GVariant *ret = NULL;
  PackageManager *mgr = PACKAGE_MANAGER (pmu);

  if (!package_manager_check_pk_permission (mgr, ODAPT ".update-cache"))
    return FALSE;

  /* Update the cache */
  g_signal_emit_by_name (pmu, "progress", _("Updating package cache..."));
  update_progress_details (NULL, "Update package list", 0, 1);

  ret = g_dbus_proxy_call_sync (pmu->priv->apt_proxy, "UpdateCache",
                                NULL, //g_variant_new ("(s)", "intellinuxgraphics.list"),
                                G_DBUS_CALL_FLAGS_NONE,
                                -1,
                                NULL,
                                &error);

  update_progress_details (NULL, "Update package list", 100, 0);

  if (ret)
    {
      g_variant_get (ret, "(s)", xt_id);
      g_variant_unref (ret);
      done = TRUE;
    }
  else
    {
      gchar *msg = g_strdup_printf (_("Could not update APT cache: %s"), error->message);
      g_signal_emit_by_name (pmu, "error", msg);
      g_error_free (error);
      g_free (msg);
    }

  return done;
}


static gboolean
remove_upgrade_repo (PackageManagerUbuntu *pmu)
{
  GError *error = NULL;
  gboolean done = FALSE;
  GDBusProxy *proxy;
  PackageManager *mgr = PACKAGE_MANAGER (pmu);
  gchar *repo_data = NULL;

  if(!get_repo_config (pmu, &repo_data, NULL))
    return TRUE;

  if (!package_manager_check_pk_permission (mgr, cusp ".applychanges"))
    goto cleanup;

  g_signal_emit_by_name (pmu, "progress", _("Removing Intel package repository..."));
  proxy = g_dbus_proxy_new_sync (pmu->priv->bus,
                                 G_DBUS_PROXY_FLAGS_DO_NOT_LOAD_PROPERTIES,
                                 NULL,
                                 CUSP,
                                 "/",
                                 CUSP,
                                 NULL,
                                 &error);
  if (proxy)
    {
      GVariant *ret = NULL;

      /* Tell software-properties to remove the repository */
      update_progress_details (NULL, "Removing APT repo", -1, 1);
      update_progress_details (NULL, repo_data, -1, 1);

      ret = g_dbus_proxy_call_sync (proxy, "RemoveSource",
                                    g_variant_new ("(s)", repo_data),
                                    G_DBUS_CALL_FLAGS_NONE,
                                    -1,
                                    NULL,
                                    &error);
      update_progress_details (NULL, "Complete", -1, 1);

      if (ret)
        {
          g_variant_unref (ret);
          done = TRUE;
        }
      else
        {
          gchar *msg =
            g_strdup_printf (_("Could not remove Intel repository '%s': %s"),
                             repo_data, error->message);
          g_signal_emit_by_name (pmu, "error", msg);
          g_error_free (error);
          g_free (msg);
        }

      g_object_unref (proxy);
    }
  else
    {
      gchar *msg = g_strdup_printf (_("Could not contact software-properties: %s"), error->message);
      update_progress_details (NULL, msg, -1, 0);
      g_signal_emit_by_name (pmu, "error", msg);
      g_error_free (error);
      g_free (msg);
    }

 cleanup:
  g_free (repo_data);
  return done;
}

/* It's much more convenient for functions in this file to call clean_transactions()
 * without any cast. This function is just needed to avoid warnings when assigning to
 * the virtual method. */
static void
package_manager_ubuntu_clean_transactions (PackageManager *manager)
{
  clean_transactions (PACKAGE_MANAGER_UBUNTU (manager));
}

static gboolean
package_manager_ubuntu_is_status_ok (PackageManager *manager,
                                     gchar **error_msg_out)
{
  /* -s is needed so we can run the check without being root */
  static const gchar cmd[] = "apt-get -s check";
  gint status;
  gint ret = FALSE;
  const gchar *error_msg = NULL;
  GError *error = NULL;

  if (g_spawn_command_line_sync (cmd, NULL, NULL, &status, &error))
    {
      /* The command was found and executed, now we check how that
       * worked out. */
      if (g_spawn_check_exit_status (status, &error))
        {
          /* Everything is ok. */
          ret = TRUE;
        }
      else
        {
          g_return_val_if_fail (error != NULL, FALSE); /* This should never happen */

          if (error->domain == G_SPAWN_EXIT_ERROR)
            {
              /* The command just failed, i.e. it returned something
               * different from 0, so the status of the package management
               * system is not ok  */
              error_msg = _("Some installed packages seem to be broken.\n"
                  "You might want to run \"sudo apt-get -f install\" in a "
                  "terminal to correct the problems.");
              ret = FALSE;
            }
          else
            {
              /* The program terminated abnormally, for instance it
               * was killed by a signal. This should not happen as it would
               * mean the system is seriously broken */
              g_warning ("\"%s\" terminated abnormally: %s", cmd, error->message);
              g_clear_error (&error);

              error_msg = _("Impossible to check the status of the system "
                  "(apt-get doesn't work correctly).");
              ret =  FALSE;
            }

          g_clear_error (&error);
        }
    }
  else
    {
      /* The command cannot be executed.
       * It's more likely our program is broken than apt-get not being found,
       * so we pretend the call was a success. */
      g_warning ("Cannot run \"%s\": %s\nThis error will be ignored.", cmd,
          error != NULL ? error->message : "unknown error");
      g_clear_error (&error);

      ret = TRUE;
    }

  *error_msg_out = g_strdup (error_msg);

  return ret;
}

static void
package_manager_ubuntu_class_init (PackageManagerUbuntuClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);
  PackageManagerClass *pm_class = PACKAGE_MANAGER_CLASS (klass);

  object_class->finalize = package_manager_ubuntu_finalize;
  pm_class->is_setup = package_manager_ubuntu_is_setup;
  pm_class->is_distro_supported = package_manager_ubuntu_is_distro_supported;
  pm_class->pre_install = package_manager_ubuntu_pre_install;
  pm_class->setup = package_manager_ubuntu_setup;
  pm_class->run_transaction = package_manager_ubuntu_run_transaction;
  pm_class->clean = package_manager_ubuntu_clean;
  pm_class->is_system_upgraded = package_manager_ubuntu_is_system_upgraded;
  pm_class->clean_transactions = package_manager_ubuntu_clean_transactions;
  pm_class->is_status_ok = package_manager_ubuntu_is_status_ok;
}

static void
package_manager_ubuntu_init (PackageManagerUbuntu *pmu)
{
  GError *error = NULL;

  pmu->priv = g_new0 (PackageManagerUbuntuPrivate, 1);

  pmu->priv->tmp_key_file = g_build_path ("/", g_get_home_dir (),
      "intellinuxgraphics-key", NULL);

  pmu->priv->bus = g_bus_get_sync (G_BUS_TYPE_SYSTEM, NULL, &error);
  if (!pmu->priv->bus)
    {
      g_warning ("Could not get system bus: %s\n", error->message);
      g_error_free (error);

      return;
    }

  pmu->priv->apt_proxy = g_dbus_proxy_new_sync (pmu->priv->bus,
						0,
						NULL,
						ODAPT,
						"/org/debian/apt",
						ODAPT,
						NULL,
						&error);
  if (!pmu->priv->apt_proxy)
    {
      g_warning ("Could not get D-Bus proxy for aptdaemon: %s\n", error->message);
      g_error_free (error);

      return;
    }
}

static gchar *
dkms_header_package (void)
{
  gint status = 0;
  gchar *stdout = NULL;
  gchar *stderr = NULL;
  gchar *pkg = NULL;

  if (g_spawn_command_line_sync ("uname -r", &stdout, &stderr, &status, NULL) &&
      WIFEXITED (status))
    {
      if (WEXITSTATUS (status) != 0)
        {
          g_debug ("checking for kernel version: %s", stderr);
        }
      else
        {
          pkg = g_strdup_printf ("linux-headers-%s", g_strstrip (stdout));
        }

      g_free (stdout);
      g_free (stderr);
    }

  return pkg;
}

PackageManager *
package_manager_ubuntu_new (void)
{
  return (PackageManager *) g_object_new (TYPE_PACKAGE_MANAGER_UBUNTU, NULL);
}
