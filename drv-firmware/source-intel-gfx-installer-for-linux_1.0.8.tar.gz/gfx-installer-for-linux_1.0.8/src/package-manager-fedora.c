/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *          Vivek Dasmohapatra <vivek.dasmohapatra@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "config.h"

#include <stdlib.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <glib/gi18n.h>
#include <gio/gio.h>
#include <packagekit-glib2/packagekit.h>

#include "package-manager-fedora.h"
#include "utils.h"

G_DEFINE_TYPE (PackageManagerFedora, package_manager_fedora, TYPE_PACKAGE_MANAGER)

#define ILG_REPO_URL 0
#define ILG_REPO_PKG 1

#define OFDPKIT "org.freedesktop.PackageKit"

#define PID_PACKAGE 0
#define PID_VERSION 1
#define PID_ARCH    2
#define PID_ORIGIN  3

typedef enum
{
  REMOVE_MODE_NONE,
  REMOVE_MODE_CLEANUP, /* refresh the repository */
  REMOVE_MODE_UNINSTALL /* BROKEN - uninstall */
} RemoveMode;

struct _PackageManagerFedoraPrivate
{
  GDBusProxy *pk_proxy;
  GSList *transactions;
  GHashTable *pids;
  GHashTable *vers;
  gboolean clean_mode;
  gboolean install_key;
  RemoveMode remove_mode;
  Configuration *config;
  GVariantBuilder *stage_2;
  struct utsname uname;
};

typedef void (* TransactionFinishedFunc) (PackageManagerFedora *pmf, gboolean success);

typedef struct
{
  PackageManagerFedora *pmf;
  gchar *method;
  GVariant *parameters;
  TransactionFinishedFunc callback;
  GDBusProxy *proxy;
} TransactionData;

static gboolean is_installed (PackageManagerFedora *pmf, const gchar *package);

static gboolean needs_upgrade (PackageManagerFedora *pmf, const gchar *pid);

static void package_manager_fedora_reset_pid_cache (PackageManagerFedora *pmf,
                                                    gboolean create);

static void on_pk_transaction_signal (GDBusProxy *proxy,
				      char *sender_name,
				      char *signal_name,
				      GVariant *parameters,
				      gpointer user_data);
static void on_resolve_remove_finished (PackageManagerFedora *pmf,
                                        gboolean success);

static gint
fedora_version (void)
{
  static gint version = -1;
  Distribution *distro = get_distro_information ();

  if (version >= 0)
    return version;

  if (distro->release == NULL)
    return version = 0;

  if (*distro->release == 0)
    return version = 0;

  return version = g_ascii_strtoll (distro->release, NULL, 10);
}

static void
clean_transactions (PackageManagerFedora *pmf)
{
  while (pmf->priv->transactions != NULL)
    {
      TransactionData *tdata = (TransactionData *) pmf->priv->transactions->data;

      pmf->priv->transactions = g_slist_remove (pmf->priv->transactions, tdata);

      g_signal_handlers_disconnect_by_func (tdata->proxy,
					    on_pk_transaction_signal,
					    tdata);
      g_free (tdata->method);
      g_object_unref (tdata->proxy);
      g_free (tdata);
    }
}

static void
package_manager_fedora_finalize (GObject *object)
{
  PackageManagerFedora *pmf = PACKAGE_MANAGER_FEDORA (object);

  if (pmf->priv)
    {
      clean_transactions (pmf);

      if (pmf->priv->pk_proxy)
	{
	  g_object_unref (pmf->priv->pk_proxy);
	  pmf->priv->pk_proxy = NULL;
	}

      package_manager_fedora_reset_pid_cache (pmf, FALSE);

      g_free (pmf->priv);
      pmf->priv = NULL;
    }

  G_OBJECT_CLASS (package_manager_fedora_parent_class)->finalize (object);
}

static gboolean
package_manager_fedora_is_setup (PackageManager *manager)
{
  gboolean setup = FALSE;

  update_progress_details (NULL, NULL, -1, 1);
  setup = g_file_test ("/etc/yum.repos.d/intellinuxgraphics.repo", G_FILE_TEST_EXISTS);
  update_progress_details (NULL, NULL, 100, 0);

  return setup;
}

static inline gboolean
get_proxy_permission (PackageManager *pm)
{
  guint i;
  const gchar *actions[] =
    { "org.freedesktop.packagekit.set-proxy",
      "org.freedesktop.packagekit.system-network-proxy-configure",
      NULL };

  for (i = 0; actions[i]; i++)
    if (package_manager_check_pk_permission (pm, actions[i]))
      return TRUE;

  return FALSE;
}

#define STR(x) (x ? x : "")

static void
proxy_setup (PackageManagerFedora *pmf)
{
  Configuration *cfg = pmf->priv->config;

  /* pick out the target URL that we _do_ know for sure: */
  const gchar *target    = g_ptr_array_index (cfg->sources, ILG_REPO_URL);
  const gchar *http_url  = g_str_has_prefix (target, "http:") ? target : NULL;
  const gchar *https_url = g_str_has_prefix (target, "https") ? target : NULL;
  const gchar *ftp_url   = g_str_has_prefix (target, "ftp"  ) ? target : NULL;

  /* fetch tht proxy config: */
  const gchar *proxy_http  = get_proxy_url ("http", http_url);
  const gchar *proxy_https = get_proxy_url ("https", https_url);
  const gchar *proxy_ftp   = get_proxy_url ("ftp", ftp_url);
  const gchar *proxy_socks = get_proxy_url ("socks", NULL);
  const gchar *no_proxy    = get_proxy_url ("no", NULL);
  const gchar *proxy_auto  = get_proxy_url ("PAC", NULL);
  gboolean proxied = FALSE;


  if (proxy_http || proxy_https || proxy_ftp || proxy_socks || proxy_auto)
    {
      if (get_proxy_permission (PACKAGE_MANAGER (pmf)))
        {
          proxied = TRUE;
        }
      else
        {
          g_debug ("No proxy permission");
          g_signal_emit_by_name (pmf, "error",
                                 "Unable to set proxies, some operations may fail");
        }
    }

  if (proxied)
    {
      GVariant *ret = NULL;
      GError *error = NULL;

      ret = g_dbus_proxy_call_sync (pmf->priv->pk_proxy, "SetProxy",
                                    g_variant_new ("(ssssss)",
                                                   STR (proxy_http),
                                                   STR (proxy_https),
                                                   STR (proxy_ftp),
                                                   STR (proxy_socks),
                                                   STR (no_proxy),
                                                   STR (proxy_auto)),
                                    G_DBUS_CALL_FLAGS_NONE,
                                    -1, NULL, &error);
      if (ret)
        {
          g_variant_unref (ret);
          g_debug ("set-proxy(%s, %s, %s, %s, [ %s ], %s): Ok",
                   STR (proxy_http), STR (proxy_https),
                   STR (proxy_ftp), STR (proxy_socks),
                   STR (no_proxy), STR (proxy_auto));
        }
      else
        {
          g_debug ("set-proxy(%s, %s, %s, %s, [ %s ], %s): %s",
                   proxy_http, proxy_https,
                   proxy_ftp, proxy_socks,
                   no_proxy, proxy_auto, error->message);
          g_signal_emit_by_name (pmf, "error", error->message);
          g_error_free (error);
        }
    }
  else
    {
      g_debug ("Packagekit setup: No proxies to set");
    }
}

static gboolean
package_manager_fedora_is_distro_supported (PackageManager *manager,
                                            Configuration *cfg)
{
  // must have a URL for the repo rpm, and the name of the repo package
  if (cfg->sources->len != 2)
    return FALSE;

  // at least one package to try to upgrade/install
  if (cfg->install->len +
      cfg->install_only->len +
      cfg->upgrade->len < 1)
    return FALSE;

  PACKAGE_MANAGER_FEDORA (manager)->priv->config = cfg;

  proxy_setup (PACKAGE_MANAGER_FEDORA (manager));

  return TRUE;
}

static inline gboolean
is_x86_32 (const gchar *arch)
{
  return (strlen (arch) == 4 &&
          arch[0] == 'i' &&
          arch[2] == '8' &&
          arch[3] == '6' &&
          g_ascii_isdigit (arch[1]));
}

static gboolean
package_arch_acceptable (PackageManagerFedora *pmf, const gchar *arch)
{
  if (g_strcmp0 (arch, "noarch") == 0)
    return TRUE;

  if (g_strcmp0 (arch, pmf->priv->uname.machine) == 0)
    return TRUE;

  // iX86 test - any 32 bit x86 arch matches any other for our purposes:
  if (is_x86_32 (arch) && is_x86_32 (pmf->priv->uname.machine))
    return TRUE;

  return FALSE;
}

static void
package_manager_fedora_maybe_add_pid (PackageManagerFedora *pmf,
                                      const gchar *status,
                                      const gchar *id)
{
  GStrv candidate = g_strsplit (id, ";", -1);
  const gchar *pkg = candidate[PID_PACKAGE];
  const gchar *v_new = candidate[PID_VERSION];
  const gchar *arch = candidate[PID_ARCH];
  const gchar *v_cur;

  if (!package_arch_acceptable (pmf, arch))
    goto cleanup;

  v_cur = g_hash_table_lookup (pmf->priv->vers, pkg);

  if (!v_cur || (compare_versions (v_cur, v_new) < 0))
    {
      g_debug ("SELECTING %s %s (was %s)", pkg, v_new, v_cur ? v_cur : "NONE");
      g_hash_table_replace (pmf->priv->pids, g_strdup (pkg), g_strdup (id));
      g_hash_table_replace (pmf->priv->vers, g_strdup (pkg), g_strdup (v_new));
    }

 cleanup:
  g_strfreev (candidate);
}

static void
on_pk_transaction_signal (GDBusProxy *proxy,
                          char *sender_name,
                          char *signal_name,
                          GVariant *parameters,
			  gpointer user_data)
{
  gchar *vp;
  TransactionData *tdata = (TransactionData *) user_data;

  vp = g_variant_print (parameters, TRUE);
  g_debug ("%s/%s: Received transaction signal %s from %s with %s", __FILE__, __FUNCTION__, signal_name, sender_name, vp);
  g_free (vp);

  if (!g_strcmp0 (signal_name, "ItemProgress"))
    {
      gchar *id;
      guint32 percentage;
      guint32 status;

      switch (fedora_version())
        {
          case 17:
            g_variant_get (parameters, "(su)", &id, &percentage);
            break;
          case 18:
          case 19:
          case 20:
          default:
            g_variant_get (parameters, "(suu)", &id, &status, &percentage);
        }

      update_progress_details (id, NULL, percentage, 1);
      g_free (id);
    }
  else if (!g_strcmp0 (signal_name, "Package"))
    {
      gchar *status;
      gchar *id;
      gchar *summary;

      switch (fedora_version())
        {
          guint ustat;

          case 17:
            g_variant_get (parameters, "(sss)", &status, &id, &summary);
            break;
          case 18:
          case 19:
          case 20:
          default:
            g_variant_get (parameters, "(uss)", &ustat, &id, &summary);
            status = g_strdup_printf ("status-code:%u", ustat);
        }

      if (tdata->pmf->priv->pids)
        {
          update_progress_details ("Resolving", summary, -1, 1);
          package_manager_fedora_maybe_add_pid (tdata->pmf, status, id);
        }
      else
        {
          update_progress_details ("Processing", id, -1, 1);
        }

      g_free (status);
      g_free (id);
      g_free (summary);
    }
  else if (!g_strcmp0 (signal_name, "Finished"))
    {
      guint exit_status = 0;
      gchar *exit_code = NULL;
      guint32 run_time;

      switch (fedora_version())
        {
          /* pk exit enum starts from "unknown", second value is "success" */
          case 17:
            g_variant_get (parameters, "(su)", &exit_code, &run_time);
            exit_status = (g_strcmp0 (exit_code, "success") == 0) ? 1 : 0;
            break;
          case 18:
          case 19:
          case 20:
          default:
            g_variant_get (parameters, "(uu)", &exit_status, &run_time);
            exit_code = g_strdup ((exit_status == 1) ? "success" : "unknown");
        }

      g_signal_handlers_disconnect_by_func (proxy, on_pk_transaction_signal, tdata);

      if (exit_status == 1)
        {
          tdata->callback (tdata->pmf, TRUE);
          update_progress_details ("Done", "", 100, 0);
        }
      else
        {
          tdata->callback (tdata->pmf, FALSE);
          /* stop the spinner, don't hide the last action or message */
          update_progress_details (NULL, NULL, -1, 0);
        }

      g_free (exit_code);
    }
  else if (!g_strcmp0 (signal_name, "ErrorCode"))
    {
      guint status = 0;
      gchar *code, *details;

      switch (fedora_version())
        {
          /* pk exit enum starts from "unknown", second value is "success" */
          case 17:
            g_variant_get (parameters, "(ss)", &code, &details);
            break;
          case 18:
          case 19:
          case 20:
          default:
            code = NULL;
            g_variant_get (parameters, "(us)", &status, &details);
        }

      g_signal_handlers_disconnect_by_func (proxy, on_pk_transaction_signal, tdata);

      /* FIXME: there must be a better way to detect this error */
      if ((!code || !g_strcmp0 (code, "transaction-error")) &&
          !g_strcmp0 (details, "No transaction to process"))
        {
          tdata->callback (tdata->pmf, TRUE);
          update_progress_details ("Done", "", 100, 0);
        }
      else
        {
          tdata->callback (tdata->pmf, FALSE);
          g_signal_emit_by_name (tdata->pmf, "error", details);
          /* stop the spinner, don't hide the last action or message or % */
          update_progress_details (NULL, NULL, -1, 0);
        }

      g_free (code);
      g_free (details);
    }
  else if (!g_strcmp0 (signal_name, "RepoDetail"))
    {
      gchar *repo_id, *description;
      gboolean enabled;

      g_variant_get (parameters, "(ssb)", &repo_id, &description, &enabled);
      update_progress_details ("Refreshing", description, -1, 1);

      g_free (repo_id);
      g_free (description);
    }
  else if (!g_strcmp0 (signal_name, "Changed"))
    {
      GVariant *percentage;
      gint pc = -1;

      percentage = g_dbus_proxy_get_cached_property (proxy, "Percentage");
      pc = g_variant_get_uint32 (percentage);
      update_progress_details (NULL, NULL, pc, 1);

      g_variant_unref (percentage);
    }
/* F21 uses PackageKit 1.0 which drops Message support */
#ifdef HAVE_PACKAGEKIT_MESSAGE
  else if (!g_strcmp0 (signal_name, "Message"))
    {
      guint status = 0;
      gchar *type, *details;
      gboolean free_type = TRUE;

      switch (fedora_version())
        {
          /* pk exit enum starts from "unknown", second value is "success" */
          case 17:
            g_variant_get (parameters, "(ss)", &type, &details);
            break;
          case 18:
          case 19:
          case 20:
          default:
            g_variant_get (parameters, "(us)", &status, &details);
            type = (gchar *) pk_message_enum_to_string (status);
            free_type = FALSE;
        }

      if (!g_strcmp0 (type, "repo-metadata-download-failed"))
        {
          tdata->callback (tdata->pmf, FALSE);
          g_signal_emit_by_name (tdata->pmf, "error", details);
          /* stop the spinner, don't hide the last action or message */
          update_progress_details (NULL, NULL, -1, 0);
        }
      else
        {
          update_progress_details (NULL, details, -1, 0);
        }

      if (free_type)
        g_free (type);

      g_free (details);
    }
#endif /* HAVE_PACKAGEKIT_0_8 */
}

static void
on_pk_transaction_method_finished (GObject      *source,
				   GAsyncResult *res,
				   gpointer      user_data)
{
  GError *error = NULL;
  GVariant *result;
  TransactionData *tdata = (TransactionData *) user_data;

  result = g_dbus_proxy_call_finish (G_DBUS_PROXY (source), res, &error);
  if (result)
    {
      g_variant_unref (result);
    }
  else
    {
      gchar *msg = g_strdup_printf (_("Error running transaction: %s"), error->message);
      g_signal_emit_by_name (tdata->pmf, "error", msg);
      g_free (msg);
      g_error_free (error);

      tdata->callback (tdata->pmf, FALSE);

      g_signal_handlers_disconnect_by_func (source, on_pk_transaction_signal, tdata);
    }
}

static gboolean
run_pk_transaction (PackageManagerFedora *pmf,
		    const gchar *method,
		    GVariant *parameters,
		    TransactionFinishedFunc callback)
{
  GError *error = NULL;
  GVariant *result;
  gboolean ret = TRUE;
  const gchar *mname = NULL;
  const gchar *rtype = NULL;

  switch (fedora_version())
    {
      /* no need to handle < 17 here, as the config file won't contain *
       * entries for those distros and we will ∴ never get this far:   */
      case 17:
        mname = "GetTid";
        rtype = "(s)";
        break;
      case 18:
      case 19:
      case 20:
      default:
        mname = "CreateTransaction";
        rtype = "(o)";
    }

  result = g_dbus_proxy_call_sync (pmf->priv->pk_proxy, mname, NULL,
                                   G_DBUS_CALL_FLAGS_NONE, -1, NULL, &error);

  if (result)
    {
      gchar *tid;
      GDBusProxy *proxy;

      g_variant_get (result, rtype, &tid);
      g_warning ("Created new transaction with path %s", tid);

      proxy = g_dbus_proxy_new_for_bus_sync (G_BUS_TYPE_SYSTEM,
					     G_DBUS_PROXY_FLAGS_NONE,
					     NULL,
                                             OFDPKIT,
					     tid,
					     OFDPKIT ".Transaction",
					     NULL,
					     &error);
      g_free (tid);
      g_variant_unref (result);

      if (proxy)
	{
	  TransactionData *tdata;

	  tdata = g_new0 (TransactionData, 1);
	  tdata->pmf = pmf;
	  tdata->method = g_strdup (method);
	  tdata->parameters = parameters;
	  tdata->callback = callback;
	  tdata->proxy = proxy;

	  pmf->priv->transactions = g_slist_append (pmf->priv->transactions, tdata);

	  g_signal_connect (tdata->proxy, "g-signal", G_CALLBACK (on_pk_transaction_signal), tdata);
	  g_dbus_proxy_call (tdata->proxy, tdata->method, tdata->parameters,
			     G_DBUS_CALL_FLAGS_NONE, -1, NULL,
			     on_pk_transaction_method_finished, tdata);
	}
      else
	{
	  gchar *msg = g_strdup_printf (_("Error running transaction: %s"), error ? error->message : "");
	  g_signal_emit_by_name (pmf, "error", msg);
	  g_free (msg);
	  g_error_free (error);

	  ret = FALSE;
	}
    }
  else
    {
      gchar *msg = g_strdup_printf (_("Error running transaction: %s"), error ? error->message : "");
      g_signal_emit_by_name (pmf, "error", msg);
      g_free (msg);
      g_error_free (error);

      ret = FALSE;
    }

  return ret;
}

static gboolean
run_pk_resolve (PackageManagerFedora *pmf,
                const gchar *filter,
                GVariantBuilder *packages,
                TransactionFinishedFunc callback)
{
  switch (fedora_version())
    {
      gint64 flags = 0;

      case 17:
        return run_pk_transaction (pmf, "Resolve",
                                   g_variant_new ("(sas)", filter, packages),
                                   callback);
      case 18:
      case 19:
      case 20:
      default:

        if (g_strcmp0 (filter, "none"))
          flags = pk_filter_bitfield_from_string (filter);
        else
          flags = 0;

        g_debug ("%s -> %ld", filter, flags);
        return run_pk_transaction (pmf, "Resolve",
                                   g_variant_new ("(tas)",
                                                  (gint64) flags,
                                                  packages),
                                   callback);
    }
}

static void
on_install_signature_finished_cb (GObject  *source, GAsyncResult *res, gpointer user_data)
{
  PkClient *client = PK_CLIENT (source);
  PackageManagerFedora *pmf = user_data;
  const gchar *err_msg = NULL;
  PkResults *results = NULL;
  PkError *pk_err = NULL;
  GError *error = NULL;

  results = pk_client_generic_finish (client, res, &error);
  if (results == NULL)
    {
      err_msg = error->message;
      goto out;
    }

  pk_err = pk_results_get_error_code (results);
  if (pk_err != NULL)
    {
      err_msg = pk_error_get_details (pk_err);
      goto out;
    }

out:
  if (err_msg == NULL)
    g_signal_emit_by_name (pmf, "setup-finished");
  else
    g_signal_emit_by_name (pmf, "error", err_msg);

  g_clear_object (&results);
  g_clear_object (&pk_err);
  g_clear_error (&error);
}

static void
on_add_repo_finished (PackageManagerFedora *pmf, gboolean success)
{
  PkClient *client;

  if (!success)
    return;

  if (pmf->priv->config->keys->len > 0)
    {
      g_warning ("You cannot specify GPG keys for Fedora as they are already "
          "specified in the repository file.");
    }

  if (!pmf->priv->install_key)
    {
      g_signal_emit_by_name (pmf, "setup-finished");
      return;
    }

  client = package_manager_get_pk_client (PACKAGE_MANAGER (pmf));
  pk_client_install_signature_async (client,
      PK_SIGTYPE_ENUM_GPG,
      "", /* The key ID is ignored */
      ";;;intellinuxgraphics", /* This means a repo signature for this repo */
      NULL, /* Cancellable */
      NULL, NULL, /* Progress callback and user data*/
      on_install_signature_finished_cb,
      pmf);
}

static const gchar *
install_permission_name (void)
{
  static const gchar *pname = NULL;

  if (pname)
    return pname;

  switch (fedora_version())
    {
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
        return pname = "org.freedesktop.packagekit.package-install";
      default:
        return pname = "org.freedesktop.packagekit.update-package";
    }
}

static const gchar *
update_permission_name (void)
{
  static const gchar *pname = NULL;

  if (pname)
    return pname;

  switch (fedora_version())
    {
      case 17:
        return pname = "org.freedesktop.packagekit.refresh-cache";
      case 18:
      case 19:
      case 20:
      default:
        return pname = "org.freedesktop.packagekit.system-sources-refresh";
    }
}

// g_variant_new is a varargs call and must consume a number of bytes off
// the stack which is controlled by the signature argument: This can break
// without a specific cast as we have no control over what the compiler
// will put on the stack, which can vary per architecture (32 vs 64, etc):
static GVariant *
gvariant_bas_or_tas (gint64 bt, GVariantBuilder *as)
{
  switch (fedora_version())
    {
      case 17:
        // gboolean should be the same size as gint
        // this cast should happen on 64 bit:
        return g_variant_new ("(bas)", (gint) bt, as);
      case 18:
      case 19:
      case 20:
      default:
        // this cast is necessary on 32 bit:
        return g_variant_new ("(tas)", (gint64) bt, as);
    }
}

static gboolean
package_manager_fedora_pre_install (PackageManager *manager)
{
  gboolean result = TRUE;
  PackageManagerFedora *pmf = PACKAGE_MANAGER_FEDORA (manager);
  Configuration *cfg = pmf->priv->config;
  gchar *command_line = NULL;
  gint exit_status;
  gchar *stdout = NULL;
  gchar *stderr = NULL;
  GError *error = NULL;

  command_line = g_strdup_printf ("pkexec --user root yum -y remove intellinuxgraphics-repo");
  g_print("%s", command_line);

  if (g_spawn_command_line_sync (command_line, &stdout, &stderr,
                                 &exit_status, &error))
    {
      if (exit_status == 0)
        {
          g_signal_emit_by_name (pmf, "pre-install-finished");
        }
      else
        {
          g_print("%s", stdout);
          g_print("%s", stderr);

          gchar *msg = g_strdup_printf (_("Error removing intellinuxgraphics-repo: %s"), error ? error->message : "");
          g_signal_emit_by_name (pmf, "error", msg);
          g_free (msg);
        }
    }

  if (error)
    g_error_free (error);

  g_free (stdout);
  g_free (stderr);
  g_free (command_line);

  return result;
}

static void
refresh_cache_yum (PackageManagerFedora *pmf)
{
  gint exit_status;
  gchar *stdout = NULL;
  gchar *stderr = NULL;
  GError *error = NULL;

  gchar *command_line = g_strdup_printf ("pkexec --user root yum makecache");
  g_print("%s", command_line);

  g_signal_emit_by_name (pmf, "progress", _("Updating package cache..."));

  if (g_spawn_command_line_sync (command_line, &stdout, &stderr,
                                 &exit_status, &error))
    {
      if (exit_status == 0)
        {
          on_add_repo_finished (pmf, TRUE);
        }
      else
        {
          g_print("%s", stdout);
          g_print("%s", stderr);
          if (error)
            {
              g_error("%s", error->message);
            }
        }
    }

  if (error)
    g_error_free (error);

  g_free (stdout);
  g_free (stderr);
  g_free (command_line);
}

static gboolean
package_manager_fedora_setup (PackageManager *manager, gboolean install_key)
{
  gboolean result = TRUE;
  PackageManagerFedora *pmf = PACKAGE_MANAGER_FEDORA (manager);

  if (!pmf->priv->pk_proxy)
    return FALSE;

  pmf->priv->install_key = install_key;

  if (!package_manager_fedora_is_setup (manager))
    {
      const gchar *pname = install_permission_name ();

      clean_transactions (pmf);

      /* Install RPM that contains information about the repository */
      if (package_manager_check_pk_permission (PACKAGE_MANAGER (pmf), pname))
	{
	  GVariantBuilder *packages;
	  GError *error = NULL;
	  gchar *output_file = NULL;
          Configuration *cfg = pmf->priv->config;
          const gchar *rpm_url = g_ptr_array_index (cfg->sources, ILG_REPO_URL);

	  output_file = g_build_path ("/", g_get_home_dir (), "intellinuxgraphics-repo.noarch.rpm", NULL);

          if (http_download_file (rpm_url, output_file, &error))
            {
              gint exit_status;
              gchar *stdout = NULL;
              gchar *stderr = NULL;

              gchar *command_line =
                g_strdup_printf ("pkexec --user root rpm -i %s", output_file);
              g_print("%s", command_line);

              if (g_spawn_command_line_sync (command_line, &stdout, &stderr,
                                             &exit_status, &error))
                {
                  if (exit_status == 0)
                    {
                      on_add_repo_finished (pmf, TRUE);
                    }
                  else
                    {
                      g_print("%s", stdout);
                      g_print("%s", stderr);
                      if (error)
                        {
                          g_error("%s", error->message);
                        }
                    }
                }

              if (error)
                g_error_free (error);

              g_free (stdout);
              g_free (stderr);
              g_free (command_line);
            }
	  else
	    {
	      gchar *msg = g_strdup_printf (_("Error downloading repository package: %s"), error->message);
	      g_signal_emit_by_name (manager, "error", msg);

	      g_error_free (error);
	      g_free (msg);
	    }
          g_free (output_file);
	}
    }
  else
    {
      /* Already setup, so just notify we're done */
      g_signal_emit_by_name (manager, "setup-finished");
    }

  return result;
}

static void
on_install_finished (PackageManagerFedora *pmf, gboolean success)
{
  if (success)
    {
      if (pmf->priv->clean_mode)
	g_signal_emit_by_name (PACKAGE_MANAGER (pmf), "cleanup-finished");
      else
	g_signal_emit_by_name (PACKAGE_MANAGER (pmf), "transaction-finished");
    }
}

static void
install_midpoint_reached (PackageManagerFedora *pmf, gboolean success)
{
  fprintf (stderr, "install_midpoint_reached(..., %d)\n", success);

  if (!success)
    return;

  if (pmf->priv->stage_2)
    {
      fprintf (stderr, "UpdatePackages...\n");
      run_pk_transaction (pmf, "UpdatePackages",
                          gvariant_bas_or_tas (0, pmf->priv->stage_2),
                          on_install_finished);

      g_variant_builder_unref (pmf->priv->stage_2);
      pmf->priv->stage_2 = NULL;
    }
  else
    {
      g_signal_emit_by_name (PACKAGE_MANAGER (pmf), "transaction-finished");
    }
}

static void
package_manager_fedora_reset_pid_cache (PackageManagerFedora *pmf,
                                        gboolean create)
{
  if (pmf->priv->pids)
    g_hash_table_unref (pmf->priv->pids);

  if (pmf->priv->vers)
    g_hash_table_unref (pmf->priv->vers);

  if (create)
    {
      pmf->priv->pids =
        g_hash_table_new_full (g_str_hash, g_str_equal, g_free, g_free);

      pmf->priv->vers =
        g_hash_table_new_full (g_str_hash, g_str_equal, g_free, g_free);
    }
  else
    {
      pmf->priv->pids = NULL;
      pmf->priv->vers = NULL;
    }
}

static void
install_package (PackageManagerFedora *pmf, const gchar *package, gint x, gint of)
{
  gchar *command_line = NULL;
  gint exit_status;
  gchar *stdout = NULL;
  gchar *stderr = NULL;
  GError *error = NULL;
  gchar *msg = NULL;
  gint percentage = -1;

  command_line = g_strdup_printf ("pkexec --user root yum -y install %s", package);
  g_print("%s", command_line);

  msg = g_strdup_printf (_("Installing %s"), package);
  percentage = (gint) (((gdouble) x / (gdouble) of) * 100);
  update_progress_details (_("Installing"), _("Running yum install command"), percentage, 1);
  g_free (msg);

  if (g_spawn_command_line_sync (command_line, &stdout, &stderr,
                                 &exit_status, &error))
    {
      if (exit_status != 0)
        {
          g_print("%s", stdout);
          g_print("%s", stderr);

          msg = g_strdup_printf (_("Unable to install %s: %s"), package, error ? error->message : "");
          g_signal_emit_by_name (pmf, "error", msg);
          g_free (msg);
        }
    }

  if (error)
    g_error_free (error);

  g_free (stdout);
  g_free (stderr);
  g_free (command_line);
}

static void
install_packages (PackageManagerFedora *pmf)
{
  g_signal_emit_by_name (pmf, "progress", _("Installing packages..."));

  Configuration *cfg = pmf->priv->config;
  GVariantBuilder *packages;
  guint i, j;
  GPtrArray *plist[] =
    { cfg->upgrade, cfg->install, cfg->install_only, NULL };

  gint total_length = cfg->upgrade->len + cfg->install->len + cfg->install_only->len;
  gint progress = 0;

  for (j = 0; plist[j]; j++)
    {
      for (i = 0; i < plist[j]->len; i++)
        {
          const gchar *package = g_ptr_array_index (plist[j], i);

          install_package (pmf, package, ++progress, total_length);
        }
    }

  package_manager_fedora_reset_pid_cache (pmf, TRUE);
}

static gboolean
package_manager_fedora_run_transaction (PackageManager *manager)
{
  PackageManagerFedora *pmf = PACKAGE_MANAGER_FEDORA (manager);
  const gchar *pname = NULL;

  clean_transactions (pmf);

  /* Create the transaction */
  g_signal_emit_by_name (pmf, "progress", _("Installing files..."));
  pmf->priv->clean_mode = FALSE;

  install_packages (pmf);

  g_signal_emit_by_name (PACKAGE_MANAGER (pmf), "transaction-finished");

  return TRUE;
}

static void
on_remove_refresh_cache_finished (PackageManagerFedora *pmf, gboolean success)
{
  if (success)
    {
      gchar *command_line, *msg;
      gint exit_status;
      GError *error = NULL;
      Configuration *cfg = pmf->priv->config;
      GString *downgrade = g_string_new ("");
      guint i = 0;

      g_signal_emit_by_name (pmf, "progress", _("Downgrading packages..."));
      update_progress_details (_("Downgrading"), _("Running yum downgrade command"), -1, 1);

      /* NOTE: we were calling run_pk_transaction (pmf, "Resolve" but it   *
       * turns out this doesn't work for downgrades: use shell workaround: */

      /* only packages from the upgrade list are downgrade candidates: */
      for (i = 0; i < cfg->upgrade->len; i++)
        {
          g_string_append (downgrade, g_ptr_array_index (cfg->upgrade, i));
          g_string_append_c (downgrade, ' ');
        }

      if (i > 0)
        {
          command_line =
            g_strdup_printf ("pkexec --user root sh -x " SCRIPTSDIR
                             "/yum-fetch-and-downgrade.sh %s",
                             downgrade->str);

          if (g_spawn_command_line_sync (command_line, NULL, NULL,
                                         &exit_status, &error))
            {
              if (exit_status == 0)
                {
                  g_signal_emit_by_name (PACKAGE_MANAGER (pmf), "cleanup-finished");
                  g_string_free (downgrade, TRUE);
                  return;
                }
            }

          msg = g_strdup_printf (_("Error running downgrade: %s"), error ? error->message : "");
          g_signal_emit_by_name (pmf, "error", msg);
          g_free (msg);

          if (error)
            g_error_free (error);

          g_free (command_line);
        }
      else
        {
          g_signal_emit_by_name (PACKAGE_MANAGER (pmf), "cleanup-finished");
        }

      g_string_free (downgrade, TRUE);
    }
}

static void
on_remove_package_finished (PackageManagerFedora *pmf, gboolean success)
{
  if (success)
    {
      if (pmf->priv->remove_mode == REMOVE_MODE_CLEANUP)
        {
          /* That's enough for pre-install cleanup */
          g_signal_emit_by_name (pmf, "pre-install-finished");
        }
      else
        {
          PackageManager *mgr = PACKAGE_MANAGER (pmf);
          const gchar *pname = update_permission_name ();

          if (package_manager_check_pk_permission (mgr, pname))
            {
              g_signal_emit_by_name (pmf, "progress",
                                     _("Updating package cache..."));
              run_pk_transaction (pmf, "RefreshCache",
                                  g_variant_new ("(b)", (gint) FALSE),
                                  on_remove_refresh_cache_finished);
            }
        }
    }
}

static void
on_resolve_remove_finished (PackageManagerFedora *pmf, gboolean success)
{
  if (success && pmf->priv->pids)
    {
      guint i = 0;
      gchar *key;
      gchar *val;
      GHashTableIter iter;
      GVariantBuilder *pids = g_variant_builder_new (G_VARIANT_TYPE ("as"));

      g_signal_emit_by_name (pmf, "progress", _("Removing repository..."));

      g_hash_table_iter_init (&iter, pmf->priv->pids);

      while (g_hash_table_iter_next (&iter, (gpointer) &key, (gpointer) &val))
        {
          g_debug ("Scheduling %s for removal", val);
          g_variant_builder_add (pids, "s", val);
          i++;
        }

      if (i > 0)
        {
          switch (fedora_version())
            {
              case 17:
                g_debug ("f17: pids[%d] -> g_variant_new()", i);
                run_pk_transaction (pmf, "RemovePackages",
                                    g_variant_new ("(asbb)", pids,
                                                   (gint) TRUE,
                                                   (gint) FALSE),
                                    on_remove_package_finished);
                break;
              case 18:
              case 19:
              case 20:
              default:
                g_debug ("f%d: pids[%d] -> g_variant_new()",
                         fedora_version(), i);
                run_pk_transaction (pmf, "RemovePackages",
                                    g_variant_new ("(tasbb)",
                                                   (gint64) FALSE,
                                                   pids,
                                                   (gint) TRUE,
                                                   (gint) FALSE),
                                    on_remove_package_finished);
            }
        }
      else // no packages identified? jump straight to the next step:
        {
          on_remove_package_finished (pmf, TRUE);
        }

      g_variant_builder_unref (pids);

      package_manager_fedora_reset_pid_cache (pmf, FALSE);
    }
}

static gboolean
package_manager_fedora_clean (PackageManager *manager)
{
  GVariantBuilder *builder;
  guint i;
  gboolean result;
  PackageManagerFedora *pmf = PACKAGE_MANAGER_FEDORA (manager);
  Configuration *cfg = pmf->priv->config;

  if (!pmf->priv->pk_proxy)
    return FALSE;

  clean_transactions (pmf);

  if (!package_manager_check_pk_permission (manager, "org.freedesktop.packagekit.package-remove"))
    return FALSE;

  pmf->priv->remove_mode = REMOVE_MODE_UNINSTALL;

  builder = g_variant_builder_new (G_VARIANT_TYPE ("as"));

  // packages from the install/remove list:
  for (i = 0; i < cfg->install->len; i++)
    {
      const gchar *package = g_ptr_array_index (cfg->install, i);

      g_variant_builder_add (builder, "s", package);
    }

  // the repo package:
  g_variant_builder_add (builder, "s",
                         g_ptr_array_index (cfg->sources, ILG_REPO_PKG));

  package_manager_fedora_reset_pid_cache (pmf, TRUE);

  pmf->priv->clean_mode = TRUE;
  result = run_pk_resolve (pmf, "installed", builder,
                           on_resolve_remove_finished);

  g_variant_builder_unref (builder);

  return result;
}

#define INSTALLED_VERSION "rpm -q --qf '%%{version}-%%{release}\\n' %s"
#define CANDIDATE_VERSION \
  "repoquery "                                                 \
  "--archlist=\"$(uname -p | sed -e 's/i.86/i686/')\",noarch " \
  "--qf '%%{version}-%%{release}' %s"

static gboolean
is_upgraded (PackageManagerFedora *pmf, const gchar *package)
{
  gboolean upgraded = FALSE;
  gint status = 0;
  gchar *pkg = g_shell_quote (package);
  gchar *icmd = g_strdup_printf (INSTALLED_VERSION, pkg);
  gchar *ccmd = g_strdup_printf (CANDIDATE_VERSION, pkg);
  gchar *err = NULL;
  gchar *istatus = NULL;
  const gchar *installed = NULL;
  gchar *candidate = NULL;

  if (g_spawn_command_line_sync (icmd, &istatus, &err, &status, NULL) &&
      WIFEXITED (status))
    {
      if (WEXITSTATUS (status) != 0)
        {
          g_debug ("checking %s for installed version: %s", package, err);
          g_free (istatus);
          istatus = NULL;
        }
      else
        {
          gchar *end = strrchr (istatus, '\n');

          if (end)
            *end = '\0';

          if (g_strstr_len (istatus, -1, "not installed") == NULL)
            {
              gchar *beg = strrchr (istatus, '\n');

              installed = beg ? ++beg : istatus;
            }
        }

      g_free (err);
      err = NULL;
    }

  if (g_spawn_command_line_sync (ccmd, &candidate, &err, &status, NULL) &&
      WIFEXITED (status))
    {
      if (WEXITSTATUS (status) != 0)
        {
          g_debug ("checking %s for candidate version: %s", package, err);
          g_free (candidate);
          candidate = NULL;
        }
      else
        {
          gchar *end = strchr (candidate, '\n');

          if (end)
            *end = '\0';
        }

      g_free (err);
      err = NULL;
    }

  /* bearing in mind this should only get called when we DO NOT have  *
   * the 3rd party repo configured:                                   *
   * Installed < Candidate => distro upgrade    : not our concern     *
   * Installed = Candidate => distro up to date : not our concern     *
   * Installed > Candidate => ahead of distro   : we can downgrade    */
  if ((installed != NULL) && (candidate != NULL))
    {
      upgraded = compare_versions (installed, candidate) > 0;
    }

  g_free (candidate);
  g_free (istatus);
  g_free (pkg);
  g_free (icmd);
  g_free (ccmd);

  return upgraded;
}

static gboolean
needs_upgrade (PackageManagerFedora *pmf, const gchar *pid)
{
  gboolean upgrade = TRUE;
  GStrv candidate = g_strsplit (pid, ";", -1);
  const gchar *package = candidate[PID_PACKAGE];
  gchar *v_new = candidate[PID_VERSION];
  gchar *pkg = g_shell_quote (package);
  gchar *icmd = g_strdup_printf (INSTALLED_VERSION, pkg);
  gchar *err = NULL;
  gchar *istatus = NULL;
  gint status = 0;
  gchar *installed = NULL;

  if (g_spawn_command_line_sync (icmd, &istatus, &err, &status, NULL) &&
      WIFEXITED (status))
    {
      if (WEXITSTATUS (status) != 0)
        {
          g_debug ("checking %s for installed version: %s", package, err);
          g_free (istatus);
          istatus = NULL;
        }
      else
        {
          gchar *end = strrchr (istatus, '\n');

          if (end)
            *end = '\0';

          if (g_strstr_len (istatus, -1, "not installed") == NULL)
            {
              gchar *beg = strrchr (istatus, '\n');

              installed = beg ? ++beg : istatus;
            }
        }

      g_free (err);
      err = NULL;
    }

  /* bearing in mind this should only get called when we DO have the *
   * 3rd party repo configured:                                      *
   * Installed < Candidate => distro upgrade    : upgrade            *
   * Installed = Candidate => distro up to date : noop               *
   * Installed > Candidate => ahead of distro   : not our concern    */
  if (installed && v_new)
    {
      gchar *distro_suffix = g_strdup_printf (".fc%d", fedora_version ());
      guint slen = strlen (distro_suffix);

      if (g_str_has_suffix (installed, distro_suffix))
        *(installed + strlen (installed) - slen) = '\0';

      if (g_str_has_suffix (v_new, distro_suffix))
        *(v_new + strlen (v_new) - slen) = '\0';

      g_debug ("pid: %s -> (%s); '%s' / '%s'", pid, package, installed, v_new);
      upgrade = compare_versions (installed, v_new) < 0;

      g_free (distro_suffix);
    }

  g_strfreev (candidate);
  g_free (pkg);
  g_free (icmd);
  g_free (istatus);

  return upgrade;
}

static gboolean
is_installed (PackageManagerFedora *pmf, const gchar *package)
{
  gboolean installed = FALSE;
  gint status = 0;
  gchar *pkg = g_shell_quote (package);
  gchar *out = NULL;
  gchar *err = NULL;
  gchar *cmd = g_strdup_printf ("rpm -q --qf '%%{installtime}' %s", pkg);

  if (g_spawn_command_line_sync (cmd, &out, &err, &status, NULL) &&
      WIFEXITED (status) &&
      WEXITSTATUS (status) == 0)
    {
      gchar *iend = NULL;
      gint64 itime = g_ascii_strtoll (out, &iend, 10);

      installed = (iend != out) && (itime > 0);
    }

  g_free (pkg);
  g_free (cmd);
  g_free (out);
  g_free (err);

  return installed;
}

static gboolean
package_manager_fedora_is_system_upgraded (PackageManager *manager,
                                           DiagnosticsView *view)
{
  PackageManagerFedora *pmf = PACKAGE_MANAGER_FEDORA (manager);
  gboolean upgraded = FALSE;
  Configuration *cfg = pmf->priv->config;
  guint i;
  guint x = 0;
  guint X = (cfg->install->len + cfg->upgrade->len) * 2;

  /* do not check install_only packages as we cannot touch
     them after they've been installed: */

  diagnostics_view_add_postscript (view, "Checking installed packages: \n");

  /* checking for install/remove candidates: */
  for (i = 0; i < cfg->install->len; i++)
    {
      const gchar *package = g_ptr_array_index (cfg->install, i);

      update_progress_details (NULL, package, (++x * 100)/X, 1);
      g_debug ("checking %s is installed", package);
      diagnostics_view_add_postscript (view, package);
      diagnostics_view_add_postscript (view, "\n");

      upgraded = is_installed (pmf, package);
      if (upgraded)
        break;

      update_progress_details (NULL, package, (++x * 100)/X, 1);
    }

  update_progress_details (NULL, NULL, (cfg->install->len * 200)/X, 1);
  diagnostics_view_end_postscript (view, "Done.\n");
  diagnostics_view_add_postscript (view, "Checking upgradeable packages: \n");

  /* checking for upgrade/downgrade candidates: */
  for (i = 0; i < cfg->upgrade->len; i++)
    {
      const gchar *package = g_ptr_array_index (cfg->upgrade, i);

      update_progress_details (NULL, package, (++x * 100)/X, 1);
      g_debug ("checking %s is upgraded", package);

      diagnostics_view_add_postscript (view, package);
      diagnostics_view_add_postscript (view, "\n");

      upgraded = is_upgraded (pmf, package);
      if (upgraded)
        break;

      update_progress_details (NULL, package, (++x * 100)/X, 1);
    }

  update_progress_details (NULL, NULL, 100, 0);
  diagnostics_view_end_postscript (view, "Done.\n");

  return upgraded;
}

/* It's much more convenient for functions in this file to call clean_transactions()
 * without any cast. This function is just needed to avoid warnings when assigning to
 * the virtual method. */
static void
package_manager_fedora_clean_transactions (PackageManager *manager)
{
  clean_transactions (PACKAGE_MANAGER_FEDORA (manager));
}

static gboolean
package_manager_fedora_is_status_ok (PackageManager *manager,
                                     gchar **error_msg_out)
{
  GDir *dir;
  const gchar *file_name;
  gboolean transaction_found = FALSE;
  gboolean ret;
  const gchar *error_msg = NULL;

  /* This function is racy and depends on some technical details of how yum
   * works, but at least it should prevent this installer from running if
   * there are previous abandoned transactions.
   *
   * We don't care about the status of "yum check" as yum doesn't seem to
   * care if the dependencies of other unrelated packages are broken. If
   * the package is related to what we are going to install and broken,
   * then yum should fix it by itself.
   *
   * We don't care if yum is running, but not installing anything as the
   * package manager will take care of waiting for it to exit before doing
   * anything (so it won't just fail).
   */

  dir = g_dir_open ("/var/lib/yum", 0, NULL);
  if (dir == NULL)
    {
      /* Well, this is not normal, but what can we do about it? */
      return TRUE;
    }

  while ((file_name = g_dir_read_name (dir)) != NULL)
    {
      if (g_str_has_prefix (file_name, "transaction-all.") &&
          !g_str_has_suffix (file_name, "disabled"))
        {
          transaction_found = TRUE;
          break;
        }
    }

  if (transaction_found)
    {
      gchar *contents;
      gsize contents_len;
      gchar *pid_string;
      gint pid;
      gchar *pid_path = NULL;

      /* There's an unfinished transaction, so we should not mess with the
       * system */
      ret = FALSE;

      if (g_file_get_contents ("/var/run/yum.pid", &contents, &contents_len, NULL))
        {
          /* There's a PID file, but it could have been left by an
           * interrupted (or crashed) process, so we verify that the
           * process actually exists. */
          pid_string = g_new0 (gchar, contents_len + 1);
          strncpy (pid_string, contents, contents_len);
          pid = atoi (pid_string);
          if (pid > 0)
            pid_path = g_strdup_printf ("/proc/%d", pid);

          g_free (contents);
        }

      if (pid_path != NULL &&
          g_file_test (pid_path, G_FILE_TEST_IS_DIR))
        {
          /* The transaction is there and yum is running, maybe yum is just
           * installing something now */
          error_msg = _("The package manager is already installing other "
              "packages.\n"
              "Please wait for the current installation to finish and rerun "
              "this installer.");
        }
      else
        {
          /* yum is not running but there's an unfinished transaction;
           * probably something went wrong in the past */
          error_msg = _("There are unfinished transactions remaining, this probably "
              "means that a previous installation was interrupted.\n"
              "You might consider running \"yum-complete-transaction\" in a terminal "
              "to finish them.");
        }

      g_free (pid_path);
    }
  else
    {
      ret = TRUE;
    }

  *error_msg_out = g_strdup (error_msg);

  g_dir_close (dir);

  return ret;
}

const gchar *
package_manager_fedora_get_repo_name (PackageManagerFedora *pmf)
{
  return g_ptr_array_index (pmf->priv->config->sources, ILG_REPO_PKG);
}


static void
package_manager_fedora_class_init (PackageManagerFedoraClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);
  PackageManagerClass *pm_class = PACKAGE_MANAGER_CLASS (klass);

  object_class->finalize = package_manager_fedora_finalize;
  pm_class->is_setup = package_manager_fedora_is_setup;
  pm_class->is_distro_supported = package_manager_fedora_is_distro_supported;
  pm_class->pre_install = package_manager_fedora_pre_install;
  pm_class->setup = package_manager_fedora_setup;
  pm_class->run_transaction = package_manager_fedora_run_transaction;
  pm_class->clean = package_manager_fedora_clean;
  pm_class->is_system_upgraded = package_manager_fedora_is_system_upgraded;
  pm_class->clean_transactions = package_manager_fedora_clean_transactions;
  pm_class->is_status_ok = package_manager_fedora_is_status_ok;
}

static void
package_manager_fedora_init (PackageManagerFedora *pmf)
{
  GError *error = NULL;

  pmf->priv = g_new0 (PackageManagerFedoraPrivate, 1);

  pmf->priv->pk_proxy = g_dbus_proxy_new_for_bus_sync (G_BUS_TYPE_SYSTEM,
						       G_DBUS_PROXY_FLAGS_NONE,
						       NULL,
						       OFDPKIT,
						       "/org/freedesktop/PackageKit",
						       OFDPKIT,
						       NULL,
						       &error);
  if (!pmf->priv->pk_proxy)
    {
      g_warning ("Could not get D-Bus proxy for PackageKit: %s\n", error->message);
      g_error_free (error);

      return;
    }

  uname (&pmf->priv->uname);

  pmf->priv->remove_mode = REMOVE_MODE_NONE;
}

PackageManager *
package_manager_fedora_new (void)
{
  return (PackageManager *) g_object_new (TYPE_PACKAGE_MANAGER_FEDORA, NULL);
}
