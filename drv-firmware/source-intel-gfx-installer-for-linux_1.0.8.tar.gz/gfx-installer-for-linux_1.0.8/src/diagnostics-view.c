/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <sys/utsname.h>
#include <glib/gi18n.h>
#include <pango/pango-font.h>
#include "diagnostics-view.h"
#include "marshal.h"
#include "package-manager.h"
#include "utils.h"

G_DEFINE_TYPE (DiagnosticsView, diagnostics_view, GTK_TYPE_BOX)

enum {
  FINISHED_SIGNAL,
  LAST_SIGNAL
};
static guint dv_signals[LAST_SIGNAL];

typedef gboolean (* DiagnosticFunc) (DiagnosticsView *view);

typedef struct {
  DiagnosticFunc perform_check;
  gchar *text;
} Diagnostic;

struct _DiagnosticsViewPrivate {
  GSList *diagnostics;
  GtkWidget *log_window;
};

static gboolean intel_diagnostic (DiagnosticsView *view);
static gboolean config_file_diagnostic (DiagnosticsView *view);
static gboolean distribution_diagnostic (DiagnosticsView *view);
static gboolean kernel_version_diagnostic (DiagnosticsView *view);
static gboolean repo_diagnostic (DiagnosticsView *view);
static gboolean pm_diagnostic (DiagnosticsView *view);

static Diagnostic *
new_diagnostic (DiagnosticsView *view, const gchar *text, DiagnosticFunc func)
{
  Diagnostic *di;

  g_debug ("%s/%s: Adding diagnostic for %s", __FILE__, __FUNCTION__, text);

  di = g_new0 (Diagnostic, 1);
  di->perform_check = func;
  di->text = g_strdup (text);

  return di;
}

static void
diagnostics_view_finalize (GObject *object)
{
  DiagnosticsView *view = DIAGNOSTICS_VIEW (object);

  if (view->priv != NULL)
    {
      while (view->priv->diagnostics != NULL)
	{
	  Diagnostic *di = (Diagnostic *) view->priv->diagnostics->data;

	  view->priv->diagnostics = g_slist_remove (view->priv->diagnostics, di);
	  g_free (di->text);
	  g_free (di);
	}

      g_free (view->priv);
    }

  G_OBJECT_CLASS (diagnostics_view_parent_class)->finalize (object);
}

static void
diagnostics_view_class_init (DiagnosticsViewClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  object_class->finalize = diagnostics_view_finalize;

  /* Install signals */
  dv_signals[FINISHED_SIGNAL] = g_signal_new ("finished",
					      G_OBJECT_CLASS_TYPE (object_class),
					      G_SIGNAL_RUN_LAST,
					      G_STRUCT_OFFSET (DiagnosticsViewClass, finished),
					      NULL, NULL,
					      g_cclosure_marshal_VOID__BOOLEAN,
					      G_TYPE_NONE, 1, G_TYPE_BOOLEAN);
}

static void
diagnostics_view_init (DiagnosticsView *view)
{
  GtkWidget *w;

  view->priv = g_new0 (DiagnosticsViewPrivate, 1);

  w = gtk_label_new (_("<big><b>Performing diagnostics</b></big>\n\n"
                     "This program needs to check your system to determine what actions are possible.\n"));
  gtk_label_set_use_markup (GTK_LABEL (w), TRUE);
  gtk_label_set_line_wrap (GTK_LABEL (w), TRUE);
  gtk_misc_set_alignment (GTK_MISC (w), 0.0, 0.0);
  gtk_box_pack_start (GTK_BOX (view), w, FALSE, FALSE, 3);
  gtk_widget_show (w);

  w = gtk_scrolled_window_new (NULL, NULL);
  gtk_box_pack_start (GTK_BOX (view), w, TRUE, TRUE, 3);
  gtk_widget_show (w);

  view->priv->log_window = gtk_text_view_new ();
  gtk_text_view_set_editable (GTK_TEXT_VIEW (view->priv->log_window), FALSE);
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (view->priv->log_window), FALSE);
  gtk_text_view_set_left_margin (GTK_TEXT_VIEW (view->priv->log_window), 12);
  gtk_text_view_set_right_margin (GTK_TEXT_VIEW (view->priv->log_window), 12);
  gtk_container_add (GTK_CONTAINER (w), view->priv->log_window);
  gtk_widget_show (view->priv->log_window);

  gtk_text_buffer_create_tag (gtk_text_view_get_buffer (GTK_TEXT_VIEW (view->priv->log_window)), "error",
                              "weight", PANGO_WEIGHT_BOLD,
                              "foreground", "#FF0000",
                              NULL);
  gtk_text_buffer_create_tag (gtk_text_view_get_buffer (GTK_TEXT_VIEW (view->priv->log_window)), "success",
                              "weight", PANGO_WEIGHT_BOLD,
                              "foreground", "#00FF00",
                              NULL);

  view->priv->diagnostics = g_slist_append (view->priv->diagnostics,
                                            new_diagnostic (view, _("Checking if Intel graphics card available..."), intel_diagnostic));
  view->priv->diagnostics = g_slist_append (view->priv->diagnostics,
                                            new_diagnostic (view, _("Retrieving information from 01.org..."), config_file_diagnostic));
  view->priv->diagnostics = g_slist_append (view->priv->diagnostics,
                                            new_diagnostic (view, _("Checking distribution..."), distribution_diagnostic));
  view->priv->diagnostics = g_slist_append (view->priv->diagnostics,
                                            new_diagnostic (view, _("Checking kernel version..."), kernel_version_diagnostic));
  view->priv->diagnostics = g_slist_append (view->priv->diagnostics,
                                            new_diagnostic (view, _("Checking available repositories..."), repo_diagnostic));
  view->priv->diagnostics = g_slist_append (view->priv->diagnostics,
                                            new_diagnostic (view, _("Checking package manager status..."), pm_diagnostic));
}

GtkWidget *
diagnostics_view_new (void)
{
  return g_object_new (TYPE_DIAGNOSTICS_VIEW,
                       "orientation", GTK_ORIENTATION_VERTICAL,
                       NULL);
}

static gboolean
intel_diagnostic (DiagnosticsView *view)
{
#if VM_TEST
  return TRUE;
#else
  gchar *contents;
  gsize length;
  gboolean result = FALSE;

  if (g_file_get_contents ("/sys/module/i915/initstate", &contents, &length, NULL))
    {
      if (strncmp (contents, "live", 4) == 0)
	result = TRUE;
      else
	{
	  /* Card might not be in use, so maybe check PCI ids? */
	}

      g_free (contents);
    }

  if (!result)
    {
      display_error (GTK_WINDOW (gtk_widget_get_toplevel (GTK_WIDGET (view))),
		     _("You don’t seem to have an Intel i915 chipset so no updates are needed"));
    }

  return result;
#endif
}

static gboolean
config_file_diagnostic (DiagnosticsView *view)
{
  Configuration *config = get_configuration ();

  return config != NULL;
}

static gboolean
distribution_diagnostic (DiagnosticsView *view)
{
  PackageManager *manager;

  manager = package_manager_get ();
  if (manager != NULL)
    {
      if (package_manager_is_distro_supported (manager))
        return TRUE;
    }

  display_error (GTK_WINDOW (gtk_widget_get_toplevel (GTK_WIDGET (view))), _("Distribution not supported"));

  return FALSE;
}

static gboolean
kernel_version_diagnostic (DiagnosticsView *view)
{
  struct utsname kernel_info;

  if (uname (&kernel_info) == 0)
    {
      if (compare_versions (kernel_info.release, "3.2.0") >= 0)
        {
          return TRUE;
        }
      else
        {
          GtkWidget *widget = gtk_widget_get_toplevel (GTK_WIDGET (view));
          GtkWindow *window = GTK_WINDOW (widget);
          display_error (window, _("You are running kernel %s, which is too old and not supported"), kernel_info.release);
        }
    }

  display_error (GTK_WINDOW (gtk_widget_get_toplevel (GTK_WIDGET (view))), _("Could not determine the version of the running kernel"));
  return FALSE;
}

static gboolean
repo_diagnostic (DiagnosticsView *view)
{
  return TRUE;
}

static gboolean
pm_diagnostic (DiagnosticsView *view)
{
  PackageManager *manager;
  gboolean ret;
  gchar *msg = NULL;

  manager = package_manager_get ();
  /* This should not happen as we have a distro check before */
  g_return_val_if_fail (manager != NULL, FALSE);

  ret = package_manager_is_status_ok (manager, &msg);
  if (!ret)
    display_error (GTK_WINDOW (gtk_widget_get_toplevel (GTK_WIDGET (view))), "%s", msg);
  g_free (msg);

  return ret;
}

void
diagnostics_view_start (DiagnosticsView *view)
{
  GSList *l;
  GtkTextBuffer *buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (view->priv->log_window));

  gtk_text_buffer_set_text (buffer, "", 0);

  for (l = view->priv->diagnostics; l != NULL; l = l->next) {
    Diagnostic *di = (Diagnostic *) l->data;
    GtkTextIter iter;

    g_debug ("%s/%s: Running diagnostic %s", __FILE__, __FUNCTION__, di->text);

    if (di->perform_check != NULL)
      {
	/* Add text to the output window */
	gtk_text_buffer_insert_at_cursor (buffer, (const gchar *) di->text, strlen (di->text));
	if (!di->perform_check (view))
	  {
	    gtk_text_buffer_get_iter_at_offset (buffer, &iter, gtk_text_buffer_get_char_count (buffer));
	    gtk_text_buffer_insert_with_tags_by_name (buffer, &iter, " Failed\n", 8, "error", NULL);
	    g_signal_emit_by_name (view, "finished", FALSE);
	    return;
	  }
      }

    gtk_text_buffer_get_iter_at_offset (buffer, &iter, gtk_text_buffer_get_char_count (buffer));
    gtk_text_buffer_insert_with_tags_by_name (buffer, &iter, " OK\n", 4, "success", NULL);
  }

  g_signal_emit_by_name (view, "finished", TRUE);
}

void
diagnostics_view_add_postscript (DiagnosticsView *view, const gchar *text)
{
  if (view)
    {
      DiagnosticsViewPrivate *priv = view->priv;
      GtkTextView *gtv = GTK_TEXT_VIEW (priv->log_window);
      GtkTextBuffer *buffer = gtk_text_view_get_buffer (gtv);
      GtkTextIter iter;

      gtk_text_buffer_insert_at_cursor (buffer, text, strlen (text));
      gtk_text_buffer_get_iter_at_offset (buffer, &iter,
                                          gtk_text_buffer_get_char_count (buffer));
      gtk_text_view_scroll_to_iter (gtv, &iter, 0.1, TRUE, 0.0, 0.1);
    }
}

void
diagnostics_view_end_postscript (DiagnosticsView *view, const gchar *text)
{
  if (view)
    {
      DiagnosticsViewPrivate *priv = view->priv;
      GtkTextView *gtv = GTK_TEXT_VIEW (priv->log_window);
      GtkTextBuffer *buffer = gtk_text_view_get_buffer (gtv);
      GtkTextIter iter;

      gtk_text_buffer_get_iter_at_offset (buffer, &iter,
                                          gtk_text_buffer_get_char_count (buffer));

      gtk_text_buffer_insert_with_tags_by_name (buffer, &iter,
                                                text, strlen (text), "success",
                                                NULL);
      gtk_text_view_scroll_to_iter (gtv, &iter, 0.1, TRUE, 0.0, 0.1);
    }
}
