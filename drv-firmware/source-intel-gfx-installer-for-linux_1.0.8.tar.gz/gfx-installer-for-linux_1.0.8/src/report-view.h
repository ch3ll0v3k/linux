/*
 * Copyright © 2013 Intel Corporation
 *
 * Authors: Marco Barisione <marco.barisione@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _REPORT_VIEW_
#define _REPORT_VIEW_

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define TYPE_REPORT_VIEW                (report_view_get_type ())
#define REPORT_VIEW(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), TYPE_REPORT_VIEW, ReportView))
#define IS_REPORT_VIEW(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TYPE_REPORT_VIEW))
#define REPORT_VIEW_CLASS(klass)        (G_TYPE_CHECK_CLASS_CAST ((klass), TYPE_REPORT_VIEW, ReportViewClass))
#define IS_REPORT_VIEW_CLASS(klass)     (G_TYPE_CHECK_CLASS_TYPE ((klass), TYPE_REPORT_VIEW))
#define REPORT_VIEW_GET_CLASS(obj)      (G_TYPE_INSTANCE_GET_CLASS ((obj), TYPE_REPORT_VIEW, ReportViewClass))

typedef struct _ReportViewPrivate ReportViewPrivate;

typedef struct {
  GtkBox parent;

  ReportViewPrivate *priv;
} ReportView;

typedef struct {
  GtkBoxClass parent_class;
} ReportViewClass;

GType      report_view_get_type (void);

GtkWidget *report_view_new (void);
void       report_view_start (ReportView *view, GHashTable *packages_before, GHashTable *packages_after);

G_END_DECLS

#endif
