/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _MAIN_WINDOW_H_
#define _MAIN_WINDOW_H_

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define TYPE_MAIN_WINDOW                (main_window_get_type ())
#define MAIN_WINDOW(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), TYPE_MAIN_WINDOW, MainWindow))
#define IS_MAIN_WINDOW(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TYPE_MAIN_WINDOW))
#define MAIN_WINDOW_CLASS(klass)        (G_TYPE_CHECK_CLASS_CAST ((klass), TYPE_MAIN_WINDOW, MainWindowClass))
#define IS_MAIN_WINDOW_CLASS(klass)     (G_TYPE_CHECK_CLASS_TYPE ((klass), TYPE_MAIN_WINDOW))
#define MAIN_WINDOW_GET_CLASS(obj)      (G_TYPE_INSTANCE_GET_CLASS ((obj), TYPE_MAIN_WINDOW, MainWindowClass))

typedef struct _MainWindowPrivate MainWindowPrivate;

typedef struct {
  GtkDialog parent;

  MainWindowPrivate *priv;
} MainWindow;

typedef struct {
  GtkDialogClass parent_class;
} MainWindowClass;

GType      main_window_get_type (void);

GtkWindow *main_window_new (void);

void main_window_progress (MainWindow *win,
                           const gchar *action,
                           const gchar *msg,
                           gint percent,
                           gboolean spin);

G_END_DECLS

#endif
