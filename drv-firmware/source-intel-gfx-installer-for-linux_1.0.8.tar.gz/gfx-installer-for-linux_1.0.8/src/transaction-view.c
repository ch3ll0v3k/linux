/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *          Vivek Dasmohapatra <vivek.dasmohapatra@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <glib/gi18n.h>
#include "package-manager.h"
#include "transaction-view.h"
#include "utils.h"

G_DEFINE_TYPE (TransactionView, transaction_view, GTK_TYPE_BOX)

enum {
  FINISHED_SIGNAL,
  NEED_REBOOT_SIGNAL,
  LAST_SIGNAL
};
static guint tv_signals[LAST_SIGNAL];

typedef gboolean (* TransactionFunc) (TransactionView *view);

typedef struct {
  TransactionView *view;
  TransactionFunc perform_transaction;
  gchar *text;
  gboolean finished;
  gboolean failed;
} Transaction;

struct _TransactionViewPrivate {
  GSList *transactions;
  Transaction *current_transaction;
  GHashTable *packages_before;
  GHashTable *packages_after;
  GtkWidget *title_label;
  GtkWidget *log_window;
  gboolean destroyed;
  gboolean install_key;
  PackageManager *pm;
};

static void
clean_transactions (TransactionView *view)
{
  while (view->priv->transactions != NULL)
    {
      Transaction *xt = (Transaction *) view->priv->transactions->data;

      view->priv->transactions = g_slist_remove (view->priv->transactions, xt);
      g_free (xt->text);
      g_free (xt);
    }
}

static void
transaction_view_finalize (GObject *object)
{
  TransactionView *view = TRANSACTION_VIEW (object);

  if (view->priv != NULL)
    {
      clean_transactions (view);

      g_clear_pointer (&view->priv->packages_before, &g_hash_table_unref);
      g_clear_pointer (&view->priv->packages_after, &g_hash_table_unref);

      g_free (view->priv);
    }

  G_OBJECT_CLASS (transaction_view_parent_class)->finalize (object);
}

static void
transaction_view_class_init (TransactionViewClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  object_class->finalize = transaction_view_finalize;

  /* Install signals */
  tv_signals[FINISHED_SIGNAL] = g_signal_new ("finished",
					      G_OBJECT_CLASS_TYPE (object_class),
					      G_SIGNAL_RUN_LAST,
					      G_STRUCT_OFFSET (TransactionViewClass, finished),
					      NULL, NULL,
					      g_cclosure_marshal_VOID__BOOLEAN,
					      G_TYPE_NONE, 1, G_TYPE_BOOLEAN);

  tv_signals[NEED_REBOOT_SIGNAL] = g_signal_new ("need-reboot",
						 G_OBJECT_CLASS_TYPE (object_class),
						 G_SIGNAL_RUN_LAST,
						 0,
						 NULL, NULL,
						 g_cclosure_marshal_VOID__VOID,
						 G_TYPE_NONE, 0);
}

static Transaction *
new_transaction (TransactionView *view, const gchar *text, TransactionFunc func)
{
  Transaction *xt;

  xt = g_new0 (Transaction, 1);
  xt->view = view;
  xt->perform_transaction = func;
  xt->text = g_strdup (text);
  xt->finished = FALSE;
  xt->failed = FALSE;

  return xt;
}

static void
log_window_insert (TransactionView *view, const gchar *msg, const gchar *tag_name)
{
  GtkTextBuffer *buffer;
  GtkTextIter iter;
  GtkTextMark *mark;

  buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (view->priv->log_window));
  gtk_text_buffer_get_end_iter (buffer, &iter);
  mark = gtk_text_buffer_create_mark (buffer, NULL, &iter, FALSE);

  gtk_text_buffer_insert_with_tags_by_name (buffer, &iter, msg, -1, tag_name, NULL);
  /* Scroll to the end */
  gtk_text_view_scroll_mark_onscreen (GTK_TEXT_VIEW (view->priv->log_window), mark);

  gtk_text_buffer_delete_mark (buffer, mark);
}

static void
on_pm_op_failed (PackageManager *pm, const gchar *msg, gpointer user_data)
{
  GtkWidget *top = NULL;
  Transaction *xt = (Transaction *) user_data;

  g_debug ("%s/%s: Package manager operation failed: %s", __FILE__, __FUNCTION__, msg);

  xt->finished = TRUE;
  xt->failed = TRUE;

  if (xt->view == NULL || xt->view->priv == NULL || xt->view->priv->destroyed)
    return;

  top = gtk_widget_get_toplevel (GTK_WIDGET (xt->view));

  if (top == NULL)
    return;

  display_error (GTK_WINDOW (top), "%s", msg);
  update_progress_details (NULL, msg, -1, 0);
}

static void
on_pm_op_finished (PackageManager *pm, gpointer user_data)
{
  Transaction *xt = (Transaction *) user_data;

  g_debug ("%s/%s: Package manager operation finished", __FILE__, __FUNCTION__);

  update_progress_details (NULL, "Complete", 101, 0);

  xt->finished = TRUE;
}

static void
on_pm_progress (PackageManager *pm, const gchar *msg, gpointer user_data)
{
  Transaction *xt = (Transaction *) user_data;

  if (xt->view == NULL ||
      xt->view->priv == NULL ||
      xt->view->priv->log_window == NULL ||
      xt->view->priv->destroyed)
    return;

  g_debug ("%s/%s: Package manager operation progress: %s", __FILE__, __FUNCTION__, msg);

  log_window_insert (xt->view, "\n\t", NULL);
  log_window_insert (xt->view, msg, NULL);
}

typedef struct {
    Transaction *xt;
    GHashTable **packages_out;
} PackageListData;

static void
on_pm_op_list_packages_finished (PackageManager *pm, GHashTable *packages, gpointer user_data)
{
  PackageListData *data = user_data;

  *(data->packages_out) = g_hash_table_ref (packages);

  on_pm_op_finished (pm, data->xt);
}

static gboolean
list_transaction (TransactionView *view, GHashTable **packages_out)
{
  gboolean result = FALSE;
  Transaction *xt = view->priv->current_transaction;
  PackageListData package_list_data;

  if (view->priv->destroyed)
    return FALSE;

  g_return_val_if_fail (packages_out != NULL && *packages_out == NULL, FALSE);

  package_list_data.xt = xt;
  package_list_data.packages_out = packages_out;

  g_signal_connect (view->priv->pm, "error", G_CALLBACK (on_pm_op_failed), xt);
  g_signal_connect (view->priv->pm, "progress", G_CALLBACK (on_pm_progress), xt);
  g_signal_connect (view->priv->pm, "list-packages-finished",
      G_CALLBACK (on_pm_op_list_packages_finished), &package_list_data);

  /* We don't have any update for the progress of this operation, so we show
   * the spinner, but no progress */
  update_progress_details ("List packages", "", 101, TRUE);

  if (package_manager_list_packages (view->priv->pm))
    {
      while (!xt->finished)
	{
	  while (gtk_events_pending ())
	    gtk_main_iteration ();
	}

      result = !xt->failed;
    }

  if (view->priv->destroyed)
    return FALSE;

  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_failed, xt);
  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_progress, xt);
  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_list_packages_finished, &package_list_data);

  return result;
}

static gboolean
list_before_transaction (TransactionView *view)
{
  return list_transaction (view, &view->priv->packages_before);
}

static gboolean
list_after_transaction (TransactionView *view)
{
  return list_transaction (view, &view->priv->packages_after);
}

static gboolean
cleanup_transaction (TransactionView *view)
{
  g_signal_emit_by_name (view, "need-reboot");
  update_progress_details (NULL, NULL, 100, 0);

  return TRUE;
}

static gboolean
downgrade_transaction (TransactionView *view)
{
  gboolean result = FALSE;
  Transaction *xt = view->priv->current_transaction;

  if (view->priv->destroyed)
    return FALSE;

  g_signal_connect (view->priv->pm, "error", G_CALLBACK (on_pm_op_failed), xt);
  g_signal_connect (view->priv->pm, "progress", G_CALLBACK (on_pm_progress), xt);
  g_signal_connect (view->priv->pm, "cleanup-finished", G_CALLBACK (on_pm_op_finished), xt);

  update_progress_details ("Uninstall", "", 0, 0);

  if (package_manager_clean (view->priv->pm))
    {
      while (!xt->finished)
	{
	  while (gtk_events_pending ())
	    gtk_main_iteration ();
	}

      result = !xt->failed;
    }

  if (view->priv->destroyed)
    return FALSE;

  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_failed, xt);
  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_progress, xt);
  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_finished, xt);

  return result;
}

static gboolean
pre_install_transaction (TransactionView *view)
{
  gboolean result = FALSE;
  Transaction *xt = view->priv->current_transaction;

  if (view->priv->destroyed)
    return FALSE;

  g_signal_connect (view->priv->pm, "error", G_CALLBACK (on_pm_op_failed), xt);
  g_signal_connect (view->priv->pm, "progress", G_CALLBACK (on_pm_progress), xt);
  g_signal_connect (view->priv->pm, "pre-install-finished", G_CALLBACK (on_pm_op_finished), xt);

  update_progress_details ("Pre-install", "", 0, 0);

  if (package_manager_pre_install (view->priv->pm))
    {
      while (!xt->finished)
        {
          while (gtk_events_pending ())
            gtk_main_iteration ();
        }

      result = !xt->failed;
    }

  if (view->priv->destroyed)
    return FALSE;

  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_failed, xt);
  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_progress, xt);
  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_finished, xt);

  return result;
}

static gboolean
install_transaction (TransactionView *view)
{
  gboolean result = FALSE;
  Transaction *xt = view->priv->current_transaction;

  if (view->priv->destroyed)
    return FALSE;

  g_signal_connect (view->priv->pm, "error", G_CALLBACK (on_pm_op_failed), xt);
  g_signal_connect (view->priv->pm, "progress", G_CALLBACK (on_pm_progress), xt);
  g_signal_connect (view->priv->pm, "transaction-finished", G_CALLBACK (on_pm_op_finished), xt);

  update_progress_details ("Install", "", 0, 0);

  if (package_manager_run_transaction (view->priv->pm))
    {
      while (!xt->finished)
	{
	  while (gtk_events_pending ())
	    gtk_main_iteration ();
	}

      result = !xt->failed;
    }

  if (view->priv->destroyed)
    return FALSE;

  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_failed, xt);
  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_progress, xt);
  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_finished, xt);

  return result;
}

static gboolean
setup_repo_transaction (TransactionView *view)
{
  gboolean result = FALSE;
  Transaction *xt = view->priv->current_transaction;

  if (view->priv->destroyed)
    return FALSE;

  g_signal_connect (view->priv->pm, "error", G_CALLBACK (on_pm_op_failed), xt);
  g_signal_connect (view->priv->pm, "setup-finished", G_CALLBACK (on_pm_op_finished), xt);

  update_progress_details ("Setup", "", 0, 0);

  if (package_manager_setup (view->priv->pm, view->priv->install_key))
    {
      while (!xt->finished)
	{
	  while (gtk_events_pending ())
	    gtk_main_iteration ();
	}

      result = !xt->failed;
    }

  if (view->priv->destroyed)
    return FALSE;

  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_failed, xt);
  g_signal_handlers_disconnect_by_func (view->priv->pm, on_pm_op_finished, xt);

  return result;
}

static gboolean
on_destruction (GtkWidget *widget, gpointer data)
{
  TransactionView *view = data;

  view->priv->destroyed = TRUE;

  if (view->priv->current_transaction != NULL)
    {
      view->priv->current_transaction->failed = TRUE;
      view->priv->current_transaction->finished = TRUE;
    }

  if (view->priv->pm != NULL)
    g_clear_object (&view->priv->pm);

  return FALSE;
}

#define DEFAULT_TITLE_LABEL _("<big><b>Upgrading system</b></big>\n\nPlease wait while the program upgrades your system to the latest Intel graphics stack.\n")

static void
transaction_view_init (TransactionView *view)
{
  GtkWidget *w;

  view->priv = g_new0 (TransactionViewPrivate, 1);

  view->priv->pm = package_manager_get ();

  g_signal_connect (GTK_BOX (view), "destroy",
                    G_CALLBACK (on_destruction), view);

  view->priv->title_label = gtk_label_new (DEFAULT_TITLE_LABEL);
  gtk_label_set_use_markup (GTK_LABEL (view->priv->title_label), TRUE);
  gtk_label_set_line_wrap (GTK_LABEL (view->priv->title_label), TRUE);
  gtk_misc_set_alignment (GTK_MISC (view->priv->title_label), 0.0, 0.0);
  gtk_box_pack_start (GTK_BOX (view), view->priv->title_label, FALSE, FALSE, 3);
  gtk_widget_show (view->priv->title_label);

  w = gtk_scrolled_window_new (NULL, NULL);
  gtk_scrolled_window_set_min_content_height (GTK_SCROLLED_WINDOW (w), 128);
  gtk_box_pack_start (GTK_BOX (view), w, TRUE, TRUE, 3);
  gtk_widget_show (w);

  view->priv->log_window = gtk_text_view_new ();
  gtk_text_view_set_editable (GTK_TEXT_VIEW (view->priv->log_window), FALSE);
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (view->priv->log_window), FALSE);
  gtk_text_view_set_left_margin (GTK_TEXT_VIEW (view->priv->log_window), 12);
  gtk_text_view_set_right_margin (GTK_TEXT_VIEW (view->priv->log_window), 12);
  gtk_container_add (GTK_CONTAINER (w), view->priv->log_window);
  gtk_widget_show (view->priv->log_window);

  gtk_text_buffer_create_tag (gtk_text_view_get_buffer (GTK_TEXT_VIEW (view->priv->log_window)), "error",
			      "weight", PANGO_WEIGHT_BOLD,
			      "foreground", "#FF0000",
			      NULL);
  gtk_text_buffer_create_tag (gtk_text_view_get_buffer (GTK_TEXT_VIEW (view->priv->log_window)), "success",
			      "weight", PANGO_WEIGHT_BOLD,
			      "foreground", "#00FF00",
			      NULL);
}

GtkWidget *
transaction_view_new (void)
{
  return g_object_new (TYPE_TRANSACTION_VIEW,
		       "orientation", GTK_ORIENTATION_VERTICAL,
		       NULL);
}

void
transaction_view_start (TransactionView *view, gboolean uninstall, gboolean install_key)
{
  GSList *l;
  GtkTextBuffer *buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (view->priv->log_window));

  view->priv->install_key = install_key;

  clean_transactions (view);
  gtk_text_buffer_set_text (buffer, "", 0);

  /* Add transactions to perform */
  if (!uninstall)
    {
      /* Don't try and cleanup if we're just about to unistall */
      view->priv->transactions = g_slist_append (view->priv->transactions,
                                                 new_transaction (view, _("Ensuring consistent system..."), pre_install_transaction));
    }

  view->priv->transactions = g_slist_append (view->priv->transactions,
                                             new_transaction (view, _("Listing packages..."), list_before_transaction));
  if (uninstall)
    {
      view->priv->transactions = g_slist_append (view->priv->transactions,
						 new_transaction (view, _("Downgrading packages..."), downgrade_transaction));

      gtk_label_set_markup (GTK_LABEL (view->priv->title_label),
			    _("<big><b>Uninstalling Intel Graphics for Linux</b></big>\n\n"
			      "Please wait while the program uninstalls the Intel graphics stack.\n"));
    }
  else
    {
      view->priv->transactions = g_slist_append (view->priv->transactions,
						 new_transaction (view, _("Setting up repositories..."), setup_repo_transaction));
      view->priv->transactions = g_slist_append (view->priv->transactions,
						 new_transaction (view, _("Installing packages..."), install_transaction));

      gtk_label_set_markup (GTK_LABEL (view->priv->title_label), DEFAULT_TITLE_LABEL);
    }

  view->priv->transactions = g_slist_append (view->priv->transactions,
					     new_transaction (view, _("Cleaning up..."), cleanup_transaction));
  view->priv->transactions = g_slist_append (view->priv->transactions,
                                             new_transaction (view, _("Listing packages..."), list_after_transaction));

  for (l = view->priv->transactions; l != NULL; l = l->next)
    {
      Transaction *xt = (Transaction *) l->data;

      update_progress_details (xt->text, "…", 0, 1);

      view->priv->current_transaction = xt;
      g_debug ("%s/%s: Running transaction %s", __FILE__, __FUNCTION__, xt->text);

      if (xt->perform_transaction != NULL)
        {
          /* Add text to the output window */
          log_window_insert (view, xt->text, NULL);
          if (!xt->perform_transaction (view))
            {
              if (view->priv->destroyed)
                return;

              log_window_insert (view, " Failed\n", "error");
              g_signal_emit_by_name (view, "finished", FALSE);

              update_progress_details (xt->text, "Failed", -1, 0);
              return;
            }
        }

      update_progress_details (xt->text, "Complete", 101, 0);
      log_window_insert (view, " OK\n", "success");
    }

  g_signal_emit_by_name (view, "finished", TRUE);
}

void
transaction_view_get_package_lists (TransactionView *view, GHashTable **before, GHashTable **after)
{
  g_return_if_fail (IS_TRANSACTION_VIEW (view));
  g_return_if_fail (before != NULL);
  g_return_if_fail (after != NULL);

  *before = view->priv->packages_before;
  *after = view->priv->packages_after;
}
