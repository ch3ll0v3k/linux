/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *          Vivek Dasmohapatra <vivek.dasmohapatra@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <ctype.h>
#include <sys/utsname.h>
#include "config.h"
#include "utils.h"

static gboolean parse_cfg_line (Configuration *cfg, const gchar *line);

static Configuration *the_config = NULL;

static inline const gchar *
cfg_payload (const gchar *line)
{
  gchar *payload = (gchar *) line;

  while (*payload && !isspace (*payload++));
  while (*payload && isspace (*payload)) payload++;

  return payload;
}

static void
add_error (Configuration *cfg, const gchar *message)
{
  if (cfg->errors == NULL)
    cfg->errors = g_ptr_array_new_with_free_func (g_free);

  g_ptr_array_add (cfg->errors, g_strdup (message));
}

static void
add_item (GPtrArray *list, const gchar *item)
{
  gchar *trimmed = g_strdup (item);
  g_ptr_array_add(list, g_strstrip (trimmed));
}

static void
kernel_check (Configuration *cfg, const gchar *cmd)
{
  static GRegex *parser = NULL;
  GMatchInfo *matched = NULL;
  static struct utsname kernel;

  if (parser == NULL)
    {
      parser = g_regex_new ("([0-9.]+)\\s+([0-9.]+)\\s+(.*)", 0, 0, NULL);
      uname (&kernel);
    }

  if (g_regex_match (parser, cmd, 0, &matched))
    {
      gchar *vermin = g_match_info_fetch (matched, 1);
      gchar *vermax = g_match_info_fetch (matched, 2);

      if (compare_versions (vermin, kernel.release) <= 0 &&
          compare_versions (vermax, kernel.release) >  0)
        {
          gchar *cmd_line = g_match_info_fetch (matched, 3);

          parse_cfg_line (cfg, cmd_line);

          g_free (cmd_line);
        }

      g_free (vermin);
      g_free (vermax);
    }

  g_match_info_unref (matched);
}

static gboolean
parse_cfg_line (Configuration *cfg, const gchar *line)
{
  GPtrArray *target = NULL;
  gboolean proceed = TRUE;

  switch (*line)
    {
      case 'e':
        add_error (cfg, cfg_payload (line));
        break;
      case 'k':
        kernel_check (cfg, cfg_payload (line));
        break;
      case 'I':
        target = cfg->install_only;
        break;
      case 'i':
        target = cfg->install;
        break;
      case 's':
        target = cfg->sources;
        break;
      case 'u':
        target = cfg->upgrade;
        break;
      case 'g':
        target = cfg->keys;
        break;
      case 'd':
        target = cfg->docs;
        break;
      case 'n':
      case '#':
      case '\n':
      case '\0':
        break;
      case '[':
        proceed = FALSE;
        break;
      default:
        g_warning ("Unrecognised config instruction: %s (%d)", line, *line);
    }

  if (target)
    add_item (target, cfg_payload (line));

  return proceed;
}

static void
debug_ptr_array (const gchar *label, GPtrArray *list)
{
  if (list)
    {
      guint i;

      fprintf (stderr, "  %s: [", label);

      for (i = 0; i < list->len; i++)
        fprintf(stderr, "%s%s",
                (gchar *) g_ptr_array_index (list, i),
                (i == list->len - 1) ? "" : " ");

      fprintf (stderr, "]\n");
    }
  else
    {
      fprintf (stderr, "  %s: (nil)\n", label);
    }
}

static void
debug_configuration (Configuration *cfg)
{
  fprintf (stderr, "{\n");
  debug_ptr_array ("errors" , cfg->errors);
  debug_ptr_array ("sources", cfg->sources);
  debug_ptr_array ("keys", cfg->keys);
  debug_ptr_array ("docs", cfg->docs);
  debug_ptr_array ("INSTALL", cfg->install_only);
  debug_ptr_array ("install", cfg->install);
  debug_ptr_array ("upgrade", cfg->upgrade);
  fprintf (stderr, "}\n");
}

Configuration *
get_configuration (void)
{
  if (!the_config)
    {
      gchar *conffile = NULL;
      GError *error = NULL;

      conffile = g_build_path ("/", g_get_home_dir (), ".ilg-config", NULL);
      if (http_download_file (CONFIG_URI, conffile, &error))
	{
	  gchar *contents = NULL;

	  if (g_file_get_contents (conffile, &contents, NULL, NULL))
	    {
	      Distribution *distro = NULL;
	      GStrv cfg = g_strsplit (contents, "\n", -1);
	      gchar *ident = NULL;
	      guint i = 0;

	      the_config = g_new0 (Configuration, 1);
	      distro = get_distro_information ();
	      ident = g_strdup_printf ("[%s %s]", distro->distributor, distro->codename);

	      the_config->sources = g_ptr_array_new_with_free_func (g_free);
	      the_config->keys = g_ptr_array_new_with_free_func (g_free);
	      the_config->docs = g_ptr_array_new_with_free_func (g_free);
	      the_config->install = g_ptr_array_new_with_free_func (g_free);
	      the_config->upgrade = g_ptr_array_new_with_free_func (g_free);
	      the_config->install_only = g_ptr_array_new_with_free_func (g_free);

	      for (i = 0; cfg[i] != NULL; i++)
		if (g_str_has_prefix (cfg[i], ident))
		  break;

              if (cfg[i] != NULL)
                for (i = i + 1; cfg[i] != NULL && *cfg[i]; i++)
                  if (!parse_cfg_line (the_config, cfg[i]))
                    break;

	      g_free (ident);
	      g_strfreev (cfg);
              g_free (contents);
	    }
	}
      else
        {
          g_warning ("Failed to download config file '%s'\n", CONFIG_URI);
        }

      g_free (conffile);
    }

  if (the_config)
    debug_configuration (the_config);

  return the_config;
}

