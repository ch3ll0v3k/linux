/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *          Vivek Dasmohapatra <vivek.dasmohapatra@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _PACKAGE_MANAGER_H_
#define _PACKAGE_MANAGER_H_

#include <glib-object.h>
#include "utils.h"
#include "diagnostics-view.h"

#ifndef I_KNOW_THE_PACKAGEKIT_GLIB2_API_IS_SUBJECT_TO_CHANGE
#define I_KNOW_THE_PACKAGEKIT_GLIB2_API_IS_SUBJECT_TO_CHANGE
#endif
#include <packagekit-glib2/packagekit.h>

G_BEGIN_DECLS

#define TYPE_PACKAGE_MANAGER                (package_manager_get_type ())
#define PACKAGE_MANAGER(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), TYPE_PACKAGE_MANAGER, PackageManager))
#define IS_PACKAGE_MANAGER(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TYPE_PACKAGE_MANAGER))
#define PACKAGE_MANAGER_CLASS(klass)        (G_TYPE_CHECK_CLASS_CAST ((klass), TYPE_PACKAGE_MANAGER, PackageManagerClass))
#define IS_PACKAGE_MANAGER_CLASS(klass)     (G_TYPE_CHECK_CLASS_TYPE ((klass), TYPE_PACKAGE_MANAGER))
#define PACKAGE_MANAGER_GET_CLASS(obj)      (G_TYPE_INSTANCE_GET_CLASS ((obj), TYPE_PACKAGE_MANAGER, PackageManagerClass))

typedef struct _PackageManagerPrivate PackageManagerPrivate;

typedef struct {
  GObject parent;
  PackageManagerPrivate *priv;
} PackageManager;

typedef struct {
  GObjectClass parent_class;

  /* virtual methods */
  gboolean (* is_setup) (PackageManager *manager);
  gboolean (* is_distro_supported) (PackageManager *manager, Configuration *orders);
  gboolean (* pre_install) (PackageManager *manager);
  gboolean (* setup) (PackageManager *manager, gboolean install_key);
  gboolean (* run_transaction) (PackageManager *manager);
  gboolean (* clean) (PackageManager *manager);
  gboolean (* is_system_upgraded) (PackageManager *manager, DiagnosticsView *v);
  void (* clean_transactions) (PackageManager *manager); /* protected */
  gboolean (* is_status_ok) (PackageManager *manager, gchar **error_msg);

  /* signals */
  void (* error) (PackageManager *manager, const gchar *msg);
  void (* progress) (PackageManager *manager, const gchar *msg);
  void (* detail)  (PackageManager *manager, const gchar *act, const gchar *msg, gint percent);
  void (* pre_install_finished) (PackageManager *manager);
  void (* setup_finished) (PackageManager *manager);
  void (* transaction_finished) (PackageManager *manager);
  void (* cleanup_finished) (PackageManager *manager);
  void (* list_packages_finished) (PackageManager *manager, gpointer dunno);
  
} PackageManagerClass;

GType           package_manager_get_type (void);

PackageManager *package_manager_get (void);
gboolean        package_manager_is_setup (PackageManager *manager);
gboolean        package_manager_is_distro_supported (PackageManager *manager);
gboolean        package_manager_pre_install (PackageManager *manager);
gboolean        package_manager_setup (PackageManager *manager, gboolean install_key);
gboolean        package_manager_run_transaction (PackageManager *manager);
gboolean        package_manager_clean (PackageManager *manager);
gboolean        package_manager_is_system_upgraded (PackageManager *manager, DiagnosticsView *v);
gboolean        package_manager_list_packages (PackageManager *manager);
gboolean        package_manager_is_status_ok (PackageManager *manager, gchar **error_msg);

gboolean        package_manager_check_pk_permission (PackageManager *manager, const gchar *action_id);

PkClient       *package_manager_get_pk_client (PackageManager *manager);

G_END_DECLS

#endif
