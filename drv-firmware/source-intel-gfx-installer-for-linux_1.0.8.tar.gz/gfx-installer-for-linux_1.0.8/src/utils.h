/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *          Vivek Dasmohapatra <vivek.dasmohapatra@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _UTILS_H_
#define _UTILS_H_

#include <gtk/gtk.h>

#define OFDBUS "org.freedesktop.DBus"

void display_error (GtkWindow *parent, const gchar *format, ...) G_GNUC_PRINTF(2, 3);

typedef struct {
  gchar *distributor;
  gchar *description;
  gchar *release;
  gchar *codename;
} Distribution;

Distribution *get_distro_information (void);
gboolean      http_download_file (const gchar *uri, const gchar *output, GError **error);

gint          compare_versions (const gchar *ver0, const gchar *ver1);

typedef struct {
  GPtrArray *errors;
  GPtrArray *sources;
  GPtrArray *keys;
  GPtrArray *docs;
  GPtrArray *install_only;
  GPtrArray *install;
  GPtrArray *upgrade;
} Configuration;

Configuration *get_configuration (void);
const gchar *get_proxy_url (const gchar *type, const gchar *url);

#ifndef NO_GUI
#define update_progress_details(a, b, c, d) \
    _update_progress_details (__func__, a, b, c, d)

void _update_progress_details (const gchar *where,
                               const gchar *action,
                               const gchar *msg,
                               gint percent,
                               gboolean spin);
#endif // NO_GUI
#endif
