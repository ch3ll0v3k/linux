/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _TRANSACTION_VIEW_
#define _TRANSACTION_VIEW_

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define TYPE_TRANSACTION_VIEW                (transaction_view_get_type ())
#define TRANSACTION_VIEW(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), TYPE_TRANSACTION_VIEW, TransactionView))
#define IS_TRANSACTION_VIEW(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TYPE_TRANSACTION_VIEW))
#define TRANSACTION_VIEW_CLASS(klass)        (G_TYPE_CHECK_CLASS_CAST ((klass), TYPE_TRANSACTION_VIEW, TransactionViewClass))
#define IS_TRANSACTION_VIEW_CLASS(klass)     (G_TYPE_CHECK_CLASS_TYPE ((klass), TYPE_TRANSACTION_VIEW))
#define TRANSACTION_VIEW_GET_CLASS(obj)      (G_TYPE_INSTANCE_GET_CLASS ((obj), TYPE_TRANSACTION_VIEW, TransactionViewClass))

typedef struct _TransactionViewPrivate TransactionViewPrivate;

typedef struct {
  GtkBox parent;

  TransactionViewPrivate *priv;
} TransactionView;

typedef struct {
  GtkBoxClass parent_class;

  /*< signals >*/
  void (* finished) (TransactionView *view, gboolean success);
} TransactionViewClass;

GType      transaction_view_get_type (void);

GtkWidget *transaction_view_new (void);
void       transaction_view_start (TransactionView *view, gboolean uninstall, gboolean install_key);
void       transaction_view_get_package_lists (TransactionView *view, GHashTable **before, GHashTable **after);

G_END_DECLS

#endif
