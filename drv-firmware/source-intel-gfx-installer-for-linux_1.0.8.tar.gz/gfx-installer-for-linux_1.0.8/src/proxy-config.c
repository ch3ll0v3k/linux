/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Vivek Dasmohapatra <vivek@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <stdlib.h>
#include <ctype.h>
#include "utils.h"

/* dconf proxy settings are stored as /system/proxy/TYPE/{host,port} *
 * port is optional, but can be set even if host is not (which is    *
 * meaningless, and should be ignored:                               */
#define UNPROXIED "direct:"
#define DCP "/system/proxy/"
#define DC_HOSTPORT(i) DCP #i "/host", DCP #i "/port"

typedef struct
{
  const gchar *setting;
  const gchar *mode;
  const gchar const *keys[3];
} dconf_map;

typedef struct
{
  const gchar *setting;
  const gchar *key;
} env_map;

/* which environment variable should we lookat for a given proxy setting? */
static const gchar *
proxy_type_to_env_var (const gchar *type)
{
  guint i;
  static const env_map setting_map[] =
    { { "http" , "http_proxy"  },
      { "https", "https_proxy" },
      { "ftp"  , "ftp_proxy"   },
      { "socks", "all_proxy"   },
      { "no"   , "no_proxy"    },
      { NULL   , NULL          } } ;

  for (i = 0; setting_map[i].setting; i++)
    if (g_strcmp0 (setting_map[i].setting, type) == 0)
      break;

  return setting_map[i].key;
}

/* some of these paths changed from earlier versions of gnome (- vs _)
 * but testing indicates all our targets use the newer paths: */
static const dconf_map const *
proxy_type_to_dconf_paths (const gchar *setting)
{
  guint i;
  static const dconf_map setting_map[] =
    { { "http" , "manual", { DC_HOSTPORT (http ) , NULL } },
      { "https", "manual", { DC_HOSTPORT (https) , NULL } },
      { "ftp"  , "manual", { DC_HOSTPORT (ftp  ) , NULL } },
      { "socks", "manual", { DC_HOSTPORT (socks) , NULL } },
      { "no"   , "manual", { DCP "ignore-hosts"  , NULL } },
      { "PAC"  , "auto"  , { DCP "autoconfig-url", NULL } },
      { NULL   , NULL    , { NULL } } } ;

  for (i = 0; setting_map[i].setting != NULL; i++)
    if (g_strcmp0 (setting_map[i].setting, setting) == 0)
      break;

  return &setting_map[i];
}

/* The dlopen() approach allows us to work with both u12.04 and .10,  *
 * and f17 and f18, with a single binary, and to cope gracefully when *
 * there's no dconf, without adding dependencies:                     */
typedef gpointer   (*dc_client0) (gpointer, gpointer, gpointer, gpointer);
typedef gpointer   (*dc_client1) (void);
typedef GVariant * (*dc_read)    (gpointer, const gchar *);

static gchar *
get_dconf_proxy_setting (const gchar *type)
{
  static gboolean tried = FALSE;
  static gboolean ready = FALSE;
  static gpointer dc;
  static gpointer dcclient_new = NULL;
  static gpointer dcread_value = NULL;
  static GModule *dconf = NULL;
  static gint dcversion = -1;

  gchar *url = NULL;

  while (!tried)
    {
      tried = TRUE;

      if (dconf = g_module_open ("libdconf.so.1", G_MODULE_BIND_LOCAL))
        dcversion = 1;
      else if (dconf = g_module_open ("libdconf.so.0", G_MODULE_BIND_LOCAL))
        dcversion = 0;

      if (dcversion < 0)
        goto no_dconf;

      if (!g_module_symbol (dconf, "dconf_client_new", &dcclient_new) ||
          !g_module_symbol (dconf, "dconf_client_read", &dcread_value))
        goto no_api;

      /* API changed [a bit] between libdconf0 and 1: */
      switch (dcversion)
        {
          case 0:
            dc = ((dc_client0) dcclient_new) (NULL, NULL, NULL, NULL);
            break;
          case 1:
            dc = ((dc_client1) dcclient_new) ();
            break;
          default:
            g_assert_not_reached ();
        }

      if (!dc)
        goto no_client;

      ready = TRUE;

      break;

    no_client:
      dcclient_new = NULL;
      dcread_value = NULL;
      g_debug ("could not initialise libdconf client");
    no_api:
      if (dconf)
        g_module_close (dconf);
      g_debug ("libdconf missing expected API (corrupted system?)");
    no_dconf:
      g_debug ("no supported libdconf available");
    }

  if (ready)
    {
      guint i;
      gboolean go = TRUE;
      const dconf_map const *map = proxy_type_to_dconf_paths (type);
      const gchar *const *paths = map->keys;
      GString *URL = NULL;
      GVariant *mode = NULL;

      /* if we have a proxy mode, it must match the one for which the *
       * dconf setting is actually valid, or we can ignore it:        */
      if (mode = ((dc_read) dcread_value) (dc, "/system/proxy/mode"))
        {
          if (g_variant_is_of_type (mode, G_VARIANT_TYPE_STRING))
            if (g_strcmp0 (map->mode, g_variant_get_string (mode, NULL)))
              go = FALSE;

          g_variant_unref (mode);
        }

      for (i = 0; paths && go && paths[i]; i++)
        {
          const gchar *sbuf = NULL;
          gchar *vbuf = NULL;
          gsize len = -1;
          GVariant *val = NULL;

          g_debug ("reading %s", paths[i]);

          if (!(val = ((dc_read) dcread_value) (dc, paths[i])))
            continue;

          if (g_variant_is_of_type (val, G_VARIANT_TYPE_STRING))
            sbuf = g_variant_get_string (val, &len);
          else
            vbuf = g_variant_print (val, FALSE);

          g_debug ("read %s = %s", paths[i], sbuf ? sbuf : vbuf);

          /* If the first element is empty, the subsequent ones mean nothing */
          if (i == 0)
            {
              if (len > 0)
                URL = g_string_new (sbuf);
              else
                go = FALSE;
            }
          else if (sbuf && g_utf8_strlen (sbuf, -1))
            {
              g_assert (URL != NULL);
              g_string_append_c (URL, ':');
              g_string_append (URL, sbuf);
            }
          else if (vbuf && g_utf8_strlen (vbuf, -1))
            {
              /* once it's been set, the user cannot easily blank it *
               * through the network settings UI: It gets set to 0   */
              if (g_strcmp0 (vbuf, "0"))
                {
                  g_assert (URL != NULL);
                  g_string_append_c (URL, ':');
                  g_string_append (URL, vbuf);
                }
            }

          g_free (vbuf);
          g_variant_unref (val);
        }

      if (URL)
        url = g_string_free (URL, FALSE);
    }

  return url;
}

/* proxy list not allocated by glib allocator, use free() directly
 * and copy the one we want into a char[] allocated by glib */
static gchar *
free_proxies (gchar **plist)
{
  gchar *rv = g_strdup (plist[0]);

  for (guint p = 0; plist[p]; p++)
    free (plist[p]);

  free (plist);

  return rv;
}

typedef gpointer (*px_engine) (void);
typedef char **  (*px_lookup) (gpointer, gchar *target);

static gchar *
get_libproxy_setting (const gchar *target)
{
  static gpointer pf = NULL;
  static gboolean tried = FALSE;
  static gboolean ready = FALSE;
  static gpointer pxengine = NULL;
  static gpointer pxlookup = NULL;
  static GModule *proxy = NULL;
  static gint pxversion = -1;

  while (!tried)
    {
      tried = TRUE;

      if (proxy = g_module_open ("libproxy.so.1", G_MODULE_BIND_LOCAL))
        pxversion = 1;
      else if (proxy = g_module_open ("libproxy.so.0", G_MODULE_BIND_LOCAL))
        pxversion = 0;

      if (pxversion < 0)
        goto no_proxy;

      if (!g_module_symbol (proxy, "px_proxy_factory_new", &pxengine) ||
          !g_module_symbol (proxy, "px_proxy_factory_get_proxies", &pxlookup))
        goto no_api;

     switch (pxversion)
        {
          case 0:
          case 1:
            pf = ((px_engine) pxengine) ();
            break;
          default:
            g_assert_not_reached ();
        }

      if (!pf)
        goto no_client;

      ready = TRUE;

      break;

    no_client:
      pxengine = NULL;
      pxlookup = NULL;
      g_debug ("could not initialise libproxy engine");
    no_api:
      if (proxy)
        g_module_close (proxy);
      g_debug ("libproxy missing expected API (corrupted system?)");
    no_proxy:
      g_debug ("no supported libproxy available");
    }

  if (ready)
    {
      char **proxies = ((px_lookup) pxlookup) (pf, (gchar *)target);

      g_debug ("looking up %s proxy via libproxy%d: %s",
               target, pxversion, proxies ? proxies[0] : "-none-");

      if (proxies)
        return free_proxies (proxies);
    }

  return NULL;
}

static const gchar *
cache_proxy (GHashTable *cache, const gchar *type, const gchar *value)
{
  g_hash_table_insert (cache, g_strdup (type), (gpointer) value);

  return value;
}

/* libproxy can be a little too fussy about whether it thinks it should
 * read the gnome proxy settings (fails if certain X clients are missing)
 * We can work around this by poking the PAC proxy into the environment: */
static void fake_pac (gboolean set)
{
  static gchar *old_proxy = NULL;

  if (set)
    {
      gchar *pac_proxy = NULL;
      gchar *pac = get_dconf_proxy_setting ("PAC");

      if (!old_proxy)
        old_proxy = g_strdup (g_getenv ("http_proxy"));

      if (pac && *pac && !g_str_has_prefix (pac, UNPROXIED))
        {
          if (g_str_has_prefix (pac, "pac+"))
            pac_proxy = g_strdup (pac);
          else
            pac_proxy = g_strdup_printf ("pac+%s", pac);

          g_setenv ("http_proxy", pac_proxy, TRUE);
          g_free (pac_proxy);
        }

      g_free (pac);
    }
  else
    {
      if (old_proxy)
        {
          g_setenv ("http_proxy", old_proxy, TRUE);

          g_free (old_proxy);
          old_proxy = NULL;
        }
      else
        {
          g_unsetenv ("http_proxy");
        }
    }
}

/* If we have a target url, go straight to libproxy:
 * If not, we have to do the proxy lookup by hand */
const gchar *
get_proxy_url (const gchar *type, const gchar *target)
{
  gchar *url = NULL;
  const gchar *env_key = NULL;
  static GHashTable *proxies = NULL;

  if (G_UNLIKELY (proxies == NULL))
    proxies = g_hash_table_new_full (g_str_hash, g_str_equal, g_free, g_free);

  if (url = g_hash_table_lookup (proxies, type))
    {
      g_debug ("cached proxy %s: %s", type, url);
    }
  else if (!target)
    {
      env_key = proxy_type_to_env_var (type);

      /* the env value is volatile, so we need to copy it: */
      if (env_key && (url = (gchar *) g_getenv (env_key)) && isalpha (*url))
        {
          g_debug ("fetching %s from environment", env_key);

          url = g_strdup (url);
          cache_proxy (proxies, type, url);
        }
      else if (url = get_dconf_proxy_setting (type))
        {
          g_debug ("fetching %s proxy from dconf", type);
          /* the dconf value is already copied for us, so we own it: */
          if (isalpha (*url))
            {
              cache_proxy (proxies, type, url);
            }
          else
            {
              g_free (url);
              url = NULL;
            }
        }

      g_debug ("proxy %s setting: %s", type, url ? url : "-none-");
    }
  else /* we have a target - jump straight to libproxy: */
    {
      fake_pac (TRUE);

      if (url = get_libproxy_setting (target))
        cache_proxy (proxies, type, url);

      g_debug ("libproxy %s setting: %s", type, url);

      fake_pac (FALSE);
    }

  if (url && isalpha (*url) && !g_str_has_prefix (url, UNPROXIED))
    return url;

  return NULL;
}
