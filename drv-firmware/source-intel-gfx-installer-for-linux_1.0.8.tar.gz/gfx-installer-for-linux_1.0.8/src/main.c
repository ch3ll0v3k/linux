/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <libintl.h>

#include "config.h"
#include "driver-manager-app.h"

static GFileOutputStream *log_file = NULL;
GtkApplication *installer;

static void
log_handler (const gchar   *log_domain,
	     GLogLevelFlags log_level,
	     const gchar   *message,
	     gpointer       user_data)
{
  if (!log_file)
    {
      gchar *path;
      GError *error = NULL;
      GFile *file;

      path = g_strdup_printf ("/var/tmp/intel-linux-graphics-installer-%d.log", getpid ());
      file = g_file_new_for_path (path);
      g_free (path);

      log_file = g_file_create (file, G_FILE_CREATE_REPLACE_DESTINATION | G_FILE_CREATE_PRIVATE, NULL, &error);
      g_object_unref (file);
      if (!log_file)
	{
	  g_print ("Error opening log file: %s\n", error->message);
	  g_error_free (error);
	}
    }

  if (log_file)
    {
      gchar *real_message = g_strdup_printf ("%s\n", message);

      g_output_stream_write (G_OUTPUT_STREAM (log_file),
			     (const void *) real_message,
			     strlen (real_message),
			     NULL,
			     NULL);
      g_free (real_message);
    }

  g_print ("%s\n", message);
}

int
main (int argc, char *argv[])
{
  int status;

  bindtextdomain (GETTEXT_PACKAGE, GNOMELOCALEDIR);
  bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
  textdomain (GETTEXT_PACKAGE);

  gtk_init (&argc, &argv);

  g_log_set_handler (NULL, G_LOG_LEVEL_ERROR | G_LOG_LEVEL_CRITICAL | G_LOG_LEVEL_WARNING |
		     G_LOG_LEVEL_MESSAGE | G_LOG_LEVEL_INFO | G_LOG_LEVEL_DEBUG | G_LOG_LEVEL_MASK,
		     (GLogFunc) log_handler, NULL);

  installer = driver_manager_app_new ();

  status = g_application_run (G_APPLICATION (installer), argc, argv);
  g_object_unref (installer);

  if (log_file != NULL)
    g_object_unref (log_file);

  return status;
}
