/*
 * Copyright © 2013 Intel Corporation
 *
 * Authors: Marco Barisione <marco.barisione@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <glib/gi18n.h>
#include "report-view.h"
#include "utils.h"

#define HEADER_TAG_NAME "header"

G_DEFINE_TYPE (ReportView, report_view, GTK_TYPE_BOX)

struct _ReportViewPrivate {
  GtkWidget *title_label;
  GtkWidget *log_window;

  GFileOutputStream *log_stream;
};

static void
report_view_class_init (ReportViewClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  g_type_class_add_private (object_class, sizeof (ReportViewPrivate));
}

static void
set_label_text (ReportView *view, const gchar *text)
{
  const gchar *header = _("<big><b>Installation report</b></big>\n\n");
  gchar *title;

  title = g_strdup_printf ("%s%s", header, text);
  gtk_label_set_markup (GTK_LABEL (view->priv->title_label), title);
  g_free (title);
}

static void
report_view_init (ReportView *view)
{
  GtkWidget *w;
  GtkTextBuffer *buffer;

  view->priv = G_TYPE_INSTANCE_GET_PRIVATE (view, TYPE_REPORT_VIEW, ReportViewPrivate);

  view->priv->title_label = gtk_label_new (NULL);
  gtk_label_set_use_markup (GTK_LABEL (view->priv->title_label), TRUE);
  gtk_label_set_line_wrap (GTK_LABEL (view->priv->title_label), TRUE);
  set_label_text (view, _("<b>No packages were changed on this run of the installer.</b>\n\n"
                          "If you have previously run the installer this session "
                          "and it made changes, you may still need to reboot your system "
                          "for them to take effect.\n"));
  gtk_misc_set_alignment (GTK_MISC (view->priv->title_label), 0.0, 0.0);
  gtk_box_pack_start (GTK_BOX (view), view->priv->title_label, FALSE, FALSE, 3);
  gtk_widget_show (view->priv->title_label);

  w = gtk_scrolled_window_new (NULL, NULL);
  gtk_scrolled_window_set_min_content_height (GTK_SCROLLED_WINDOW (w), 128);
  gtk_box_pack_start (GTK_BOX (view), w, TRUE, TRUE, 3);
  gtk_widget_show (w);

  view->priv->log_window = gtk_text_view_new ();
  gtk_text_view_set_editable (GTK_TEXT_VIEW (view->priv->log_window), FALSE);
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (view->priv->log_window), FALSE);
  gtk_text_view_set_left_margin (GTK_TEXT_VIEW (view->priv->log_window), 12);
  gtk_text_view_set_right_margin (GTK_TEXT_VIEW (view->priv->log_window), 12);
  gtk_container_add (GTK_CONTAINER (w), view->priv->log_window);
  gtk_widget_show (view->priv->log_window);

  buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (view->priv->log_window)),
  gtk_text_buffer_create_tag (buffer, HEADER_TAG_NAME,
                              "weight", PANGO_WEIGHT_BOLD,
                              NULL);
}

GtkWidget *
report_view_new (void)
{
  return g_object_new (TYPE_REPORT_VIEW,
                       "orientation", GTK_ORIENTATION_VERTICAL,
                       NULL);
}

static void
log_open (ReportView *view)
{
  gchar *path = NULL;
  GFile *file = NULL;
  GError *error = NULL;

  g_return_if_fail (view->priv->log_stream == NULL);

  path = g_strdup_printf ("/var/tmp/intel-linux-graphics-installer-report-%d.log",
      getpid ());
  file = g_file_new_for_path (path);

  view->priv->log_stream = g_file_create (file,
      G_FILE_CREATE_REPLACE_DESTINATION | G_FILE_CREATE_PRIVATE, NULL, &error);
  if (view->priv->log_stream == NULL)
    {
      g_critical ("Error opening log file: %s", error->message);
      g_error_free (error);
    }

  g_clear_object (&file);
  g_free (path);
}

static void
log_close (ReportView *view)
{
  g_clear_object (&view->priv->log_stream);
}

static void
log_write (ReportView *view, const gchar *msg)
{
  if (view->priv->log_stream == NULL)
    {
      /* If something went wrong we have already printed an error */
      return;
    }

  g_output_stream_write (G_OUTPUT_STREAM (view->priv->log_stream),
      msg, strlen (msg), NULL, NULL);
}

typedef struct
{
  gchar *name;
  gchar *version_before;
  gchar *version_after;
} Package;

static Package *
package_new (const gchar *name, const gchar *version_before, const gchar *version_after)
{
  Package *package = g_slice_new0 (Package);
  package->name = g_strdup (name);
  package->version_before = g_strdup (version_before);
  package->version_after = g_strdup (version_after);
  return package;
}

static void
package_free (Package *package)
{
  if (package != NULL)
    {
      g_free (package->name);
      g_free (package->version_before);
      g_free (package->version_after);
      g_slice_free (Package, package);
    }
}

static gint
package_compare (gconstpointer a,
                 gconstpointer b)
{
  const Package *pa = a;
  const Package *pb = b;

  return g_strcmp0 (pa->name, pb->name);
}

static void
package_list_free (GList *packages)
{
  g_list_foreach (packages, (GFunc) package_free, NULL);
  g_list_free (packages);
}

static void
diff_package_lists (ReportView *view, GHashTable *before, GHashTable *after,
    GList **added, GList **upgraded, GList **downgraded, GList **removed)
{
  GHashTableIter iter_before, iter_after;
  gpointer key, value;

  g_hash_table_iter_init (&iter_after, after);
  while (g_hash_table_iter_next (&iter_after, &key, &value))
    {
      const gchar *name = key;
      const gchar *version_after = value;
      const gchar *version_before = g_hash_table_lookup (before, name);
      GList **where = NULL;

      if (version_before == NULL)
        {
          /* It was not installed before so this is an addition or nothing
           * changed */
          if (version_after != NULL)
            where = added;
        }
      else if (version_after == NULL)
        {
          /* Before is not NULL, so it must be a removal */
          where = removed;
        }
      else
        {
          /* Both are non null, so this is a version change (upgrade or
           * downgrade) or nothing changed */
          gint cmp = compare_versions (version_before, version_after);
          if (cmp > 0)
            where = downgraded;
          else if (cmp < 0)
            where = upgraded;
        }

      if (where != NULL)
        {
          Package *p = package_new (name, version_before, version_after);
          *where = g_list_prepend (*where, p);
        }
    }

  /* If a source is removed, then a package that was installed before could
   * not even be in the after hash table, so we go through the packages that
   * were installed before and look for the ones are not available at all
   * any more. */
  g_hash_table_iter_init (&iter_before, before);
  while (g_hash_table_iter_next (&iter_before, &key, &value))
    {
      const gchar *name = key;
      const gchar *version_before = value;

      if (version_before != NULL &&
          !g_hash_table_lookup_extended (after, name, NULL, NULL))
        {
          Package *p = package_new (name, version_before, NULL);
          *removed = g_list_prepend (*removed, p);
        }
    }

  *added = g_list_sort (*added, package_compare);
  *upgraded = g_list_sort (*upgraded, package_compare);
  *downgraded = g_list_sort (*downgraded, package_compare);
  *removed = g_list_sort (*removed, package_compare);
}

static void
append_line (ReportView *view, const gchar *text, gboolean header)
{
  const gchar *indentation = ((header && text != NULL) ? "" : "    ");
  const gchar *tag_name = (header ? HEADER_TAG_NAME : NULL);
  GtkTextBuffer *buffer;
  GtkTextIter iter;
  gchar *line;

  if (text == NULL)
    text = ""; /* This is just to add a new line */

  buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (view->priv->log_window));
  gtk_text_buffer_get_end_iter (buffer, &iter);
  line = g_strdup_printf ("%s%s\n", indentation, text);
  gtk_text_buffer_insert_with_tags_by_name (buffer, &iter, line, -1, tag_name, NULL);

  log_write (view, line);

  g_free (line);
}

static void
add_package_entries (ReportView *view, const gchar *category_name, GList *packages)
{
  GList *l;

  if (packages == NULL)
    {
      /* Nothing for this category */
      return;
    }

  append_line (view, category_name, TRUE);

  for (l = packages; l != NULL; l = l->next)
    {
      Package *package = l->data;
      gchar *version_text;
      gchar *text;

      if (package->version_before == NULL)
        {
          /* Version after cannot be NULL too */
          /* Note to translators: %s is the package version we just installed */
          version_text = g_strdup_printf (_(" (%s)"), package->version_after);
        }
      else if (package->version_after == NULL)
        {
          /* Note to translators: %s is the package version before we
           * uninstalled the package */
          version_text = g_strdup_printf (_(" (was %s)"), package->version_before);
        }
      else
        {
          /* Note to translators: the first %s is the old package version, the
           * second %s is the new package version we just installed */
          version_text = g_strdup_printf (_(" (from %s to %s)"),
                package->version_before, package->version_after);
        }

      text = g_strdup_printf ("%s%s", package->name, version_text);
      append_line (view, text, FALSE);

      g_free (text);
      g_free (version_text);
    }

  append_line (view, NULL, FALSE);
}

void
report_view_start (ReportView *view, GHashTable *packages_before, GHashTable *packages_after)
{
  GList *added = NULL;
  GList *upgraded = NULL;
  GList *downgraded = NULL;
  GList *removed = NULL;
  gchar *summary;

  g_return_if_fail (IS_REPORT_VIEW (view));
  g_return_if_fail (packages_before != NULL);
  g_return_if_fail (packages_after != NULL);

  diff_package_lists (view, packages_before, packages_after,
      &added, &upgraded, &downgraded, &removed);

  if (added == NULL && removed == NULL
      && upgraded == NULL && downgraded == NULL)
    {
      gtk_widget_hide (view->priv->log_window);
    }
  else
    {
      log_open (view);

      log_write (view, "Intel Graphics Installer for Linux report\n\n");

      summary = g_strdup_printf (_("<b>%d added, %d upgraded, %d downgraded, %d removed.</b>\n\n"
                                   "You should reboot your system when prompted.\n"),
          g_list_length (added),
          g_list_length (upgraded),
          g_list_length (downgraded),
          g_list_length (removed));
      set_label_text (view, summary);

      log_write (view, summary);
      log_write (view, "\n\n");

      add_package_entries (view, _("Added:"), added);
      add_package_entries (view, _("Upgraded:"), upgraded);
      add_package_entries (view, _("Downgraded:"), downgraded);
      add_package_entries (view, _("Removed:"), removed);

      log_close (view);

      g_free (summary);
    }


  package_list_free (added);
  package_list_free (upgraded);
  package_list_free (downgraded);
  package_list_free (removed);
}
