/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _DIAGNOSTICS_VIEW_
#define _DIAGNOSTICS_VIEW_

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define TYPE_DIAGNOSTICS_VIEW                (diagnostics_view_get_type ())
#define DIAGNOSTICS_VIEW(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), TYPE_DIAGNOSTICS_VIEW, DiagnosticsView))
#define IS_DIAGNOSTICS_VIEW(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TYPE_DIAGNOSTICS_VIEW))
#define DIAGNOSTICS_VIEW_CLASS(klass)        (G_TYPE_CHECK_CLASS_CAST ((klass), TYPE_DIAGNOSTICS_VIEW, DiagnosticsViewClass))
#define IS_DIAGNOSTICS_VIEW_CLASS(klass)     (G_TYPE_CHECK_CLASS_TYPE ((klass), TYPE_DIAGNOSTICS_VIEW))
#define DIAGNOSTICS_VIEW_GET_CLASS(obj)      (G_TYPE_INSTANCE_GET_CLASS ((obj), TYPE_DIAGNOSTICS_VIEW, DiagnosticsViewClass))

typedef struct _DiagnosticsViewPrivate DiagnosticsViewPrivate;

typedef struct {
  GtkBox parent;

  DiagnosticsViewPrivate *priv;
} DiagnosticsView;

typedef struct {
  GtkBoxClass parent_class;

  /*< signals >*/
  void (* finished) (DiagnosticsView *view, gboolean success);
} DiagnosticsViewClass;

GType      diagnostics_view_get_type (void);

GtkWidget *diagnostics_view_new (void);
void       diagnostics_view_start (DiagnosticsView *view);

void diagnostics_view_add_postscript (DiagnosticsView *view, const gchar *text);
void diagnostics_view_end_postscript (DiagnosticsView *view, const gchar *text);

G_END_DECLS

#endif
