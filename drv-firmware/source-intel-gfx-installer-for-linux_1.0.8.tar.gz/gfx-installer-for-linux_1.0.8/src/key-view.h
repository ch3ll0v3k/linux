/*
 * Copyright © 2013 Intel Corporation
 *
 * Authors: Marco Barisione <marco.barisione@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _KEY_VIEW_
#define _KEY_VIEW_

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define TYPE_KEY_VIEW                (key_view_get_type ())
#define KEY_VIEW(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), TYPE_KEY_VIEW, KeyView))
#define IS_KEY_VIEW(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TYPE_KEY_VIEW))
#define KEY_VIEW_CLASS(klass)        (G_TYPE_CHECK_CLASS_CAST ((klass), TYPE_KEY_VIEW, KeyViewClass))
#define IS_KEY_VIEW_CLASS(klass)     (G_TYPE_CHECK_CLASS_TYPE ((klass), TYPE_KEY_VIEW))
#define KEY_VIEW_GET_CLASS(obj)      (G_TYPE_INSTANCE_GET_CLASS ((obj), TYPE_KEY_VIEW, KeyViewClass))

typedef struct _KeyViewPrivate KeyViewPrivate;

typedef struct {
  GtkBox parent;

  KeyViewPrivate *priv;
} KeyView;

typedef struct {
  GtkBoxClass parent_class;
} KeyViewClass;

GType        key_view_get_type (void);

GtkWidget   *key_view_new (void);

void         key_view_start (KeyView *view);
void         key_view_freeze_choice (KeyView *view);

gboolean     key_view_get_install_key (KeyView *view);
const gchar *key_view_get_docs_to_show (KeyView *view);

G_END_DECLS

#endif
