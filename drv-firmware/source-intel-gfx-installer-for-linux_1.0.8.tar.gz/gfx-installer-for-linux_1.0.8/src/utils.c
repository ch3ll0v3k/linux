/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <libsoup/soup.h>
#include <libsoup/soup-gnome-features.h>

#include "driver-manager-app.h"
#include "utils.h"

#define FEDORA_RELEASE_RE "Fedora\\s+release\\s+(\\d+)\\s+\\((.*?)\\)"
#define FEDORA_RELEASE_FILE "/etc/fedora-release"

extern GtkApplication *installer;

#ifndef NO_GUI
static gchar last_action[255];

void
_update_progress_details (const gchar *where,
                         const gchar *action,
                         const gchar *msg,
                         gint percent,
                         gboolean spin)
{
    DriverManagerApp *dma = DRIVER_MANAGER_APP (installer);

    // 101 => from package managers = don't know, don't update
    // we use -1 internally for that behaviour
    if (percent == 101)
      percent = -1;

    if (action)
      {
        strncpy (last_action, action, 254);
        last_action[254] = '\0';
      }
    else
      {
        action = last_action;
      }

    g_debug ("🕛 %s", where);
    driver_manager_app_progress (dma, action, msg, percent, spin);
}
#endif // NO_GUI

void
display_error (GtkWindow *parent, const gchar *format, ...)
{
  va_list args;
  gchar *msg;
  GtkWidget *dialog;

  va_start (args, format);
  msg = g_strdup_vprintf (format, args);
  va_end (args);

  dialog = gtk_message_dialog_new (parent, 0, GTK_MESSAGE_ERROR, GTK_BUTTONS_CLOSE, "%s", msg);
  gtk_dialog_run (GTK_DIALOG (dialog));
  gtk_widget_destroy (dialog);

  g_free (msg);
}

Distribution *
get_distro_information (void)
{
  gchar *output, **output_parts;
  gint exit_status;
  static Distribution distro;
  static gboolean initialized = FALSE;

  if (initialized)
    return &distro;

  memset (&distro, 0, sizeof (distro));

  if (g_spawn_command_line_sync ("lsb_release -a", &output, NULL, &exit_status, NULL))
    {
      output_parts = g_strsplit (output, "\n", 0);
      g_free (output);
      if (output_parts != NULL)
	{
	  gint cnt = 0;

	  while (output_parts[cnt] != NULL)
	    {
	      gchar **line_items = g_strsplit (output_parts[cnt], ":", 2);

	      if (line_items != NULL)
		{
		  if (g_strcmp0 (line_items[0], "Distributor ID") == 0)
		    distro.distributor = g_strstrip (g_strdup (line_items[1]));
		  else if (g_strcmp0 (line_items[0], "Description") == 0)
		    distro.description = g_strstrip (g_strdup (line_items[1]));
		  else if (g_strcmp0 (line_items[0], "Release") == 0)
		    distro.release = g_strstrip (g_strdup (line_items[1]));
		  else if (g_strcmp0 (line_items[0], "Codename") == 0)
		    distro.codename = g_strstrip (g_strdup (line_items[1]));

		  g_strfreev (line_items);
		}

	      cnt += 1;
	    }

          // Turns out lsb_release output is not consistent with
          // /etc/fedora-release: Since the release file is what's there
          // by default, let's go with that.  For the record: RH lsb squashes
          // the codename into one BeefyMiracle style word
          if (g_strcmp0 (distro.distributor, "Fedora") == 0)
            {
              GMatchInfo *matched = NULL;
              GRegex *release = g_regex_new (FEDORA_RELEASE_RE, 0, 0, NULL);

              if (g_regex_match (release, distro.description, 0, &matched))
                {
                  g_free (distro.codename);
                  distro.codename = g_match_info_fetch (matched, 2);
                }

              g_match_info_unref (matched);
              g_regex_unref (release);
            }

	  g_strfreev (output_parts);

	  initialized = TRUE;

	  return &distro;
	}
    }
  else
    {
      gchar *contents;
      gsize size;

      /* lsb_release is not available on Fedora (by default) */
      if (g_file_get_contents (FEDORA_RELEASE_FILE, &contents, &size, NULL))
        {
          GMatchInfo *matched = NULL;
          GRegex *release = g_regex_new (FEDORA_RELEASE_RE, 0, 0, NULL);

          distro.distributor = g_strdup ("Fedora");
          distro.description = contents;

          if (g_regex_match (release, contents, 0, &matched))
            {
              distro.release = g_match_info_fetch (matched, 1);
              distro.codename = g_match_info_fetch (matched, 2);
            }
          else
            {
              distro.release = g_strdup("Unknown");
              distro.codename = g_strdup ("Unknown");
            }

          g_match_info_unref (matched);
          g_regex_unref (release);

	  initialized = TRUE;

	  return &distro;
	}
    }

  return &distro;
}

static gboolean
purely_digital (const gchar *str)
{
  gchar *c;

  for (c = (gchar *) str; c && *c; c++)
    if (! g_ascii_isdigit(*c))
      return FALSE;

  return c != str;
}

static gint
compare_version_component (const gchar *vp0, const gchar *vp1)
{
  if (purely_digital (vp0) && purely_digital (vp1))
    {
      guint i0 = g_ascii_strtoull(vp0, NULL, 10);
      guint i1 = g_ascii_strtoull(vp1, NULL, 10);

      return (i0 < i1) ? -1 : (i0 > i1) ? 1 : 0;
    }

  return g_strcmp0 (vp0, vp1);
}

gint
compare_versions (const gchar *ver0, const gchar *ver1)
{
  GStrv v0 = g_strsplit_set (ver0, ".:-", -1);
  GStrv v1 = g_strsplit_set (ver1, ".:-", -1);
  guint l0 = g_strv_length (v0);
  guint l1 = g_strv_length (v1);
  guint vl = MIN (l0, l1);
  guint i;
  gint comp = 0;

  for (i = 0; i < vl; i++)
    {
      comp = compare_version_component (*(v0 + i), *(v1 + i));

      if (comp != 0)
        break;
    }

  /* got to the end of the shorter version with no difference: *
   * ∴ the longer version string is considered greater         */
  if (comp == 0)
    {
      if (l0 < l1)
        comp = -1;
      else if (l0 > l1)
        comp = 1;
    }

  g_strfreev (v0);
  g_strfreev (v1);

  return comp;
}

gboolean
http_download_file (const gchar *uri,
		    const gchar *output,
		    GError     **error)
{
  SoupSession *http_session;
  SoupMessage *message;
  guint status;
  gboolean result = FALSE;

  http_session = soup_session_sync_new_with_options (SOUP_SESSION_ADD_FEATURE_BY_TYPE, SOUP_TYPE_GNOME_FEATURES_2_26,
						     NULL);
  if (!http_session)
    return FALSE;

  message = soup_message_new (SOUP_METHOD_GET, uri);
  status = soup_session_send_message (http_session, message);
  if (SOUP_STATUS_IS_SUCCESSFUL (status))
    {
      GFile *output_file;

      output_file = g_file_new_for_path (output);
      if (output_file)
	{
	  GFileOutputStream *stream;
	  SoupBuffer *buffer;
	  GError *local_error = NULL;

	  stream = g_file_replace (output_file, NULL, FALSE, G_FILE_CREATE_REPLACE_DESTINATION, NULL, &local_error);
	  if (stream)
	    {
	      goffset offset = 0;

	      while ((buffer = soup_message_body_get_chunk (message->response_body, offset)))
		{
		  g_output_stream_write (G_OUTPUT_STREAM (stream),
					 buffer->data,
					 buffer->length,
					 NULL,
					 NULL);

		  offset += buffer->length;

		  soup_buffer_free (buffer);
		}

	      g_object_unref (stream);
	      result = TRUE;
	    }
	  else
	    g_propagate_error (error, local_error);

	  g_object_unref (output_file);
	}
    }
  else
    {
      if (error != NULL)
	g_set_error (error, g_quark_from_static_string ("HTTP"), status, "%s", message->reason_phrase);
    }

  g_object_unref (message);
  g_object_unref (http_session);

  return result;
}
