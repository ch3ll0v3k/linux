/*
 * Copyright © 2013 Intel Corporation
 *
 * Authors: Marco Barisione <marco.barisione@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <glib/gi18n.h>
#include "key-view.h"
#include "utils.h"

#define INTRO_TEXT N_("\
The Intel Graphics Installer for Linux is digitally signed with a PGP key for \
increased security.\n\
If you install this key you will be able to verify that the installer and \
related software are official packages provider by Intel. Installing the \
key also means that your system will automatically trust future updates of \
the software.\n\
\n\
Do you want to install the PGP key?")

#define INSTALL_TEXT \
  N_("Install the key and trust packages signed with it.")
#define NO_AND_SHOW_INSTRUCTIONS_TEXT \
  N_("Do not install the key, but show me how to do it manually.")
#define NO_TEXT \
  N_("Do not install the key or trust these packages automatically.")

G_DEFINE_TYPE (KeyView, key_view, GTK_TYPE_BOX)

struct _KeyViewPrivate {
  GtkWidget *radio_install;
  GtkWidget *radio_no_and_instructions;
  GtkWidget *radio_no;
};

static void
key_view_class_init (KeyViewClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  g_type_class_add_private (object_class, sizeof (KeyViewPrivate));
}

static GtkWidget *
add_radio_button (KeyView *view, const gchar *label)
{
  GtkWidget *w;

  w = gtk_radio_button_new_with_label_from_widget (
      GTK_RADIO_BUTTON (view->priv->radio_install), label);
  gtk_widget_show (w);
  gtk_box_pack_start (GTK_BOX (view), w, FALSE, TRUE, 0);

  return w;
}

static void
key_view_init (KeyView *view)
{
  GtkWidget *w;

  view->priv = G_TYPE_INSTANCE_GET_PRIVATE (view, TYPE_KEY_VIEW, KeyViewPrivate);

  w = gtk_label_new (_(INTRO_TEXT));
  gtk_label_set_line_wrap (GTK_LABEL (w), TRUE);
  gtk_label_set_justify (GTK_LABEL (w), GTK_JUSTIFY_FILL);
  gtk_widget_show (w);
  gtk_box_pack_start (GTK_BOX (view), w, FALSE, TRUE, 3);

  view->priv->radio_install = add_radio_button (view, INSTALL_TEXT);
  view->priv->radio_no_and_instructions = add_radio_button (view, NO_AND_SHOW_INSTRUCTIONS_TEXT);
  view->priv->radio_no = add_radio_button (view, NO_TEXT);
}

GtkWidget *
key_view_new (void)
{
  return g_object_new (TYPE_KEY_VIEW,
                       "orientation", GTK_ORIENTATION_VERTICAL,
                       NULL);
}

void
key_view_start (KeyView *view)
{
  g_return_if_fail (IS_KEY_VIEW (view));

  /* This method exists for consistency with the other views even if it doesn't
   * do anything at the moment */
}

static void
freeze_if_not_active (GtkWidget *w)
{
  if (!gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (w)))
      gtk_widget_set_sensitive (w, FALSE);
}

void
key_view_freeze_choice (KeyView *view)
{
  /* After installation starts you cannot change your choice any more,
   * so we just disable the non-active radio buttons */
  freeze_if_not_active (view->priv->radio_install);
  freeze_if_not_active (view->priv->radio_no_and_instructions);
  freeze_if_not_active (view->priv->radio_no);
}

gboolean
key_view_get_install_key (KeyView *view)
{
  return gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (view->priv->radio_install));
}

const gchar *
key_view_get_docs_to_show (KeyView *view)
{
  Configuration *config;

  if (!gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (view->priv->radio_no_and_instructions)))
      return NULL;

  config = get_configuration ();
  switch (config->docs->len)
    {
    case 0:
      g_warning ("No documentation specified in the configuration file.");
      /* At least this has some relevant instructions */
      return "https://01.org/linuxgraphics/downloads/2013/intelr-graphics-installer-1.0.2-linux";
    case 1:
      return g_ptr_array_index (config->docs, 0);
    default:
      g_critical ("Too many documents specified in the configuration file.");
      return NULL;
    }
}
