/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <glib/gi18n.h>

#include "config.h"
#include "driver-manager-app.h"
#include "main-window.h"

G_DEFINE_TYPE (DriverManagerApp, driver_manager_app, GTK_TYPE_APPLICATION)

struct _DriverManagerAppPrivate {
  GtkWindow *main_window;
};

static void
driver_manager_app_finalize (GObject *object)
{
  DriverManagerApp *dm_app = DRIVER_MANAGER_APP (object);

  if (dm_app->priv != NULL)
    {
      g_free (dm_app->priv);
      dm_app->priv = NULL;
    }

  G_OBJECT_CLASS (driver_manager_app_parent_class)->finalize (object);
}

static void
on_driver_manager_app_startup (GApplication *app, gpointer user_data)
{
}

static void
on_window_destroyed (GtkWidget *w, gpointer user_data)
{
  g_application_quit (G_APPLICATION (user_data));
}

static void
on_driver_manager_app_activate (GApplication *app, gpointer user_data)
{
  DriverManagerApp *dm_app = DRIVER_MANAGER_APP (app);

  dm_app->priv->main_window = main_window_new ();
  gtk_application_add_window (GTK_APPLICATION (app), dm_app->priv->main_window);
  g_signal_connect (dm_app->priv->main_window, "destroy", G_CALLBACK (on_window_destroyed), app);
  gtk_widget_show (GTK_WIDGET (dm_app->priv->main_window));
}

static gint
on_driver_manager_app_command_line (GApplication *application, GApplicationCommandLine *command_line)
{
  GOptionContext *ctx;
  GError *error = NULL;
  gchar **args, **argv;
  gint argc, i, status = 0;

  /* See Glib documentation on the "Commandline Option Parser" for more info */
  args = g_application_command_line_get_arguments (command_line, &argc);

  argv = g_new (gchar*, argc + 1);
  for (i = 0; i <= argc; i++)
      argv[i] = args[i];

  ctx = g_option_context_new (_("— Install Intel drivers for Linux"));
  g_option_context_set_translation_domain (ctx, GETTEXT_PACKAGE);

  if (!g_option_context_parse (ctx, &argc, &argv, &error))
    {
      g_application_command_line_printerr (command_line,
                                           _("Option parsing failed: %s\n"),
                                           error->message);
      g_error_free (error);
      status = 1;
    }
  else
    {
      g_application_activate (application);
      status = 0;
    }

  g_option_context_free (ctx);
  g_free (argv);
  g_strfreev (args);

  return status;
}

static void
driver_manager_app_class_init (DriverManagerAppClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  object_class->finalize = driver_manager_app_finalize;
}

static void
driver_manager_app_init (DriverManagerApp *dm_app)
{
  dm_app->priv = g_new0 (DriverManagerAppPrivate, 1);

  g_signal_connect (dm_app, "startup", G_CALLBACK (on_driver_manager_app_startup), NULL);
  g_signal_connect (dm_app, "activate", G_CALLBACK (on_driver_manager_app_activate), NULL);
  g_signal_connect (dm_app, "command-line", G_CALLBACK (on_driver_manager_app_command_line), NULL);
}

GtkApplication *
driver_manager_app_new (void)
{
  g_set_application_name ("Intel Graphics Installer for Linux");

  return GTK_APPLICATION (g_object_new (TYPE_DRIVER_MANAGER_APP,
					"application-id", "org.intellinuxgraphics.DriverManager",
					"flags", G_APPLICATION_HANDLES_COMMAND_LINE,
					"inactivity-timeout", 30000,
					"register-session", TRUE,
					NULL));
}

void
driver_manager_app_progress (DriverManagerApp *app,
                             const gchar *action,
                             const gchar *msg,
                             gint percent,
                             gboolean spin)
{
  MainWindow *window = NULL;

  if (!app || !app->priv || !app->priv->main_window)
    return;

  window = MAIN_WINDOW (app->priv->main_window);
  main_window_progress (window, action, msg, percent, spin);
}
