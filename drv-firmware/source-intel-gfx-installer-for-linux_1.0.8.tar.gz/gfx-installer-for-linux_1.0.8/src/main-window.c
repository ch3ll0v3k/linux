/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *          Marco Barisione <marco.barisione@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <glib/gi18n.h>
#include "config.h"
#include "diagnostics-view.h"
#include "key-view.h"
#include "main-window.h"
#include "package-manager.h"
#include "report-view.h"
#include "transaction-view.h"

#define WAITING " ⏳ "

typedef enum {
    RESPONSE_BACK = 0,
    RESPONSE_CLOSE,
    RESPONSE_NEXT,
    RESPONSE_UNINSTALL,
    RESPONSE_INSTALL,
    RESPONSE_LAST
} MainWindowReponse;

typedef enum {
    RESPONSE_STATUS_DISABLED,
    RESPONSE_STATUS_ENABLED,
    RESPONSE_STATUS_HIDDEN
} ResponseStatus;

typedef struct Page Page;

typedef void (*ActivatePageFunction) (MainWindow *, Page *);

struct Page {
    GtkWidget *widget;
    ActivatePageFunction activate;
    gboolean has_been_activated;
    ResponseStatus cached_reponse_statuses[RESPONSE_LAST];
    const gchar *next_button_label;
};

#define NEXT_BUTTON_LABEL_NEXT _("Next")
#define NEXT_BUTTON_LABEL_BEGIN _("Begin")
#define NEXT_BUTTON_LABEL_REPORT _("Report")

G_DEFINE_TYPE (MainWindow, main_window, GTK_TYPE_DIALOG)

struct _MainWindowPrivate {
  gboolean need_reboot;
  gboolean is_uninstall;
  GPtrArray *pages; /* GPtrArray<Page*> */

  /* Pages */
  Page *intro_page;
  Page *diagnostics_page;
#if ENABLE_KEY_INSTALLATION
  Page *key_page;
#endif
  Page *transaction_page;
  Page *report_page;

  /* Widgets */
  GtkWidget *notebook;
  GtkWidget *back_button;
  GtkWidget *close_button;
  GtkWidget *install_button;
  GtkWidget *next_button;
  struct {
    GtkWidget *box;
    GtkWidget *status;
    GtkWidget *message;
    GtkWidget *percent;
    GtkWidget *spinner;
  } progress;
};

static void
main_window_finalize (GObject *object)
{
  MainWindow *win = MAIN_WINDOW (object);

  if (win->priv != NULL)
    {
      g_ptr_array_free (win->priv->pages, TRUE);
      g_free (win->priv);
    }

  G_OBJECT_CLASS (main_window_parent_class)->finalize (object);
}

static void
main_window_class_init (MainWindowClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  object_class->finalize = main_window_finalize;
}

static Page *
add_page (MainWindow *win,
          GtkWidget *widget,
          ActivatePageFunction activate)
{
  Page *page;
  gint id;

  page = g_new0 (Page, 1);
  page->widget = widget;
  page->activate = activate;
  page->has_been_activated = FALSE;
  /* All the normal buttons are enabled by default, ... */
  for (id = 0; id < RESPONSE_LAST; id++)
    page->cached_reponse_statuses[id] = RESPONSE_STATUS_ENABLED;
  /* ... but not the install/uninstall buttons as they are used only by one page */
  page->cached_reponse_statuses[RESPONSE_INSTALL] = RESPONSE_STATUS_HIDDEN;
  page->cached_reponse_statuses[RESPONSE_UNINSTALL] = RESPONSE_STATUS_HIDDEN;

  page->next_button_label = NEXT_BUTTON_LABEL_NEXT;

  g_ptr_array_add (win->priv->pages, page);

  gtk_notebook_append_page (GTK_NOTEBOOK (win->priv->notebook), page->widget, NULL);
  gtk_widget_show (page->widget);

  return page;
}

static void
set_response_status (MainWindow *win, Page *page, gint response_id, ResponseStatus status)
{
  GtkDialog *dialog = GTK_DIALOG (win);
  GtkWidget *widget = gtk_dialog_get_widget_for_response (dialog, response_id);

  if (status == RESPONSE_STATUS_HIDDEN)
    {
      gtk_widget_hide (widget);
    }
  else
    {
      gtk_widget_show (widget);
      gtk_dialog_set_response_sensitive (dialog, response_id,
          status == RESPONSE_STATUS_ENABLED);
    }

  page->cached_reponse_statuses[response_id] = status;
}

static void
set_next_button_label (MainWindow *win, Page *page, const gchar *label)
{
  gtk_button_set_label (GTK_BUTTON (win->priv->next_button), label);
  page->next_button_label = label;
}

static void
set_active_page (MainWindow *win, guint page_number)
{
  Page *page;
  gint id;

  g_return_if_fail (page_number < win->priv->pages->len);

  gtk_notebook_set_current_page (GTK_NOTEBOOK (win->priv->notebook), page_number);

  page = g_ptr_array_index (win->priv->pages, page_number);

  /* Set the buttons to the default status or, if the page was already
   * visited, to the last status set */
  for (id = 0; id < RESPONSE_LAST; id++)
    set_response_status (win, page, id, page->cached_reponse_statuses[id]);

  gtk_button_set_label (GTK_BUTTON (win->priv->next_button),
        page->next_button_label);

  if (!page->has_been_activated)
    {
      page->activate (win, page);
      page->has_been_activated = TRUE;
    }
}

static void
on_diagnostics_finished (DiagnosticsView *view, gboolean success, gpointer user_data)
{
  MainWindow *win = MAIN_WINDOW (user_data);

  g_debug ("%s/%s: Diagnostics finished %s", __FILE__, __FUNCTION__, success ? "successfully" : "with an error");

  if (success)
    {
#if ENABLE_UNINSTALL
      PackageManager *pm = package_manager_get ();

      /* If the package manager is configured, or we have some non-vanilla *
       * packages, we should offer the option to downgrade:                */
      if (package_manager_is_setup (pm) ||
          package_manager_is_system_upgraded (pm, view))
        {
          set_response_status (win, win->priv->diagnostics_page,
              RESPONSE_UNINSTALL, RESPONSE_STATUS_ENABLED);
        }
#endif

      set_response_status (win, win->priv->diagnostics_page,
          RESPONSE_INSTALL, RESPONSE_STATUS_ENABLED);
      gtk_widget_grab_focus (win->priv->install_button);
    }

  set_response_status (win, win->priv->diagnostics_page,
      RESPONSE_BACK, RESPONSE_STATUS_ENABLED);
  set_response_status (win, win->priv->diagnostics_page,
      RESPONSE_CLOSE, RESPONSE_STATUS_ENABLED);
}

static void
on_transaction_finished (TransactionView *view, gboolean success, gpointer user_data)
{
  MainWindow *win = MAIN_WINDOW (user_data);

  g_debug ("%s/%s: Package transaction finished %s", __FILE__, __FUNCTION__, success ? "successfully" : "with an error");

  set_response_status (win, win->priv->transaction_page,
      RESPONSE_BACK, RESPONSE_STATUS_ENABLED);
  set_response_status (win, win->priv->transaction_page,
      RESPONSE_CLOSE, RESPONSE_STATUS_ENABLED);

  /* No point in going to the report page in case of error as everything
   * that happened is displayed on the current page */
  if (success)
    {
      set_response_status (win, win->priv->transaction_page,
          RESPONSE_NEXT, RESPONSE_STATUS_ENABLED);
      gtk_widget_grab_focus (win->priv->next_button);
    }
}

static void
on_need_reboot (TransactionView *view, gpointer user_data)
{
  MainWindow *win = MAIN_WINDOW (user_data);

  win->priv->need_reboot = TRUE;
}

static void
ask_reboot (MainWindow *win)
{
  GtkWidget *dialog;
  gboolean failed = FALSE;

  dialog = gtk_message_dialog_new (GTK_WINDOW (win), 0,
                                   GTK_MESSAGE_QUESTION, GTK_BUTTONS_YES_NO,
                                   "%s",
                                   _("System needs to be rebooted for the package changes to be taken into account. Do you want to reboot your system now?"));
  if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_YES)
    {
      GDBusConnection *bus;
      GDBusProxy *proxy;
      GError *error = NULL;

      bus = g_bus_get_sync (G_BUS_TYPE_SESSION, NULL, &error);
      if (bus)
        {
          proxy = g_dbus_proxy_new_sync (bus, 0, NULL,
                                         "org.gnome.SessionManager",
                                         "/org/gnome/SessionManager",
                                         "org.gnome.SessionManager",
                                         NULL,
                                         &error);
          if (proxy)
            {
              GVariant *ret;

              ret = g_dbus_proxy_call_sync (proxy, "Shutdown",
                                            NULL,
                                            G_DBUS_CALL_FLAGS_NONE,
                                            -1,
                                            NULL,
                                            &error);
              if (ret)
                g_variant_unref (ret);

              g_object_unref (proxy);
            }
          else
            {
              failed = TRUE;
              g_critical ("Could not contact session manager: %s", error->message);
              g_error_free (error);
            }

          g_object_unref (bus);
        }
      else
        {
          failed = TRUE;
          g_critical ("Could not contact the session bus: %s", error->message);
          g_error_free (error);
        }
    }

  gtk_widget_destroy (dialog);

  if (failed)
    {
      GtkWidget *error_dialog = gtk_message_dialog_new (GTK_WINDOW (win),
          GTK_DIALOG_DESTROY_WITH_PARENT,
          GTK_MESSAGE_ERROR,
          GTK_BUTTONS_CLOSE,
          _("Failed to reboot the system."));
      gtk_dialog_run (GTK_DIALOG (error_dialog));
      gtk_widget_destroy (error_dialog);
    }
}

static void
on_dialog_response (GtkDialog *dialog, gint response_id, gpointer user_data)
{
  MainWindow *win = MAIN_WINDOW (dialog);
  gint current_page = gtk_notebook_get_current_page (GTK_NOTEBOOK (win->priv->notebook));

  switch (response_id)
    {
    case RESPONSE_BACK:
      set_active_page (win, current_page - 1);
      break;
    case RESPONSE_NEXT:
      set_active_page (win, current_page + 1);
      break;
    case RESPONSE_UNINSTALL:
      win->priv->is_uninstall = TRUE;
#if ENABLE_KEY_INSTALLATION
      /* Once the uninstallation starts, we are sure that the key page will
       * never be shown again (and this button will never be pressed again
       * as it's hidden afterwards) */
      g_return_if_fail (win->priv->key_page != NULL);
      gtk_notebook_remove_page (GTK_NOTEBOOK (win->priv->notebook), current_page + 1);
      g_ptr_array_remove_index (win->priv->pages, current_page + 1);
      win->priv->key_page = NULL;
#endif
      set_active_page (win, current_page + 1);
      break;
    case RESPONSE_INSTALL:
      win->priv->is_uninstall = FALSE;
      set_active_page (win, current_page + 1);
      break;
    case RESPONSE_CLOSE:
      if (win->priv->need_reboot)
        ask_reboot (win);
      gtk_widget_destroy (GTK_WIDGET (win));
      break;
    default:
      /* FIXME: Once this code has been untangled, this should be a
       * g_assert_not_reached(). */
      break;
    }
}

static void
activate_intro_page (MainWindow *win, Page *page)
{
  set_response_status (win, page, RESPONSE_BACK, RESPONSE_STATUS_DISABLED);
  set_next_button_label (win, page, NEXT_BUTTON_LABEL_BEGIN);
  gtk_widget_grab_focus (win->priv->next_button);
}

static void
activate_diagnostics_page (MainWindow *win, Page *page)
{
  /* These will be enabled when the diagnostics finishes... */
  set_response_status (win, page, RESPONSE_BACK, RESPONSE_STATUS_DISABLED);
  set_response_status (win, page, RESPONSE_CLOSE, RESPONSE_STATUS_DISABLED);
  set_response_status (win, page, RESPONSE_INSTALL, RESPONSE_STATUS_DISABLED);
  /* ... next is not available ... */
  set_response_status (win, page, RESPONSE_NEXT, RESPONSE_STATUS_HIDDEN);
  /* and uninstall is going to be shown only if needed */

  diagnostics_view_start (DIAGNOSTICS_VIEW (page->widget));
}

#if ENABLE_KEY_INSTALLATION
static void
activate_key_page (MainWindow *win, Page *page)
{
  g_return_if_fail (!win->priv->is_uninstall);

  key_view_start (KEY_VIEW (page->widget));
}
#endif

static void
activate_transaction_page (MainWindow *win, Page *page)
{
  gboolean install_key = FALSE;
#if ENABLE_KEY_INSTALLATION
  const gchar *docs_to_show;
#endif

  /* Once you select install/uninstall there's no going back, so we just show
   * a normal "Next" button */
  win->priv->diagnostics_page->cached_reponse_statuses[RESPONSE_INSTALL] = RESPONSE_STATUS_HIDDEN;
  win->priv->diagnostics_page->cached_reponse_statuses[RESPONSE_UNINSTALL] = RESPONSE_STATUS_HIDDEN;
  win->priv->diagnostics_page->cached_reponse_statuses[RESPONSE_NEXT] = RESPONSE_STATUS_ENABLED;

  /* These will be enabled when the transaction finishes */
  set_response_status (win, page, RESPONSE_BACK, RESPONSE_STATUS_DISABLED);
  set_response_status (win, page, RESPONSE_NEXT, RESPONSE_STATUS_DISABLED);
  set_response_status (win, page, RESPONSE_CLOSE, RESPONSE_STATUS_DISABLED);

  set_next_button_label (win, page, NEXT_BUTTON_LABEL_REPORT);

#if ENABLE_KEY_INSTALLATION
  if (win->priv->key_page)
    {
      /* You cannot change your mind after starting the installation */
      key_view_freeze_choice (KEY_VIEW (win->priv->key_page->widget));

      if (!win->priv->is_uninstall)
        install_key = key_view_get_install_key (KEY_VIEW (win->priv->key_page->widget));

      docs_to_show = key_view_get_docs_to_show (KEY_VIEW (win->priv->key_page->widget));
      if (docs_to_show != NULL)
        gtk_show_uri (NULL, docs_to_show, gtk_get_current_event_time (), NULL);
    }
#endif

  transaction_view_start (TRANSACTION_VIEW (page->widget),
      win->priv->is_uninstall, install_key);
}

static void
activate_report_view (MainWindow *win, Page *page)
{
  GHashTable *packages_before, *packages_after;

  gtk_widget_hide (win->priv->progress.box);

  set_response_status (win, page, RESPONSE_NEXT, RESPONSE_STATUS_DISABLED);
  gtk_widget_grab_focus (win->priv->close_button);

  transaction_view_get_package_lists (TRANSACTION_VIEW (win->priv->transaction_page->widget),
      &packages_before, &packages_after);
  report_view_start (REPORT_VIEW (page->widget), packages_before, packages_after);
}

static void
progress_widgets_init (MainWindow *win, GtkBox *box)
{
  GtkLabel *l;

  win->priv->pages = g_ptr_array_new_with_free_func (g_free);

  /* create the progress widget(s) */
  win->priv->progress.box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 1);
  gtk_widget_set_halign (win->priv->progress.box, GTK_ALIGN_START);
  gtk_widget_set_valign (win->priv->progress.box, GTK_ALIGN_CENTER);

  /* the short "current action" widget */
  win->priv->progress.status = gtk_label_new (" ");
  l = GTK_LABEL (win->priv->progress.status);
  gtk_label_set_ellipsize(l, PANGO_ELLIPSIZE_MIDDLE);
  gtk_label_set_width_chars (l, 20);
  gtk_label_set_max_width_chars(l, 20);
  gtk_misc_set_alignment (GTK_MISC (l), 0.0, 0.0);
  gtk_box_pack_start(GTK_BOX (win->priv->progress.box), win->priv->progress.status, FALSE, FALSE, 1);
  gtk_widget_show (win->priv->progress.status);

  /* The longer detailed-message widget */
  win->priv->progress.message = gtk_label_new (" ");
  l = GTK_LABEL (win->priv->progress.message);
  gtk_box_pack_start(GTK_BOX (win->priv->progress.box), win->priv->progress.message, FALSE, FALSE, 1);
  gtk_label_set_ellipsize (l, PANGO_ELLIPSIZE_MIDDLE);
  gtk_label_set_width_chars (l, 40);
  gtk_label_set_max_width_chars (l, 40);
  gtk_misc_set_alignment (GTK_MISC (l), 0.0, 0.0);
  gtk_widget_show (win->priv->progress.message);

  /* The overall %age widget */
  win->priv->progress.percent = gtk_label_new (" ");
  l = GTK_LABEL (win->priv->progress.percent);
  gtk_label_set_width_chars(l, 5);
  gtk_label_set_max_width_chars(l, 5);
  gtk_misc_set_alignment (GTK_MISC (l), 0.0, 0.0);
  gtk_box_pack_start (GTK_BOX (win->priv->progress.box), win->priv->progress.percent, FALSE, FALSE, 1);
  gtk_widget_show (win->priv->progress.percent);

  /* the progress spinner */
  win->priv->progress.spinner = gtk_spinner_new ();
  gtk_box_pack_end (GTK_BOX (win->priv->progress.box), win->priv->progress.spinner, TRUE, FALSE, 1);

  gtk_widget_show (win->priv->progress.box);
  gtk_box_pack_start (box, win->priv->progress.box, TRUE, TRUE, 3);
}

static void
main_window_init (MainWindow *win)
{
  GtkWidget *vbox;
  GtkWidget *box, *w;

  gtk_window_set_default_size (GTK_WINDOW (win), 700, 500);

  win->priv = g_new0 (MainWindowPrivate, 1);

  vbox = gtk_box_new (GTK_ORIENTATION_VERTICAL, 3);
  box = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 3);

  gtk_widget_show (box);
  gtk_widget_show (vbox);

  gtk_box_pack_start (GTK_BOX (gtk_dialog_get_content_area (GTK_DIALOG (win))), vbox, TRUE, TRUE, 3);

  progress_widgets_init (win, GTK_BOX (vbox));
  gtk_box_pack_start (GTK_BOX (vbox), box, TRUE, TRUE, 1);

  w = gtk_image_new_from_file (IMAGESDIR "/logo.png");
  gtk_widget_show (w);
  gtk_box_pack_start (GTK_BOX (box), w, FALSE, TRUE, 3);

  /* Create the notebook that will provide the different pages */
  win->priv->notebook = gtk_notebook_new ();
  gtk_container_set_border_width (GTK_CONTAINER (win->priv->notebook), 12);
  gtk_notebook_set_show_tabs (GTK_NOTEBOOK (win->priv->notebook), FALSE);
  gtk_notebook_set_show_border (GTK_NOTEBOOK (win->priv->notebook), FALSE);
  gtk_widget_show (win->priv->notebook);
  gtk_box_pack_start (GTK_BOX (box), win->priv->notebook, TRUE, TRUE, 3);

  /* Add Introduction view */
  w = gtk_label_new (_("<big><b>Intel Graphics Installer for Linux</b></big>\n\n"
					   "<b>Automatically identify and find software updates.</b>\n\n"
					   "This program allows you to install the latest graphics stack packages "
					   "from Intel. It will find and set up the repositories needed for getting "
					   "your system up-to-date with the latest graphics drivers from Intel."));
  gtk_label_set_use_markup (GTK_LABEL (w), TRUE);
  gtk_label_set_line_wrap (GTK_LABEL (w), TRUE);
  gtk_misc_set_alignment (GTK_MISC (w), 0.0, 0.0);
  win->priv->intro_page = add_page (win, w, activate_intro_page);

  /* Add Diagnostics view */
  w = diagnostics_view_new ();
  g_signal_connect (w, "finished", G_CALLBACK (on_diagnostics_finished), win);
  win->priv->diagnostics_page = add_page (win, w, activate_diagnostics_page);

  /* Add key view */
#if ENABLE_KEY_INSTALLATION
  w = key_view_new ();
  win->priv->key_page = add_page (win, w, activate_key_page);
#endif

  /* Add Transaction view */
  w = transaction_view_new ();
  g_signal_connect (w, "finished", G_CALLBACK (on_transaction_finished), win);
  g_signal_connect (w, "need-reboot", G_CALLBACK (on_need_reboot), win);
  win->priv->transaction_page = add_page (win, w, activate_transaction_page);

  /* Add Report view */
  w = report_view_new ();
  win->priv->report_page = add_page (win, w, activate_report_view);

  /* Add buttons (the actual text will be set when activating each page) */
  win->priv->back_button = gtk_dialog_add_button (GTK_DIALOG (win), _("Back"), RESPONSE_BACK);
  win->priv->close_button = gtk_dialog_add_button (GTK_DIALOG (win), GTK_STOCK_CLOSE, RESPONSE_CLOSE);
  win->priv->next_button = gtk_dialog_add_button (GTK_DIALOG (win), NEXT_BUTTON_LABEL_NEXT, RESPONSE_NEXT);
  win->priv->install_button = gtk_dialog_add_button (GTK_DIALOG (win), _("Uninstall"), RESPONSE_UNINSTALL);
  win->priv->install_button = gtk_dialog_add_button (GTK_DIALOG (win), _("Install"), RESPONSE_INSTALL);

  g_signal_connect (win, "response", G_CALLBACK (on_dialog_response), NULL);

  set_active_page (win, 0);
}

GtkWindow *
main_window_new (void)
{
  return g_object_new (TYPE_MAIN_WINDOW, NULL);
}

void
main_window_progress (MainWindow *win,
                      const gchar *action,
                      const gchar *msg,
                      gint percent,
                      gboolean spin)
{
  static gchar last_action[255] = "";
  static gint  last_percent = -1;
  static gint  stickiness = 0;
  gboolean repeat = g_strcmp0 (action, last_action) == 0;
  gboolean stuck = FALSE;
  gboolean spinning;

  if (action)
    g_strlcpy (last_action, action, 255);

  // still going, same action as before, percent didn't change:
  if (spin && repeat && last_percent == percent)
    stuck = (stickiness++ >= 2);
  else
    stickiness = 0;

  last_percent = percent;

  if (win == NULL || win->priv == NULL)
    return;

  if (action != NULL && win->priv->progress.status != NULL)
    {
      GtkLabel *a = GTK_LABEL (win->priv->progress.status);
      gtk_label_set_text(a, action);
    }

  if (msg != NULL && win->priv->progress.message != NULL)
    {
      GtkLabel *m = GTK_LABEL (win->priv->progress.message);
      gtk_label_set_text(m, msg);
    }

  if (win->priv->progress.spinner != NULL)
    {
      GtkSpinner *s = GTK_SPINNER(win->priv->progress.spinner);

      if (spin)
        {
          gtk_spinner_start (s);
          gtk_widget_show (GTK_WIDGET (s));
        }
      else
        {
          gtk_spinner_stop (s);
          gtk_widget_hide (GTK_WIDGET (s));
        }
    }

  if (percent != -1 &&
      win->priv->progress.percent != NULL &&
      win->priv->progress.spinner != NULL)
    {
      GtkLabel *p = GTK_LABEL (win->priv->progress.percent);

      if (percent > 100)
        percent = 100;

      if (stuck)
        {
          gtk_label_set_text (p, WAITING);
        }
      else if (percent >= 0)
        {
          gchar *text = g_strdup_printf ("%3d %%", percent);

          gtk_label_set_text (p, text);
          g_free (text);
        }
      else
        {
          gtk_label_set_text (p, WAITING);
        }
    }
  else if (percent == -1 &&
           win->priv->progress.percent != NULL)
    {
      gtk_label_set_text (GTK_LABEL (win->priv->progress.percent), "");
    }

  spinning = FALSE;
  g_object_get (win->priv->progress.spinner, "active", &spinning, NULL);
  g_debug ("🕛 %s : %s  [ %s ] %s",
           gtk_label_get_text (GTK_LABEL (win->priv->progress.status )),
           gtk_label_get_text (GTK_LABEL (win->priv->progress.message)),
           gtk_label_get_text (GTK_LABEL (win->priv->progress.percent)),
           spinning ? "⏲" : "◦");
}
