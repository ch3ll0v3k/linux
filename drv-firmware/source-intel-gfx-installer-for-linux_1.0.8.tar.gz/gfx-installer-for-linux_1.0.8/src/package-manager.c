/*
 * Copyright © 2012-2013 Intel Corporation
 *
 * Authors: Rodrigo Moya <rodrigo.moya@collabora.co.uk>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <glib/gi18n.h>
#include <gio/gio.h>
#include <polkit/polkit.h>

#include "package-manager.h"
#include "package-manager-fedora.h"
#include "package-manager-ubuntu.h"
#include "utils.h"
#include "marshal.h"

#define INSTALLER_PERMISSION "org.01.linuxgraphics.installer"

G_DEFINE_TYPE (PackageManager, package_manager, G_TYPE_OBJECT)

struct _PackageManagerPrivate
{
  PkClient *pk_client;
};

enum {
  ERROR_SIGNAL,
  PROGRESS_SIGNAL,
  PRE_INSTALL_FINISHED_SIGNAL,
  SETUP_FINISHED_SIGNAL,
  TRANSACTION_FINISHED_SIGNAL,
  CLEANUP_FINISHED_SIGNAL,
  LIST_PACKAGES_FINISHED_SIGNAL,
  LAST_SIGNAL
};
static guint pm_signals[LAST_SIGNAL];

static PackageManager *singleton_pm = NULL;

static void
package_manager_finalize (GObject *object)
{
  PackageManager *manager = (PackageManager *) object;

  g_clear_object (&manager->priv->pk_client);

  G_OBJECT_CLASS (package_manager_parent_class)->finalize (object);
}

static void
package_manager_class_init (PackageManagerClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  object_class->finalize = package_manager_finalize;
  klass->is_setup = NULL;
  klass->is_distro_supported = NULL;
  klass->pre_install = NULL;
  klass->setup = NULL;
  klass->run_transaction = NULL;
  klass->clean = NULL;
  klass->is_system_upgraded = NULL;
  klass->clean_transactions = NULL;
  klass->is_status_ok = NULL;

  g_type_class_add_private (object_class, sizeof (PackageManagerPrivate));

  /* Install signals */
  pm_signals[ERROR_SIGNAL] = g_signal_new ("error",
					   G_OBJECT_CLASS_TYPE (object_class),
					   G_SIGNAL_RUN_LAST,
					   G_STRUCT_OFFSET (PackageManagerClass, error),
					   NULL, NULL,
					   g_cclosure_marshal_VOID__STRING,
					   G_TYPE_NONE, 1, G_TYPE_STRING);
  pm_signals[PROGRESS_SIGNAL] = g_signal_new ("progress",
					      G_OBJECT_CLASS_TYPE (object_class),
					      G_SIGNAL_RUN_LAST,
					      G_STRUCT_OFFSET (PackageManagerClass, progress),
					      NULL, NULL,
					      g_cclosure_marshal_VOID__STRING,
					      G_TYPE_NONE, 1, G_TYPE_STRING);
  pm_signals[PRE_INSTALL_FINISHED_SIGNAL] = g_signal_new ("pre-install-finished",
      G_OBJECT_CLASS_TYPE (object_class),
      G_SIGNAL_RUN_LAST,
      G_STRUCT_OFFSET (PackageManagerClass, pre_install_finished),
      NULL, NULL,
      g_cclosure_marshal_VOID__VOID,
      G_TYPE_NONE, 0);
  pm_signals[SETUP_FINISHED_SIGNAL] = g_signal_new ("setup-finished",
						    G_OBJECT_CLASS_TYPE (object_class),
						    G_SIGNAL_RUN_LAST,
						    G_STRUCT_OFFSET (PackageManagerClass, setup_finished),
						    NULL, NULL,
						    g_cclosure_marshal_VOID__VOID,
						    G_TYPE_NONE, 0);
  pm_signals[TRANSACTION_FINISHED_SIGNAL] = g_signal_new ("transaction-finished",
							  G_OBJECT_CLASS_TYPE (object_class),
							  G_SIGNAL_RUN_LAST,
							  G_STRUCT_OFFSET (PackageManagerClass, transaction_finished),
							  NULL, NULL,
							  g_cclosure_marshal_VOID__VOID,
							  G_TYPE_NONE, 0);
  pm_signals[CLEANUP_FINISHED_SIGNAL] = g_signal_new ("cleanup-finished",
						      G_OBJECT_CLASS_TYPE (object_class),
						      G_SIGNAL_RUN_LAST,
						      G_STRUCT_OFFSET (PackageManagerClass, cleanup_finished),
						      NULL, NULL,
						      g_cclosure_marshal_VOID__VOID,
						      G_TYPE_NONE, 0);
  pm_signals[LIST_PACKAGES_FINISHED_SIGNAL] = g_signal_new ("list-packages-finished",
							    G_OBJECT_CLASS_TYPE (object_class),
							    G_SIGNAL_RUN_LAST,
							    G_STRUCT_OFFSET (PackageManagerClass, list_packages_finished),
							    NULL, NULL,
							    g_cclosure_marshal_VOID__POINTER,
							    G_TYPE_NONE,
							    1,
							    G_TYPE_POINTER);
}

static void
package_manager_init (PackageManager *manager)
{
  manager->priv = G_TYPE_INSTANCE_GET_PRIVATE (manager, TYPE_PACKAGE_MANAGER, PackageManagerPrivate);

  manager->priv->pk_client = pk_client_new ();
  package_manager_check_pk_permission (manager, INSTALLER_PERMISSION);
}

PackageManager *
package_manager_get (void)
{
  Distribution *distro;

  if (singleton_pm)
    return singleton_pm;

  /* Determine on which distro we are running */
  distro = get_distro_information ();
  if (!distro)
    return NULL;

  if (g_strcmp0 (distro->distributor, "Ubuntu") == 0)
    singleton_pm = package_manager_ubuntu_new ();
  else if (g_strcmp0 (distro->distributor, "Fedora") == 0)
    singleton_pm = package_manager_fedora_new ();

  return singleton_pm;
}

/* This is intended to be called _only_ when the 3rd party repo(s) are NOT   *
 * configured and we want to check to see if we have upgraded packages, ie   *
 * we are partially upgraded and we want to let the user head either way:    *
 * It will not return sensible results if the 3rd party repos are configured */
gboolean
package_manager_is_system_upgraded (PackageManager *manager, DiagnosticsView *v)
{
  PackageManagerClass *klass;
  gboolean upgraded = FALSE;

  g_return_val_if_fail (IS_PACKAGE_MANAGER (manager), FALSE);

  klass = PACKAGE_MANAGER_GET_CLASS (manager);

  update_progress_details ("Status-check", "Checking upgrade status", 0, 1);

  if (klass->is_system_upgraded != NULL)
      upgraded = klass->is_system_upgraded (manager, v);

  update_progress_details (NULL, "Complete", 101, 0);

  return upgraded;
}

static void
package_manager_clean_transactions (PackageManager *manager)
{
  PackageManagerClass *klass;

  g_return_if_fail (IS_PACKAGE_MANAGER (manager));

  klass = PACKAGE_MANAGER_GET_CLASS (manager);

  if (klass->clean_transactions != NULL)
      klass->clean_transactions (manager);
}

gboolean
package_manager_is_status_ok (PackageManager *manager, gchar **error_msg)
{
  PackageManagerClass *klass;

  g_return_val_if_fail (IS_PACKAGE_MANAGER (manager), FALSE);
  g_return_val_if_fail (error_msg != NULL, FALSE);

  *error_msg = NULL; /* just to make sure */

  klass = PACKAGE_MANAGER_GET_CLASS (manager);

  if (klass->is_status_ok != NULL)
    return klass->is_status_ok (manager, error_msg);
  else
    return TRUE; /* just assume everything is fine */
}

gboolean
package_manager_is_setup (PackageManager *manager)
{
  gboolean pmsetup = FALSE;

  g_return_val_if_fail (IS_PACKAGE_MANAGER (manager), FALSE);

  update_progress_details ("Status-check",
                           "Checking Repository Configuration", 0, 1);

  if (PACKAGE_MANAGER_GET_CLASS (manager)->is_setup != NULL)
    pmsetup = PACKAGE_MANAGER_GET_CLASS (manager)->is_setup (manager);

  update_progress_details (NULL, "Complete", 101, 0);

  return pmsetup;
}

gboolean
package_manager_is_distro_supported (PackageManager *manager)
{
  gboolean supported = FALSE;
  Configuration *cfg = NULL;
  PackageManagerClass *klass = PACKAGE_MANAGER_GET_CLASS (manager);

  g_return_val_if_fail (IS_PACKAGE_MANAGER (manager), FALSE);

  update_progress_details ("Configuration", "Loading …", 0, 1);

  cfg = get_configuration ();

  update_progress_details (NULL, "Loaded", 80, 1);

  if (!cfg)
    {
      g_signal_emit_by_name (manager, "error", "Unsupported distribution");
      return FALSE;
    }

  if (cfg->errors && cfg->errors->len > 0)
    {
      guint i;

      for (i = 0; i < cfg->errors->len; i++)
        {
          gchar *msg = g_ptr_array_index (cfg->errors, i);

          g_signal_emit_by_name (manager, "error", msg);
        }

      return FALSE;
    }

  update_progress_details (NULL, "Testing …", 80, 1);

  if (klass->is_distro_supported != NULL)
    supported = klass->is_distro_supported (manager, cfg);

  update_progress_details (NULL, "Complete", 101, 0);

  return supported;
}

gboolean
package_manager_pre_install (PackageManager *manager)
{
  gboolean ready = FALSE;

  g_return_val_if_fail (IS_PACKAGE_MANAGER (manager), FALSE);

  update_progress_details ("Pre-install", "Ensuring consistent repositories …", 0, 1);

  if (PACKAGE_MANAGER_GET_CLASS (manager)->pre_install != NULL)
    ready = PACKAGE_MANAGER_GET_CLASS (manager)->pre_install (manager);

  update_progress_details (NULL, "Complete", 101, 0);

  return ready;
}

gboolean
package_manager_setup (PackageManager *manager, gboolean install_key)
{
  gboolean is_setup = FALSE;

  g_return_val_if_fail (IS_PACKAGE_MANAGER (manager), FALSE);

  update_progress_details ("Setup", "Configuring Repositories …", 0, 1);

  if (PACKAGE_MANAGER_GET_CLASS (manager)->setup != NULL)
    is_setup = PACKAGE_MANAGER_GET_CLASS (manager)->setup (manager, install_key);

  update_progress_details (NULL, "Complete", 101, 0);

  return is_setup;
}

gboolean
package_manager_run_transaction (PackageManager *manager)
{
  g_return_val_if_fail (IS_PACKAGE_MANAGER (manager), FALSE);

  if (PACKAGE_MANAGER_GET_CLASS (manager)->run_transaction != NULL)
    return PACKAGE_MANAGER_GET_CLASS (manager)->run_transaction (manager);

  return FALSE;
}

gboolean
package_manager_clean (PackageManager *manager)
{
  g_return_val_if_fail (IS_PACKAGE_MANAGER (manager), FALSE);

  if (PACKAGE_MANAGER_GET_CLASS (manager)->clean != NULL)
    return PACKAGE_MANAGER_GET_CLASS (manager)->clean (manager);

  return FALSE;
}

static void
packages_retrieved_cb (GObject *source, GAsyncResult *res, gpointer user_data)
{
  PackageManager *manager = user_data;
  PkResults *results;
  GPtrArray *packages;
  GHashTable *packages_hash;
  guint i;
  GError *error = NULL;

  results = pk_client_generic_finish (manager->priv->pk_client, res, &error);
  if (results == NULL)
    {
      g_signal_emit_by_name (manager, "error", error->message);
      g_clear_error (&error);
      return;
    }

  packages_hash = g_hash_table_new_full (g_str_hash, g_str_equal,
      g_free, g_free);
  packages = pk_results_get_package_array (results);
  for (i = 0; i < packages->len; i++)
    {
      PkPackage *package = g_ptr_array_index (packages, i);
      g_hash_table_replace (packages_hash,
          g_strdup_printf ("%s:%s",
            pk_package_get_name (package),
            pk_package_get_arch (package)),
          g_strdup (pk_package_get_version (package)));
    }

  /* Remove the repo package on Fedora installer */
  if (IS_PACKAGE_MANAGER_FEDORA (manager))
    {
      PackageManagerFedora *pmf = PACKAGE_MANAGER_FEDORA (manager);
      gchar *repo_name = g_strdup_printf ("%s:noarch",
          package_manager_fedora_get_repo_name (pmf));
      g_hash_table_remove (packages_hash, repo_name);
      g_free (repo_name);
    }

  g_signal_emit_by_name (manager, "list-packages-finished", packages_hash);

  g_hash_table_unref (packages_hash);
  g_clear_pointer (&packages, g_ptr_array_unref);
  g_object_unref (results);
}

gboolean
package_manager_list_packages (PackageManager *manager)
{
  g_return_val_if_fail (IS_PACKAGE_MANAGER (manager), FALSE);
  g_return_val_if_fail (manager->priv->pk_client, FALSE);

  package_manager_clean_transactions (manager);

  pk_client_get_packages_async (manager->priv->pk_client,
                                pk_filter_bitfield_from_string ("installed"),
                                NULL, /* cancellable */
                                NULL, /* progress callback, it doesn't actually work */
                                NULL, /* progress user data */
                                packages_retrieved_cb,
                                manager);

  return TRUE;
}

gboolean
package_manager_check_pk_permission (PackageManager *manager, const gchar *action_id)
{
  GPermission *permission;
  gboolean result = TRUE;

  g_debug ("polkit: Fetching %s permissions...", action_id);
  permission = polkit_permission_new_sync (action_id, NULL, NULL, NULL);
  if (!permission)
    {
      gchar *msg = g_strdup_printf (_("Your system does not have the '%s' PolicyKit files installed. Please check your installation"), action_id);
      g_signal_emit_by_name (manager, "error", msg);
      g_debug ("polkit: %s; %s", action_id, msg);
      g_free (msg);

      return FALSE;
    }

  if (!g_permission_get_allowed (permission))
    {
      GError *error = NULL;

      if (!g_permission_get_can_acquire (permission))
	{
	  g_signal_emit_by_name (manager, "error", _("You don't have permissions to run this operation"));
          g_debug ("polkit: %s; %s", action_id, "permission cannot be acquired");
	  result = FALSE;
	}
      else if (!g_permission_acquire (permission, NULL, &error))
	{
          const gchar *reason;
          gchar *msg;

          if (g_error_matches (error, G_IO_ERROR, G_IO_ERROR_CANCELLED))
            reason = _("User dismissed the authentication dialog");
          else
            reason = _("Polkit encountered an error");

	  msg = g_strdup_printf (_("Could not acquire permissions: %s"), reason);

	  g_signal_emit_by_name (manager, "error", msg);
          g_debug ("polkit: %s; %s", action_id, msg);
	  g_free (msg);
	  g_error_free (error);

	  result = FALSE;
	}
    }

  g_object_unref (permission);

  return result;
}

PkClient *
package_manager_get_pk_client (PackageManager *manager)
{
  return manager->priv->pk_client;
}
