#!/bin/bash
# Copyright © 2013 Intel Corporation
# Author: Vivek Dasmohapatra <vivek@collabora.com>

set -e 

srcdir=$(dirname "$0");
gnome_vg_suppressions=https://github.com/dtrebbien/GNOME.supp.git;
vg_suppress="gtk+ gdk gail gio glib pango .";
tmpdir="/tmp/$RANDOM-gnome-vg-suppressions-$$";
shopt -s nullglob;


cat_suppressions () { for f in "$1"/*.supp; do cat "$f"; echo "# --"; done; };

( mkdir -p "$tmpdir";
  cd "$tmpdir";
  git clone $gnome_vg_suppressions . > /dev/null;
  for d in $vg_suppress; do cat_suppressions $d; done; 
  rm -rf "$tmpdir" >/dev/null ) > ${srcdir}/.tmp.supp;
cat ${srcdir}/local.supp >> ${srcdir}/.tmp.supp;

mv -v ${srcdir}/.tmp.supp ${srcdir}/ilg-valgrind.supp;

