#!/bin/sh

same_thing ()
{
    if [ x$(stat -L -c%i $1) = x$(stat -L -c%i $2) ]; then true; else false; fi;
}

package=$1;
version=$2;
rpm_dir=${3:-~/rpmbuild}
tarname=$package-$version;
top_dir=$(basename $(pwd));

cd ..;

# create the symlink if the top dir is not named right and the target name
# doesn't exist already:
if [ $top_dir != $tarname ];
then
    if [ ! -e $tarname ];
    then
        ln -s $top_dir $tarname;
    fi;
fi;

# make sure we have a target rpmbuild directory:
if [ ! -d $rpm_dir ];
then
    echo RPM build dir $rpm_dir not found 1>&2;
    exit 1;
fi

# sanity check: are we about to tar up what we think we're about to tar up?
if ! same_thing $top_dir $tarname;
then
    echo $tarname already exists, please remove it 1>&2;
    exit 1;
fi

tar --exclude \*/.git --exclude configure -chzvf $rpm_dir/SOURCES/$tarname.tar.gz $tarname && \
    cp -av $top_dir/data/$package.spec $rpm_dir/SPECS/$package.spec



